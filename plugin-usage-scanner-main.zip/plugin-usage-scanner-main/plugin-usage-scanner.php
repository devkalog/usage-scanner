<?php
/**
 * Plugin Name:       Aboutnet Plugin Usage Scanner
 * Description:       Shows which installed plugins are actually used: where their elements are (Elementor widgets and extensions, shortcodes, blocks, widget areas) and what they do on the site (front-end output, login, email, URLs, cache, own data). Admin-only; scans only when you click Scan.
 * Version:           3.1.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Aboutnet
 * License:           GPL-2.0-or-later
 * Text Domain:       aboutnet-plugin-usage-scanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Declared inside the check (not at top level) so PHP does not bind the class early: a second copy
// of this file is skipped instead of causing a fatal "cannot redeclare class" error.
if ( ! class_exists( 'Aboutnet_Plugin_Usage_Scanner', false ) ) :

final class Aboutnet_Plugin_Usage_Scanner {

	const VERSION       = '3.1.0';
	const PAGE          = 'plugin-usage-scanner';
	const OPT_RESULT    = 'aboutnet_pus_inventory';
	const OPT_STATE     = 'aboutnet_pus_scan_state';
	const PROBE_KEY     = 'aboutnet_pus_probe';
	const PROBE_PARAM   = 'aboutnet_pus_probe';
	const NONCE_ACTION  = 'aboutnet_plugin_usage_scanner';
	const NONCE_NAME    = 'aboutnet_plugin_usage_scanner_nonce';
	const BATCH         = 100;
	const TIME_BUDGET   = 12;
	const SEARCH_BUDGET = 20;
	const SEARCH_CAP    = 1000;
	const SNIPPET_LEN   = 90;
	const MAX_LOCATIONS = 60;

	/** Post types that never hold page content worth scanning. */
	private const SKIP_POST_TYPES = array(
		'revision', 'nav_menu_item', 'customize_changeset', 'oembed_cache', 'user_request', 'attachment',
		'custom_css', 'wp_font_face', 'wp_font_family', 'wp_global_styles', 'scheduled-action',
		'shop_order', 'shop_order_refund', 'shop_order_placehold', 'shop_subscription', 'shop_coupon', 'product_variation',
		'acf-field', 'acf-field-group', 'acf-post-type', 'acf-taxonomy', 'acf-ui-options-page',
		'wpcf7_contact_form', 'wpforms', 'wpforms_log', 'elementor_font', 'elementor_icons', 'elementor_snippet',
	);

	/** Post types whose content is shown through other pages or site-wide. */
	private const TEMPLATE_TYPES = array( 'elementor_library', 'wp_block', 'wp_template', 'wp_template_part' );

	/** Widget-name prefixes too generic to treat as one plugin's settings prefix. */
	private const TOKEN_STOPLIST = array(
		'e', 'el', 'wp', 'my', 'the', 'form', 'forms', 'post', 'posts', 'product', 'products', 'woocommerce', 'wc',
		'theme', 'site', 'page', 'nav', 'menu', 'price', 'image', 'text', 'video', 'icon', 'social', 'google',
		'loop', 'search', 'custom', 'advanced', 'simple', 'animated', 'call', 'media', 'author', 'archive',
	);

	/** Known prefixes, used only to name the probable source of elements no active plugin provides. */
	private const HINTS = array(
		'w:ha'          => array( 'Happy Addons', array( 'happy-elementor-addons', 'happy-elementor-addons-pro' ) ),
		'w:eael'        => array( 'Essential Addons', array( 'essential-addons-for-elementor-lite', 'essential-addons-elementor' ) ),
		'w:premium'     => array( 'Premium Addons', array( 'premium-addons-for-elementor', 'premium-addons-pro' ) ),
		'w:jet'         => array( 'Crocoblock (Jet plugins)', array( 'jet-*' ) ),
		'w:uael'        => array( 'Ultimate Addons for Elementor', array( 'ultimate-elementor' ) ),
		'w:pp'          => array( 'PowerPack', array( 'powerpack-lite-for-elementor', 'powerpack-elements' ) ),
		'w:elementskit' => array( 'ElementsKit', array( 'elementskit-lite', 'elementskit' ) ),
		'w:ekit'        => array( 'ElementsKit', array( 'elementskit-lite', 'elementskit' ) ),
		'w:wpr'         => array( 'Royal Elementor Addons', array( 'royal-elementor-addons' ) ),
		'w:tp'          => array( 'The Plus Addons', array( 'the-plus-addons-for-elementor-page-builder', 'theplus_elementor_addon' ) ),
		'w:bdt'         => array( 'Element Pack', array( 'bdthemes-element-pack-lite', 'bdthemes-element-pack' ) ),
		'w:ucaddon'     => array( 'Unlimited Elements', array( 'unlimited-elements-for-elementor', 'unlimited-elements-for-elementor-premium' ) ),
		'w:wpforms'     => array( 'WPForms', array( 'wpforms-lite', 'wpforms' ) ),
		'w:elementor-pro' => array( 'Elementor Pro', array( 'elementor-pro' ) ),
		's:contact-form-7' => array( 'Contact Form 7', array( 'contact-form-7' ) ),
		's:wpforms'        => array( 'WPForms', array( 'wpforms-lite', 'wpforms' ) ),
		's:gravityform'    => array( 'Gravity Forms', array( 'gravityforms' ) ),
		's:fluentform'     => array( 'Fluent Forms', array( 'fluentform' ) ),
		's:rev_slider'     => array( 'Slider Revolution', array( 'revslider' ) ),
		's:vc_'            => array( 'WPBakery Page Builder', array( 'js_composer' ) ),
		's:et_pb_'         => array( 'Divi Builder', array( 'divi-builder' ) ),
		's:elementor-template' => array( 'Elementor Pro', array( 'elementor-pro' ) ),
		's:woocommerce_'   => array( 'WooCommerce', array( 'woocommerce' ) ),
		'd:acf'            => array( 'Advanced Custom Fields', array( 'advanced-custom-fields', 'advanced-custom-fields-pro' ) ),
		'd:jet'            => array( 'JetEngine', array( 'jet-engine' ) ),
		'd:pods'           => array( 'Pods', array( 'pods' ) ),
		'd:toolset'        => array( 'Toolset', array( 'types' ) ),
		'd:woocommerce'    => array( 'Elementor Pro (WooCommerce tags)', array( 'elementor-pro' ) ),
	);

	/** Elementor Pro widget names, so a missing Pro is named correctly. */
	private const ELEMENTOR_PRO_WIDGETS = array(
		'form', 'login', 'posts', 'portfolio', 'slides', 'nav-menu', 'mega-menu', 'loop-grid', 'loop-carousel',
		'animated-headline', 'price-list', 'price-table', 'flip-box', 'call-to-action', 'media-carousel',
		'testimonial-carousel', 'reviews', 'table-of-contents', 'countdown', 'share-buttons', 'blockquote',
		'template', 'global', 'gallery', 'sitemap', 'author-box', 'post-comments', 'post-navigation', 'post-info',
		'lottie', 'hotspot', 'paypal-button', 'stripe-button', 'progress-tracker', 'code-highlight', 'video-playlist',
		'off-canvas', 'archive-posts', 'search', 'search-form',
	);

	private const VERDICTS = array(
		'used'     => array( 'In use — keep', 'Its elements are on live pages, site-wide templates or widget areas.' ),
		'active'   => array( 'Working on the site — keep', 'Not (only) a page element, but it clearly does something on the site — see “What it does on the site”.' ),
		'hidden'   => array( 'Only in unpublished places', 'Its elements are only in drafts, private pages or templates that are not shown anywhere.' ),
		'quiet'    => array( 'Background only — check', 'Only background activity was found (it hooks into WordPress, runs tasks or keeps data). Decide based on what it does.' ),
		'unused'   => array( 'No sign of use — likely removable', 'Nothing it adds is used and no activity of it was found on the site.' ),
		'rescan'   => array( 'Activated after the scan', 'Run the scan again to check this plugin.' ),
		'inactive' => array( 'Inactive', 'Not running. Leftovers are its elements or data still saved on the site.' ),
	);

	/** WordPress behaviours worth naming when a plugin hooks into them. */
	private const HOOK_CATEGORIES = array(
		'SEO (titles, robots, sitemaps)' => array( 'wp_robots', 'document_title_parts', 'pre_get_document_title', 'wp_sitemaps_enabled', 'robots_txt' ),
		'Email sending'                  => array( 'phpmailer_init', 'pre_wp_mail', 'wp_mail', 'wp_mail_from', 'wp_mail_from_name' ),
		'Login and passwords'            => array( 'login_url', 'login_init', 'authenticate', 'wp_login_failed', 'login_form', 'lostpassword_url' ),
		'URLs and slugs'                 => array( 'sanitize_title', 'wp_unique_post_slug', 'redirect_canonical', 'post_link', 'page_link', 'term_link' ),
		'Redirects and 404s'             => array( 'pre_handle_404', 'wp_redirect', 'x_redirect_by' ),
		'Translations'                   => array( 'gettext', 'gettext_with_context', 'load_textdomain_mofile', 'override_load_textdomain', 'load_translation_file', 'locale' ),
		'Media uploads'                  => array( 'upload_mimes', 'wp_handle_upload', 'wp_handle_upload_prefilter', 'wp_generate_attachment_metadata', 'wp_check_filetype_and_ext' ),
		'Comments and spam'              => array( 'preprocess_comment', 'pre_comment_approved' ),
		'Post editor'                    => array( 'use_block_editor_for_post', 'use_block_editor_for_post_type', 'replace_editor', 'tiny_mce_before_init' ),
		'Admin list tools'               => array( 'post_row_actions', 'page_row_actions' ),
		'Script and style loading'       => array( 'script_loader_tag', 'style_loader_tag', 'script_loader_src', 'style_loader_src' ),
		'Security and access'            => array( 'xmlrpc_enabled', 'xmlrpc_methods', 'rest_authentication_errors', 'wp_headers' ),
		'Activity logging'               => array( 'activated_plugin', 'deactivated_plugin', 'user_register' ),
	);

	/** Data prefixes (tables, post meta, options) that do not follow the plugin's folder name. */
	private const DATA_ALIASES = array(
		'wordpress-seo'                       => array( 'yoast', 'wpseo' ),
		'wordpress-seo-premium'               => array( 'yoast', 'wpseo' ),
		'seo-by-rank-math'                    => array( 'rank_math', 'rankmath' ),
		'seo-by-rank-math-pro'                => array( 'rank_math', 'rankmath' ),
		'all-in-one-seo-pack'                 => array( 'aioseo' ),
		'translatepress-multilingual'         => array( 'trp' ),
		'woocommerce'                         => array( 'wc', 'woocommerce', 'actionscheduler' ),
		'wordfence'                           => array( 'wf', 'wfls', 'wordfence' ),
		'sitepress-multilingual-cms'          => array( 'icl', 'wpml' ),
		'polylang'                            => array( 'pll', 'polylang' ),
		'gravityforms'                        => array( 'gf', 'rg', 'gform' ),
		'formidable'                          => array( 'frm' ),
		'wp-mail-smtp'                        => array( 'wp_mail_smtp', 'wpmailsmtp' ),
		'easy-wp-smtp'                        => array( 'swpsmtp', 'easy_wp_smtp' ),
		'elementor'                           => array( 'e', 'elementor' ),
		'elementor-pro'                       => array( 'elementor_pro', 'elementorpro' ),
		'litespeed-cache'                     => array( 'litespeed' ),
		'loco-translate'                      => array( 'loco' ),
		'wp-rocket'                           => array( 'rocket', 'wp_rocket' ),
		'w3-total-cache'                      => array( 'w3tc' ),
		'updraftplus'                         => array( 'updraft' ),
		'duplicate-post'                      => array( 'duplicate_post' ),
		'google-site-kit'                     => array( 'googlesitekit' ),
		'complianz-gdpr'                      => array( 'cmplz' ),
		'cookie-law-info'                     => array( 'cky', 'cookielawinfo' ),
		'secure-custom-fields'                => array( 'acf' ),
		'advanced-custom-fields'              => array( 'acf' ),
		'advanced-custom-fields-pro'          => array( 'acf' ),
		'wp-optimize'                         => array( 'wpo' ),
		'mailchimp-for-wp'                    => array( 'mc4wp' ),
		'woodmart-core'                       => array( 'woodmart', 'xts' ),
		'simple-history'                      => array( 'simple_history' ),
		'wpforms-lite'                        => array( 'wpforms' ),
		'wpforms'                             => array( 'wpforms' ),
		'contact-form-7'                      => array( 'wpcf7' ),
		'jetpack'                             => array( 'jetpack', 'jpsq' ),
		'wps-hide-login'                      => array( 'whl' ),
		'essential-addons-for-elementor-lite' => array( 'eael' ),
		'the-events-calendar'                 => array( 'tribe', 'tec' ),
		'wp-smushit'                          => array( 'wp_smush', 'smush' ),
		'ewww-image-optimizer'                => array( 'ewww', 'ewwwio' ),
		'shortpixel-image-optimiser'          => array( 'shortpixel', 'wp_short_pixel' ),
		'wp-fastest-cache'                    => array( 'wpfc', 'wpfastestcache' ),
		'safe-svg'                            => array( 'safe_svg' ),
		'classic-editor'                      => array( 'classic_editor' ),
	);

	/** Words in plugin names too generic to identify a plugin's tables, meta or settings. */
	private const DATA_STOPLIST = array(
		'wordpress', 'plugin', 'plugins', 'addon', 'addons', 'lite', 'free', 'core', 'premium', 'multilingual', 'custom',
		'simple', 'advanced', 'easy', 'cache', 'page', 'pages', 'post', 'posts', 'data', 'settings', 'options', 'widget',
		'widgets', 'theme', 'site', 'google', 'social', 'media', 'image', 'images', 'form', 'forms', 'contact', 'security',
		'smtp', 'mail', 'email', 'translate', 'translation', 'editor', 'block', 'blocks', 'builder', 'manager', 'tools',
		'tool', 'login', 'hide', 'history', 'cookie', 'consent', 'banner', 'permalinks', 'fields', 'field', 'secure',
		'duplicate', 'classic', 'optimizer', 'optimize', 'analytics', 'search', 'slider', 'gallery', 'menu', 'user',
		'users', 'admin', 'auto', 'update', 'backup', 'files', 'file', 'link', 'links', 'shop', 'product', 'products',
		'order', 'orders', 'payment', 'payments', 'shipping', 'with', 'from', 'your', 'redirect', 'redirects', 'popup',
		'popups', 'header', 'footer', 'elements', 'element', 'kit', 'pack', 'suite', 'starter', 'templates', 'template',
	);

	/** @var array<string,string> post type => owner, captured while post types register. */
	private static $post_type_owners = array();

	/** @var array|null */
	private static $roots = null;

	/** @var array|null Measurements during a front-end probe request. */
	private static $probe = null;

	/** @var array|null|false */
	private static $result_cache = false;

	/** @var array|null */
	private static $rows_cache = null;

	/* ---------------------------------------------------------------------
	 * Bootstrap
	 * ------------------------------------------------------------------- */

	public static function bootstrap(): void {
		register_activation_hook( __FILE__, array( __CLASS__, 'activate' ) );

		if ( ! is_admin() ) {
			// Front end: one cheap check. Only the scanner's own probe requests (with a valid token) are measured.
			if ( isset( $_GET[ self::PROBE_PARAM ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				add_action( 'template_redirect', array( __CLASS__, 'probe_start' ), 0 );
			}
			return;
		}

		if ( self::is_scanner_request() ) {
			add_action( 'registered_post_type', array( __CLASS__, 'capture_post_type' ), 10, 2 );
		}
		add_action( 'plugins_loaded', array( __CLASS__, 'init' ), 20 );
	}

	public static function activate(): void {
		register_uninstall_hook( __FILE__, array( __CLASS__, 'uninstall' ) );
	}

	public static function uninstall(): void {
		delete_option( self::OPT_RESULT );
		delete_option( self::OPT_STATE );
		delete_transient( self::PROBE_KEY );
	}

	public static function init(): void {
		if ( class_exists( 'Aboutnet_Plugin_Usage_Scanner_Final', false ) ) {
			self::unhook_legacy();
			add_action( 'admin_notices', array( __CLASS__, 'legacy_notice' ) );
		}

		add_action( 'admin_menu', array( __CLASS__, 'add_admin_page' ) );
		add_action( 'admin_head', array( __CLASS__, 'admin_styles' ) );

		add_filter( 'manage_plugins_columns', array( __CLASS__, 'add_plugins_column' ) );
		add_action( 'manage_plugins_custom_column', array( __CLASS__, 'render_plugins_column' ), 10, 3 );

		foreach ( array( 'page', 'post' ) as $post_type ) {
			add_filter( "manage_{$post_type}_posts_columns", array( __CLASS__, 'add_posts_column' ) );
			add_action( "manage_{$post_type}_posts_custom_column", array( __CLASS__, 'render_posts_column' ), 10, 2 );
		}
		add_action( 'restrict_manage_posts', array( __CLASS__, 'render_posts_filter' ), 10, 2 );
		add_action( 'pre_get_posts', array( __CLASS__, 'apply_posts_filter' ) );
	}

	private static function is_scanner_request(): bool {
		return isset( $_GET['page'] ) && self::PAGE === sanitize_key( wp_unslash( $_GET['page'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	/** Version 2.x used another class name; if both are active, keep only this one. */
	private static function unhook_legacy(): void {
		$legacy = 'Aboutnet_Plugin_Usage_Scanner_Final';
		remove_action( 'admin_menu', array( $legacy, 'add_admin_page' ) );
		remove_action( 'admin_head', array( $legacy, 'admin_styles' ) );
		remove_filter( 'manage_page_posts_columns', array( $legacy, 'add_pages_detected_column' ) );
		remove_action( 'manage_page_posts_custom_column', array( $legacy, 'render_pages_detected_column' ), 10 );
		remove_action( 'restrict_manage_posts', array( $legacy, 'render_pages_filter_dropdown' ), 10 );
		remove_filter( 'posts_clauses', array( $legacy, 'filter_pages_by_detected_usage' ), 10 );
	}

	public static function legacy_notice(): void {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p><strong>Plugin Usage Scanner:</strong> an older copy (2.x) is also active and has been switched off. Deactivate and delete the old copy from Plugins.</p></div>';
	}

	public static function add_admin_page(): void {
		$hook = add_management_page( 'Plugin Usage Scanner', 'Plugin Usage Scanner', 'manage_options', self::PAGE, array( __CLASS__, 'render_page' ) );
		if ( $hook ) {
			add_action( 'load-' . $hook, array( __CLASS__, 'handle_post' ) );
		}
	}

	private static function page_url( array $args = array() ): string {
		return add_query_arg( array_merge( array( 'page' => self::PAGE ), $args ), admin_url( 'tools.php' ) );
	}

	/** Scan steps post here and redirect back, so reloading never re-runs a step. */
	public static function handle_post(): void {
		if ( 'POST' !== self::request_method() || empty( $_POST['pus_action'] ) ) {
			return;
		}
		$action = sanitize_key( wp_unslash( $_POST['pus_action'] ) );
		if ( ! in_array( $action, array( 'scan_start', 'scan_continue', 'scan_cancel' ), true ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'aboutnet-plugin-usage-scanner' ) );
		}
		check_admin_referer( self::NONCE_ACTION, self::NONCE_NAME );

		if ( 'scan_cancel' === $action ) {
			delete_option( self::OPT_STATE );
			wp_safe_redirect( self::page_url() );
			exit;
		}

		$probe = ( 'scan_start' === $action && isset( $_POST['pus_probe'] ) ) ? (string) wp_unslash( $_POST['pus_probe'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON, validated field by field in summarize_probe().
		$done  = self::run_scan_step( 'scan_start' === $action, $probe );
		wp_safe_redirect( self::page_url( $done ? array( 'scanned' => 1 ) : array( 'pus_step' => 1 ) ) );
		exit;
	}

	private static function request_method(): string {
		return isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET';
	}

	/* ---------------------------------------------------------------------
	 * Who owns what: file paths -> plugin folders
	 * ------------------------------------------------------------------- */

	private static function roots(): array {
		if ( null !== self::$roots ) {
			return self::$roots;
		}
		$roots = array();
		$dirs  = array(
			array( 'mu', defined( 'WPMU_PLUGIN_DIR' ) ? WPMU_PLUGIN_DIR : '' ),
			array( 'p', WP_PLUGIN_DIR ),
			array( 't', get_theme_root() ),
			array( 'core', ABSPATH . WPINC ),
			array( 'core', ABSPATH . 'wp-admin' ),
		);
		foreach ( $dirs as $dir ) {
			if ( '' === (string) $dir[1] ) {
				continue;
			}
			$real = realpath( $dir[1] );
			foreach ( array_unique( array( (string) $dir[1], false === $real ? '' : $real ) ) as $path ) {
				if ( '' !== $path ) {
					$roots[] = array( $dir[0], trailingslashit( wp_normalize_path( $path ) ) );
				}
			}
		}
		self::$roots = $roots;
		return $roots;
	}

	/** Returns 'p:folder', 'mu:file', 't:theme', 'core' or ''. */
	private static function owner_from_file( string $file ): string {
		if ( '' === $file ) {
			return '';
		}
		$file = wp_normalize_path( $file );
		foreach ( self::roots() as $root ) {
			if ( 0 !== strpos( $file, $root[1] ) ) {
				continue;
			}
			if ( 'core' === $root[0] ) {
				return 'core';
			}
			$parts = explode( '/', substr( $file, strlen( $root[1] ) ), 2 );
			return '' === $parts[0] ? '' : $root[0] . ':' . $parts[0];
		}
		return '';
	}

	/** @param object|string $class */
	private static function owner_from_class( $class ): string {
		try {
			$file = ( new ReflectionClass( $class ) )->getFileName();
			return false === $file ? '' : self::owner_from_file( (string) $file );
		} catch ( \Throwable $e ) {
			return '';
		}
	}

	/** @param mixed $callback */
	private static function owner_from_callable( $callback ): string {
		try {
			if ( is_string( $callback ) && false !== strpos( $callback, '::' ) ) {
				$callback = explode( '::', $callback, 2 );
			}
			if ( is_array( $callback ) && 2 === count( $callback ) ) {
				$callback = array_values( $callback );
				// Prefer the concrete class: methods inherited from a base class in another plugin would point there.
				$owner = ( is_object( $callback[0] ) || ( is_string( $callback[0] ) && class_exists( $callback[0] ) ) ) ? self::owner_from_class( $callback[0] ) : '';
				if ( '' === $owner ) {
					$method = new ReflectionMethod( $callback[0], (string) $callback[1] );
					$owner  = self::owner_from_file( (string) $method->getFileName() );
				}
				return $owner;
			}
			if ( $callback instanceof Closure || ( is_string( $callback ) && function_exists( $callback ) ) ) {
				return self::owner_from_file( (string) ( new ReflectionFunction( $callback ) )->getFileName() );
			}
			if ( is_object( $callback ) ) {
				return self::owner_from_class( $callback );
			}
		} catch ( \Throwable $e ) {
			return '';
		}
		return '';
	}

	private static function owner_from_url( string $url ): string {
		if ( '' === $url ) {
			return '';
		}
		$path  = (string) wp_parse_url( $url, PHP_URL_PATH );
		$bases = array(
			'mu' => defined( 'WPMU_PLUGIN_URL' ) ? WPMU_PLUGIN_URL : '',
			'p'  => plugins_url(),
			't'  => get_theme_root_uri(),
		);
		foreach ( $bases as $kind => $base ) {
			$base_path = untrailingslashit( (string) wp_parse_url( (string) $base, PHP_URL_PATH ) ) . '/';
			if ( '/' !== $base_path && 0 === strpos( $path, $base_path ) ) {
				$parts = explode( '/', substr( $path, strlen( $base_path ) ), 2 );
				return '' === $parts[0] ? '' : $kind . ':' . $parts[0];
			}
		}
		return '';
	}

	/** Matches a block namespace or similar slug to an installed plugin folder or text domain. */
	private static function owner_from_slug( string $slug, bool $active_only = false ): string {
		if ( '' === $slug ) {
			return '';
		}
		$prefix_match = array();
		foreach ( self::plugin_list() as $folder => $plugin ) {
			if ( $active_only && ! $plugin['active'] ) {
				continue;
			}
			if ( $slug === $folder || $slug === $plugin['td'] ) {
				return 'p:' . $folder;
			}
			if ( 0 === strpos( $folder, $slug . '-' ) ) {
				$prefix_match[] = 'p:' . $folder;
			}
		}
		return 1 === count( $prefix_match ) ? $prefix_match[0] : '';
	}

	private static function self_owner(): string {
		static $self = null;
		if ( null === $self ) {
			$self = self::owner_from_file( __FILE__ );
		}
		return $self;
	}

	private static function is_trackable_owner( $owner ): bool {
		return is_string( $owner ) && '' !== $owner && 'core' !== $owner && self::self_owner() !== $owner;
	}

	/** Records which plugin called register_post_type(). Hooked only on the scanner's own requests. */
	public static function capture_post_type( $post_type, $object ): void {
		if ( ! empty( $object->_builtin ) ) {
			return;
		}
		foreach ( debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 30 ) as $frame ) { // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_debug_backtrace
			if ( empty( $frame['file'] ) ) {
				continue;
			}
			$owner = self::owner_from_file( (string) $frame['file'] );
			if ( self::is_trackable_owner( $owner ) ) {
				self::$post_type_owners[ (string) $post_type ] = $owner;
				return;
			}
		}
	}

	/* ---------------------------------------------------------------------
	 * Installed plugins and what each one registers
	 * ------------------------------------------------------------------- */

	private static function plugin_list(): array {
		static $list = null;
		if ( null !== $list ) {
			return $list;
		}
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$list = array();
		foreach ( get_plugins() as $file => $data ) {
			$folder   = false !== strpos( $file, '/' ) ? dirname( $file ) : $file;
			$requires = array();
			if ( ! empty( $data['RequiresPlugins'] ) ) {
				$requires = array_map( 'trim', explode( ',', (string) $data['RequiresPlugins'] ) );
			}
			$list[ $folder ] = array(
				'file'     => $file,
				'name'     => wp_strip_all_tags( (string) $data['Name'] ),
				'version'  => (string) $data['Version'],
				'td'       => (string) $data['TextDomain'],
				'active'   => is_plugin_active( $file ),
				'requires' => array_values( array_diff( array_unique( array_filter( $requires ) ), array( $folder ) ) ),
			);
		}
		uasort(
			$list,
			static function ( array $a, array $b ): int {
				return strcasecmp( $a['name'], $b['name'] );
			}
		);
		return $list;
	}

	private static function build_registry(): array {
		$reg = array(
			'sc'       => array(), // shortcode tag => owner
			'w'        => array(), // Elementor widget => [owner, title]
			'b'        => array(), // block name => owner
			'd'        => array(), // Elementor dynamic tag => owner
			'ww'       => array(), // classic widget id_base => [owner, title]
			'pt'       => array(), // post type => [owner, label, items, published, public]
			'tokens'   => array(), // settings prefix => owners
		);

		global $shortcode_tags, $wp_widget_factory;
		foreach ( (array) $shortcode_tags as $tag => $callback ) {
			$reg['sc'][ (string) $tag ] = self::owner_from_callable( $callback );
		}

		if ( isset( $wp_widget_factory->widgets ) && is_array( $wp_widget_factory->widgets ) ) {
			foreach ( $wp_widget_factory->widgets as $widget ) {
				if ( is_object( $widget ) && ! empty( $widget->id_base ) ) {
					$reg['ww'][ (string) $widget->id_base ] = array( self::owner_from_class( $widget ), wp_strip_all_tags( (string) ( isset( $widget->name ) ? $widget->name : $widget->id_base ) ) );
				}
			}
		}

		if ( class_exists( '\Elementor\Plugin', false ) && isset( \Elementor\Plugin::$instance ) && is_object( \Elementor\Plugin::$instance ) ) {
			$elementor = \Elementor\Plugin::$instance;
			try {
				if ( isset( $elementor->widgets_manager ) && is_object( $elementor->widgets_manager ) && method_exists( $elementor->widgets_manager, 'get_widget_types' ) ) {
					foreach ( (array) $elementor->widgets_manager->get_widget_types() as $name => $widget ) {
						if ( ! is_object( $widget ) ) {
							continue;
						}
						$name  = (string) $name;
						$owner = self::owner_from_class( $widget );
						if ( 0 === strpos( $name, 'wp-widget-' ) ) {
							$base  = substr( $name, 10 );
							$owner = isset( $reg['ww'][ $base ] ) ? $reg['ww'][ $base ][0] : 'core';
						}
						$title             = method_exists( $widget, 'get_title' ) ? (string) $widget->get_title() : $name;
						$reg['w'][ $name ] = array( $owner, wp_strip_all_tags( $title ) );
					}
				}
			} catch ( \Throwable $e ) {
				$reg['w_error'] = $e->getMessage();
			}
			try {
				if ( isset( $elementor->dynamic_tags ) && is_object( $elementor->dynamic_tags ) && method_exists( $elementor->dynamic_tags, 'get_tags' ) ) {
					foreach ( (array) $elementor->dynamic_tags->get_tags() as $name => $info ) {
						$class = '';
						if ( is_array( $info ) && ! empty( $info['class'] ) ) {
							$class = $info['class'];
						} elseif ( is_array( $info ) && isset( $info['instance'] ) && is_object( $info['instance'] ) ) {
							$class = $info['instance'];
						} elseif ( is_object( $info ) ) {
							$class = $info;
						}
						$reg['d'][ (string) $name ] = '' !== $class ? self::owner_from_class( $class ) : '';
					}
				}
			} catch ( \Throwable $e ) {
				$reg['d_error'] = $e->getMessage();
			}
		}

		if ( class_exists( 'WP_Block_Type_Registry' ) ) {
			foreach ( WP_Block_Type_Registry::get_instance()->get_all_registered() as $name => $block ) {
				if ( 0 === strpos( (string) $name, 'core/' ) ) {
					continue;
				}
				$owner = '';
				if ( ! empty( $block->render_callback ) ) {
					$owner = self::owner_from_callable( $block->render_callback );
					$owner = 'core' === $owner ? '' : $owner;
				}
				if ( '' === $owner ) {
					$owner = self::owner_from_block_assets( $block );
				}
				if ( '' === $owner ) {
					$owner = self::owner_from_slug( (string) strtok( (string) $name, '/' ) );
				}
				$reg['b'][ (string) $name ] = $owner;
			}
		}

		foreach ( get_post_types( array( '_builtin' => false ), 'objects' ) as $name => $object ) {
			$counts = wp_count_posts( $name );
			$items  = 0;
			foreach ( array( 'publish', 'future', 'draft', 'pending', 'private' ) as $status ) {
				$items += isset( $counts->$status ) ? (int) $counts->$status : 0;
			}
			$reg['pt'][ $name ] = array(
				isset( self::$post_type_owners[ $name ] ) ? self::$post_type_owners[ $name ] : '',
				wp_strip_all_tags( (string) $object->labels->name ),
				$items,
				isset( $counts->publish ) ? (int) $counts->publish : 0,
				! empty( $object->public ),
			);
		}

		// Settings prefixes for Elementor extensions (e.g. "ha_", "eael_"): the dominant prefix of a plugin's widget names.
		$by_owner = array();
		foreach ( $reg['w'] as $name => $info ) {
			if ( self::is_trackable_owner( $info[0] ) && ! in_array( $info[0], array( 'p:elementor', 'p:elementor-pro' ), true ) ) {
				$by_owner[ $info[0] ][] = $name;
			}
		}
		foreach ( $by_owner as $owner => $names ) {
			if ( count( $names ) < 3 ) {
				continue;
			}
			$counts = array();
			foreach ( $names as $name ) {
				$token            = self::token_of( $name );
				$counts[ $token ] = isset( $counts[ $token ] ) ? $counts[ $token ] + 1 : 1;
			}
			arsort( $counts );
			$token = (string) key( $counts );
			if ( strlen( $token ) >= 2 && current( $counts ) / count( $names ) >= 0.6 && ! in_array( $token, self::TOKEN_STOPLIST, true ) ) {
				$reg['tokens'][ $token ][] = $owner;
			}
		}

		return $reg;
	}

	private static function owner_from_block_assets( $block ): string {
		$props = array( 'editor_script_handles', 'script_handles', 'view_script_handles', 'editor_style_handles', 'style_handles', 'view_style_handles' );
		foreach ( $props as $prop ) {
			if ( ! property_exists( $block, $prop ) || empty( $block->$prop ) || ! is_array( $block->$prop ) ) {
				continue;
			}
			$deps = false !== strpos( $prop, 'style' ) ? wp_styles() : wp_scripts();
			foreach ( $block->$prop as $handle ) {
				if ( isset( $deps->registered[ $handle ] ) && is_string( $deps->registered[ $handle ]->src ) ) {
					$owner = self::owner_from_url( $deps->registered[ $handle ]->src );
					if ( self::is_trackable_owner( $owner ) ) {
						return $owner;
					}
				}
			}
		}
		return '';
	}

	private static function token_of( string $name ): string {
		$parts = preg_split( '/[-_]/', strtolower( $name ), 2 );
		return is_array( $parts ) ? (string) $parts[0] : '';
	}

	/* ---------------------------------------------------------------------
	 * Front-end probe: a few live pages are loaded as a visitor (from the admin's browser, so it also
	 * works before a DNS switch) with a one-time token. On those requests only, every plugin callback on
	 * wp_head / wp_body_open / wp_footer / the_content is measured, and a JSON summary is appended.
	 * ------------------------------------------------------------------- */

	public static function probe_start(): void {
		$given    = isset( $_GET[ self::PROBE_PARAM ] ) ? sanitize_text_field( wp_unslash( $_GET[ self::PROBE_PARAM ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$expected = get_transient( self::PROBE_KEY );
		if ( ! is_string( $expected ) || '' === $expected || '' === $given || ! hash_equals( $expected, $given ) ) {
			return;
		}
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		do_action( 'litespeed_control_set_nocache', 'Aboutnet Plugin Usage Scanner probe' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
		nocache_headers();
		self::$probe = array(
			'out'     => array(),
			'wrapped' => array(),
		);
		foreach ( array( 'wp_head', 'wp_body_open', 'wp_footer' ) as $hook ) {
			add_action(
				$hook,
				static function () use ( $hook ): void {
					self::probe_wrap( $hook, false );
				},
				PHP_INT_MIN
			);
		}
		add_filter(
			'the_content',
			static function ( $content ) {
				self::probe_wrap( 'the_content', true );
				return $content;
			},
			PHP_INT_MIN
		);
		add_action( 'wp_footer', array( __CLASS__, 'probe_emit' ), PHP_INT_MAX );
	}

	/** Wraps every plugin callback of a hook (once, just before it runs) to measure its output. */
	private static function probe_wrap( string $hook, bool $is_filter ): void {
		global $wp_filter;
		if ( null === self::$probe || isset( self::$probe['wrapped'][ $hook ] ) || ! isset( $wp_filter[ $hook ] ) || ! ( $wp_filter[ $hook ] instanceof WP_Hook ) ) {
			return;
		}
		self::$probe['wrapped'][ $hook ] = true;
		foreach ( $wp_filter[ $hook ]->callbacks as $priority => $callbacks ) {
			foreach ( $callbacks as $id => $callback ) {
				$original = $callback['function'];
				$owner    = self::owner_from_callable( $original );
				if ( ! self::is_trackable_owner( $owner ) ) {
					continue;
				}
				if ( $is_filter ) {
					$wrapper = static function () use ( $original, $owner, $hook ) {
						$args   = func_get_args();
						$result = call_user_func_array( $original, $args );
						if ( isset( $args[0] ) && is_string( $args[0] ) && is_string( $result ) && $result !== $args[0] ) {
							self::probe_count( $owner, $hook, 1 );
						}
						return $result;
					};
				} else {
					$wrapper = static function () use ( $original, $owner, $hook ) {
						$args = func_get_args();
						ob_start();
						try {
							$result = call_user_func_array( $original, $args );
						} finally {
							$output = (string) ob_get_clean();
						}
						self::probe_count( $owner, $hook, strlen( $output ) );
						echo $output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own output, passed through unchanged.
						return $result;
					};
				}
				$wp_filter[ $hook ]->callbacks[ $priority ][ $id ]['function'] = $wrapper;
			}
		}
	}

	private static function probe_count( string $owner, string $hook, int $amount ): void {
		if ( null !== self::$probe && $amount > 0 ) {
			self::$probe['out'][ $owner ][ $hook ] = ( isset( self::$probe['out'][ $owner ][ $hook ] ) ? self::$probe['out'][ $owner ][ $hook ] : 0 ) + $amount;
		}
	}

	public static function probe_emit(): void {
		if ( null === self::$probe ) {
			return;
		}
		$assets = array();
		foreach ( array( wp_scripts(), wp_styles() ) as $deps ) {
			foreach ( (array) $deps->done as $handle ) {
				$src   = ( isset( $deps->registered[ $handle ] ) && is_string( $deps->registered[ $handle ]->src ) ) ? $deps->registered[ $handle ]->src : '';
				$owner = self::owner_from_url( $src );
				if ( self::is_trackable_owner( $owner ) ) {
					$assets[ $owner ][] = (string) $handle;
				}
			}
		}
		global $shortcode_tags;
		$shortcodes = array();
		foreach ( (array) $shortcode_tags as $tag => $callback ) {
			$shortcodes[ (string) $tag ] = self::owner_from_callable( $callback );
		}
		$data        = array(
			'v'      => 1,
			't'      => wp_strip_all_tags( html_entity_decode( wp_get_document_title(), ENT_QUOTES, 'UTF-8' ) ),
			'out'    => self::$probe['out'],
			'assets' => $assets,
			'sc'     => $shortcodes,
			'hooks'  => self::hook_footprint(),
		);
		self::$probe = null;
		echo "\n" . '<script type="application/json" id="aboutnet-pus-probe">' . wp_json_encode( $data, JSON_HEX_TAG | JSON_HEX_AMP ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON with HEX_TAG.
	}

	private static function probe_token(): string {
		$token = get_transient( self::PROBE_KEY );
		if ( ! is_string( $token ) || strlen( $token ) < 20 ) {
			$token = wp_generate_password( 32, false );
		}
		set_transient( self::PROBE_KEY, $token, 30 * MINUTE_IN_SECONDS );
		return $token;
	}

	/** Home page, the page that used the most plugins last time, and the latest page / post / product. */
	private static function probe_urls(): array {
		$token = self::probe_token();
		$urls  = array( home_url( '/' ) );
		$r     = self::get_result();
		if ( $r ) {
			$best  = 0;
			$count = 0;
			foreach ( $r['index'] as $id => $entry ) {
				if ( isset( $r['posts'][ $id ] ) && 'published' === $r['posts'][ $id ]['live'] && count( $entry ) > $count ) {
					$best  = (int) $id;
					$count = count( $entry );
				}
			}
			if ( $best ) {
				$urls[] = get_permalink( $best );
			}
		}
		$front = (int) get_option( 'page_on_front' );
		foreach ( array( 'page', 'post', 'product' ) as $type ) {
			if ( ! post_type_exists( $type ) ) {
				continue;
			}
			$ids = get_posts(
				array(
					'post_type'   => $type,
					'post_status' => 'publish',
					'numberposts' => 1,
					'fields'      => 'ids',
					'orderby'     => 'modified',
					'exclude'     => $front ? array( $front ) : array(),
				)
			);
			if ( $ids ) {
				$urls[] = get_permalink( (int) $ids[0] );
			}
		}
		$out = array();
		foreach ( array_unique( array_filter( array_map( 'strval', $urls ) ) ) as $url ) {
			$out[] = add_query_arg( self::PROBE_PARAM, $token, $url );
		}
		return array_slice( $out, 0, 5 );
	}

	/** Results posted by the browser: [{u, s, d, p, e}], validated loosely here and strictly when summarised. */
	private static function parse_probe_input( string $raw ): array {
		$data = '' !== $raw ? json_decode( $raw, true ) : null;
		if ( ! is_array( $data ) ) {
			return array();
		}
		$items = array();
		foreach ( array_slice( $data, 0, 10 ) as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$items[] = array(
				'u' => isset( $item['u'] ) ? self::clean_probe_url( (string) $item['u'] ) : '',
				's' => isset( $item['s'] ) ? (int) $item['s'] : 0,
				'd' => ( isset( $item['d'] ) && is_array( $item['d'] ) ) ? $item['d'] : null,
				'p' => ( isset( $item['p'] ) && is_array( $item['p'] ) ) ? $item['p'] : array(),
				'e' => isset( $item['e'] ) ? substr( sanitize_text_field( (string) $item['e'] ), 0, 160 ) : '',
			);
		}
		return $items;
	}

	private static function clean_probe_url( string $url ): string {
		return esc_url_raw( remove_query_arg( self::PROBE_PARAM, $url ) );
	}

	/** Same probe from the server, used only when the browser could not send results. */
	private static function server_probe(): array {
		$url      = add_query_arg( self::PROBE_PARAM, self::probe_token(), home_url( '/' ) );
		$response = wp_remote_get(
			$url,
			array(
				'timeout'     => 10,
				'redirection' => 3,
				'sslverify'   => apply_filters( 'https_local_ssl_verify', false ), // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
			)
		);
		if ( is_wp_error( $response ) ) {
			return array( array( 'u' => home_url( '/' ), 's' => 0, 'd' => null, 'p' => array(), 'e' => $response->get_error_message() ) );
		}
		$html = (string) wp_remote_retrieve_body( $response );
		return array(
			array(
				'u' => home_url( '/' ),
				's' => (int) wp_remote_retrieve_response_code( $response ),
				'd' => self::probe_json_from_html( $html ),
				'p' => self::plugin_paths_in_html( $html ),
				'e' => '',
			),
		);
	}

	private static function probe_json_from_html( string $html ): ?array {
		if ( ! preg_match( '#<script type="application/json" id="aboutnet-pus-probe">(.*?)</script>#s', $html, $m ) ) {
			return null;
		}
		$data = json_decode( $m[1], true );
		return is_array( $data ) ? $data : null;
	}

	private static function plugin_paths_in_html( string $html ): array {
		$base  = (string) wp_parse_url( plugins_url( '/' ), PHP_URL_PATH );
		$paths = array();
		foreach ( array( $base, str_replace( '/', '\/', $base ) ) as $needle ) {
			if ( preg_match_all( '#' . preg_quote( $needle, '#' ) . '([A-Za-z0-9._-]+)(?:/|\\\\/)#', $html, $m ) ) {
				foreach ( $m[1] as $folder ) {
					$paths[ $folder ] = ( isset( $paths[ $folder ] ) ? $paths[ $folder ] : 0 ) + 1;
				}
			}
		}
		return $paths;
	}

	private static function valid_owner( $owner ): bool {
		return is_string( $owner ) && 1 === preg_match( '/^(p|t|mu):[A-Za-z0-9._ -]{1,190}$/', $owner );
	}

	/** Merges the probed pages into one summary per plugin. */
	private static function summarize_probe( array $items, string $via ): array {
		$sum = array(
			'via'    => $via,
			'tried'  => count( $items ),
			'ok'     => 0,
			'pages'  => array(),
			'errors' => array(),
			'owners' => array(),
			'sc'     => array(),
		);
		$labels = array_keys( self::HOOK_CATEGORIES );
		foreach ( $items as $item ) {
			$page = (string) $item['u'];
			if ( ! is_array( $item['d'] ) ) {
				$sum['errors'][] = ( '' !== $item['e'] ? $item['e'] : 'HTTP ' . (int) $item['s'] ) . ' — ' . $page;
				continue;
			}
			++$sum['ok'];
			$data           = $item['d'];
			$title          = isset( $data['t'] ) && is_string( $data['t'] ) ? trim( sanitize_text_field( $data['t'] ) ) : '';
			$sum['pages'][] = '' !== $title ? ( function_exists( 'mb_strimwidth' ) ? mb_strimwidth( $title, 0, 60, '…', 'UTF-8' ) : substr( $title, 0, 60 ) ) : self::short_url( $page );
			$seen           = array();

			foreach ( ( isset( $data['out'] ) && is_array( $data['out'] ) ) ? $data['out'] : array() as $owner => $hooks ) {
				if ( ! self::valid_owner( $owner ) || ! is_array( $hooks ) ) {
					continue;
				}
				foreach ( $hooks as $hook => $amount ) {
					if ( in_array( $hook, array( 'wp_head', 'wp_body_open', 'wp_footer', 'the_content' ), true ) && (int) $amount > 0 ) {
						$current                                  = isset( $sum['owners'][ $owner ]['out'][ $hook ] ) ? $sum['owners'][ $owner ]['out'][ $hook ] : 0;
						$sum['owners'][ $owner ]['out'][ $hook ] = max( $current, (int) $amount );
						$seen[ $owner ]                          = true;
					}
				}
			}
			foreach ( ( isset( $data['assets'] ) && is_array( $data['assets'] ) ) ? $data['assets'] : array() as $owner => $handles ) {
				if ( self::valid_owner( $owner ) && is_array( $handles ) ) {
					foreach ( array_slice( $handles, 0, 40 ) as $handle ) {
						$sum['owners'][ $owner ]['assets'][ sanitize_key( (string) $handle ) ] = true;
					}
					$seen[ $owner ] = true;
				}
			}
			foreach ( ( isset( $data['sc'] ) && is_array( $data['sc'] ) ) ? $data['sc'] : array() as $tag => $owner ) {
				if ( is_string( $tag ) && ( '' === $owner || 'core' === $owner || self::valid_owner( $owner ) ) && ! isset( $sum['sc'][ $tag ] ) ) {
					$sum['sc'][ $tag ] = (string) $owner;
				}
			}
			foreach ( ( isset( $data['hooks'] ) && is_array( $data['hooks'] ) ) ? $data['hooks'] : array() as $owner => $found ) {
				if ( self::valid_owner( $owner ) && is_array( $found ) ) {
					foreach ( $found as $label ) {
						if ( in_array( $label, $labels, true ) ) {
							$sum['owners'][ $owner ]['hooks'][ $label ] = true;
						}
					}
				}
			}
			foreach ( $item['p'] as $folder => $count ) {
				if ( is_string( $folder ) && preg_match( '/^[A-Za-z0-9._-]{1,190}$/', $folder ) ) {
					$owner                                 = 'p:' . $folder;
					$sum['owners'][ $owner ]['refs']       = ( isset( $sum['owners'][ $owner ]['refs'] ) ? $sum['owners'][ $owner ]['refs'] : 0 ) + (int) $count;
					$seen[ $owner ]                        = true;
				}
			}
			foreach ( array_keys( $seen ) as $owner ) {
				$sum['owners'][ $owner ]['pages'] = ( isset( $sum['owners'][ $owner ]['pages'] ) ? $sum['owners'][ $owner ]['pages'] : 0 ) + 1;
			}
		}
		foreach ( $sum['owners'] as $owner => $info ) {
			if ( isset( $info['assets'] ) ) {
				$sum['owners'][ $owner ]['assets'] = array_keys( $info['assets'] );
			}
			if ( isset( $info['hooks'] ) ) {
				$sum['owners'][ $owner ]['hooks'] = array_keys( $info['hooks'] );
			}
		}
		return $sum;
	}

	/** Which plugins hook into the behaviours listed in HOOK_CATEGORIES (in the current request). */
	private static function hook_footprint(): array {
		$out = array();
		foreach ( self::HOOK_CATEGORIES as $label => $hooks ) {
			foreach ( $hooks as $hook ) {
				foreach ( self::hook_callbacks( $hook ) as $callback ) {
					$out[ $callback['owner'] ][ $label ] = true;
				}
			}
		}
		return array_map( 'array_keys', $out );
	}

	/** Plugin/theme callbacks on a hook: [owner, function, accepted_args]. */
	private static function hook_callbacks( string $hook ): array {
		global $wp_filter;
		if ( ! isset( $wp_filter[ $hook ] ) || ! ( $wp_filter[ $hook ] instanceof WP_Hook ) ) {
			return array();
		}
		$out = array();
		foreach ( $wp_filter[ $hook ]->callbacks as $callbacks ) {
			foreach ( $callbacks as $callback ) {
				$owner = self::owner_from_callable( $callback['function'] );
				if ( self::is_trackable_owner( $owner ) ) {
					$out[] = array(
						'owner'    => $owner,
						'function' => $callback['function'],
						'args'     => (int) $callback['accepted_args'],
					);
				}
			}
		}
		return $out;
	}

	/* ---------------------------------------------------------------------
	 * Content scan (resumable, in time-boxed steps)
	 * ------------------------------------------------------------------- */

	private static function run_scan_step( bool $fresh, string $probe_input = '' ): bool {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}
		wp_raise_memory_limit( 'admin' );
		$start = microtime( true );

		$state = $fresh ? null : get_option( self::OPT_STATE );
		if ( ! is_array( $state ) || self::VERSION !== ( $state['v'] ?? '' ) ) {
			$state = self::new_state( $probe_input );
		}

		$done              = self::scan_step( $state, $start + self::TIME_BUDGET );
		$state['elapsed'] += microtime( true ) - $start;

		if ( $done ) {
			$activity          = microtime( true );
			$state['activity'] = self::collect_activity( $state );
			$state['elapsed'] += microtime( true ) - $activity;
			update_option( self::OPT_RESULT, self::finalize( $state ), false );
			delete_option( self::OPT_STATE );
			self::$result_cache = false;
		} else {
			update_option( self::OPT_STATE, $state, false );
		}
		return $done;
	}

	private static function new_state( string $probe_input = '' ): array {
		global $wpdb;
		$active = array();
		foreach ( self::plugin_list() as $folder => $plugin ) {
			if ( $plugin['active'] ) {
				$active[] = 'p:' . $folder;
			}
		}

		$items = self::parse_probe_input( $probe_input );
		$via   = 'browser';
		$ok    = false;
		foreach ( $items as $item ) {
			$ok = $ok || is_array( $item['d'] );
		}
		if ( ! $ok ) {
			$fallback = self::server_probe();
			if ( is_array( $fallback[0]['d'] ) || ! $items ) {
				$items = $fallback;
				$via   = 'server';
			}
		}
		$probe = self::summarize_probe( $items, $via );

		$reg = self::build_registry();
		foreach ( $probe['sc'] as $tag => $owner ) {
			if ( ! isset( $reg['sc'][ $tag ] ) || '' === $reg['sc'][ $tag ] ) {
				$reg['sc'][ $tag ] = $owner;
			}
		}
		unset( $probe['sc'] );

		return array(
			'v'           => self::VERSION,
			'started'     => time(),
			'elapsed'     => 0.0,
			'cursor'      => 0,
			'scanned'     => 0,
			'total'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE " . self::posts_where_sql() ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			'elementor'   => 0,
			'undecodable' => array(),
			'active'      => $active,
			'probe'       => $probe,
			'reg'         => $reg,
			'posts'       => array(),
		);
	}

	private static function posts_where_sql(): string {
		$types = implode( "','", array_map( 'esc_sql', self::SKIP_POST_TYPES ) );
		return "post_type NOT IN ('{$types}') AND post_status NOT IN ('trash','auto-draft','inherit')";
	}

	/** Post types where unknown [shortcodes] are worth reporting (visible content). */
	private static function public_content_types(): array {
		$types = get_post_types( array( 'public' => true ) );
		foreach ( self::TEMPLATE_TYPES as $type ) {
			$types[ $type ] = $type;
		}
		return $types;
	}

	private static function scan_step( array &$state, float $deadline ): bool {
		global $wpdb;
		$where   = self::posts_where_sql();
		$context = array(
			'sc_regex' => self::shortcode_regex( array_keys( $state['reg']['sc'] ) ),
			'sc_set'   => $state['reg']['sc'],
			'tokens'   => $state['reg']['tokens'],
			'widgets'  => $state['reg']['w'],
			'public'   => self::public_content_types(),
		);

		while ( microtime( true ) < $deadline ) {
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_title, post_type, post_status, post_content, post_excerpt FROM {$wpdb->posts} WHERE ID > %d AND {$where} ORDER BY ID ASC LIMIT %d", $state['cursor'], self::BATCH ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			if ( empty( $rows ) ) {
				return true;
			}
			$meta = self::fetch_builder_meta( array_map( 'intval', wp_list_pluck( $rows, 'ID' ) ) );
			foreach ( $rows as $row ) {
				self::scan_one_post( $row, isset( $meta[ (int) $row->ID ] ) ? $meta[ (int) $row->ID ] : array(), $state, $context );
				$state['cursor'] = (int) $row->ID;
				++$state['scanned'];
				if ( microtime( true ) >= $deadline ) {
					return false;
				}
			}
			unset( $rows, $meta );
		}
		return false;
	}

	/** Small Elementor meta for a batch; the (possibly huge) layout JSON is fetched per post later. */
	private static function fetch_builder_meta( array $ids ): array {
		global $wpdb;
		if ( empty( $ids ) ) {
			return array();
		}
		$in   = implode( ',', array_map( 'intval', $ids ) );
		$rows = $wpdb->get_results( "SELECT post_id, meta_key, CASE WHEN meta_key = '_elementor_data' THEN '' ELSE meta_value END AS meta_value FROM {$wpdb->postmeta} WHERE post_id IN ({$in}) AND meta_key IN ('_elementor_data','_elementor_edit_mode','_elementor_template_type','_elementor_conditions')" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$meta = array();
		foreach ( (array) $rows as $row ) {
			$id = (int) $row->post_id;
			if ( ! isset( $meta[ $id ][ $row->meta_key ] ) ) {
				$meta[ $id ][ $row->meta_key ] = '_elementor_data' === $row->meta_key ? true : (string) $row->meta_value;
			}
		}
		return $meta;
	}

	private static function fetch_elementor_data( int $post_id ): string {
		global $wpdb;
		return (string) $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_elementor_data' ORDER BY meta_id ASC LIMIT 1", $post_id ) );
	}

	private static function scan_one_post( $row, array $meta, array &$state, array $context ): void {
		$id     = (int) $row->ID;
		$keys   = array();
		$crumbs = array();
		$refs   = array();
		$public = isset( $context['public'][ $row->post_type ] );

		// Elementor renders its own layout instead of post_content, but only while the page is built with it.
		$builder = ! empty( $meta['_elementor_data'] ) && ! empty( $meta['_elementor_edit_mode'] );

		if ( $builder ) {
			$raw = self::fetch_elementor_data( $id );
			++$state['elementor'];
			$tree = self::decode_elementor_data( $raw );
			if ( null !== $tree ) {
				self::walk_elements(
					$tree,
					static function ( array $el, array $path ) use ( &$keys, &$crumbs, &$refs, $context, $public ): void {
						self::visit_inventory_element( $el, $path, $keys, $crumbs, $refs, $context, $public );
					}
				);
			} elseif ( '' !== trim( $raw ) ) {
				if ( count( $state['undecodable'] ) < 50 ) {
					$state['undecodable'][] = $id;
				}
				if ( preg_match_all( '/"widgetType"\s*:\s*"([^"\\\\]+)"/', $raw, $matches ) ) {
					foreach ( $matches[1] as $widget_type ) {
						self::add_key( $keys, 'w:' . $widget_type );
					}
				}
				self::scan_string( $raw, $keys, $refs, $context, $public );
			}
			unset( $raw, $tree );
			self::scan_string( (string) $row->post_excerpt, $keys, $refs, $context, $public );
		} else {
			self::scan_string( (string) $row->post_content . "\n" . (string) $row->post_excerpt, $keys, $refs, $context, $public );
		}

		$is_template = in_array( $row->post_type, self::TEMPLATE_TYPES, true );
		if ( empty( $keys ) && empty( $refs ) && ! $is_template ) {
			return;
		}

		$entry = array(
			't' => (string) $row->post_title,
			'y' => (string) $row->post_type,
			's' => (string) $row->post_status,
			'k' => $keys,
		);
		if ( $builder ) {
			$entry['e'] = 1;
		}
		if ( $crumbs ) {
			$entry['c'] = $crumbs;
		}
		if ( $refs ) {
			$entry['r'] = array_values( array_unique( array_filter( $refs ) ) );
		}
		if ( ! empty( $meta['_elementor_template_type'] ) ) {
			$entry['tt'] = (string) $meta['_elementor_template_type'];
		}
		if ( ! empty( $meta['_elementor_conditions'] ) ) {
			$conditions = self::safe_unserialize( (string) $meta['_elementor_conditions'] );
			if ( is_array( $conditions ) ) {
				$entry['cn'] = array_values( array_filter( $conditions, 'is_string' ) );
			}
		}
		$state['posts'][ $id ] = $entry;
	}

	private static function visit_inventory_element( array $el, array $path, array &$keys, array &$crumbs, array &$refs, array $context, bool $public ): void {
		$settings = ( isset( $el['settings'] ) && is_array( $el['settings'] ) ) ? $el['settings'] : array();
		$widget   = self::widget_type( $el );
		$where    = implode( ' › ', $path );

		if ( '' !== $widget ) {
			$owner     = isset( $context['widgets'][ $widget ] ) ? $context['widgets'][ $widget ][0] : '';
			$keep_path = ! in_array( $owner, array( 'core', 'p:elementor' ), true );
			self::add_key( $keys, 'w:' . $widget, $crumbs, $keep_path ? $where : '' );
			if ( 'global' === $widget && ! empty( $el['templateID'] ) && is_numeric( $el['templateID'] ) ) {
				$refs[] = (int) $el['templateID'];
			}
		}
		if ( isset( $settings['template_id'] ) && is_numeric( $settings['template_id'] ) ) {
			$refs[] = (int) $settings['template_id'];
		}

		// Elementor extensions add prefixed settings to any element ("ha_floating_fx", "eael_particle_switch"…).
		if ( $context['tokens'] ) {
			$seen = array();
			foreach ( $settings as $key => $value ) {
				$key = (string) $key;
				$pos = strpos( $key, '_' );
				if ( ! $pos ) {
					continue;
				}
				$token = strtolower( substr( $key, 0, $pos ) );
				if ( isset( $seen[ $token ] ) || ! isset( $context['tokens'][ $token ] ) ) {
					continue;
				}
				if ( '' !== $widget && $token === self::token_of( $widget ) ) {
					continue; // The plugin's own widget settings.
				}
				if ( self::is_active_setting( $value ) ) {
					$seen[ $token ] = true;
					self::add_key( $keys, 'x:' . $token, $crumbs, $where . ' (' . $key . ')' );
				}
			}
		}

		self::scan_strings_in( $settings, $keys, $refs, $context, $public, 0 );
	}

	private static function scan_strings_in( array $values, array &$keys, array &$refs, array $context, bool $public, int $depth ): void {
		if ( $depth > 8 ) {
			return;
		}
		foreach ( $values as $value ) {
			if ( is_array( $value ) ) {
				self::scan_strings_in( $value, $keys, $refs, $context, $public, $depth + 1 );
			} elseif ( is_string( $value ) && ( false !== strpos( $value, '[' ) || false !== strpos( $value, '<!--' ) ) ) {
				self::scan_string( $value, $keys, $refs, $context, $public );
			}
		}
	}

	/** Finds shortcodes, Elementor dynamic tags, blocks and template references in a piece of content. */
	private static function scan_string( string $text, array &$keys, array &$refs, array $context, bool $report_unknown ): void {
		if ( '' === $text ) {
			return;
		}
		if ( false !== strpos( $text, '[' ) ) {
			if ( '' !== $context['sc_regex'] && preg_match_all( '/' . $context['sc_regex'] . '/', $text, $matches, PREG_SET_ORDER ) ) {
				foreach ( $matches as $m ) {
					if ( '[' === $m[1] && isset( $m[6] ) && ']' === $m[6] ) {
						continue; // [[escaped]] shortcode, printed as text.
					}
					self::add_key( $keys, 's:' . $m[2] );
					if ( 'elementor-template' === $m[2] && preg_match( '/\bid\s*=\s*\\\\?["\']?(\d+)/', $m[3], $id ) ) {
						$refs[] = (int) $id[1];
					}
				}
			}
			if ( false !== strpos( $text, 'elementor-tag' ) && preg_match_all( '/\[elementor-tag\b[^\]]*?\bname=\\\\?"([^"\\\\]+)/', $text, $matches ) ) {
				foreach ( $matches[1] as $name ) {
					self::add_key( $keys, 'd:' . $name );
				}
			}
			if ( $report_unknown && preg_match_all( '/\[([A-Za-z][A-Za-z0-9_-]{1,60})(?=[\s\]\/])([^\[\]]{0,400})\]/', $text, $matches, PREG_SET_ORDER ) ) {
				foreach ( $matches as $m ) {
					$tag = $m[1];
					if ( isset( $context['sc_set'][ $tag ] ) || 'elementor-tag' === $tag ) {
						continue;
					}
					// Plain bracketed words are common in text; require something shortcode-like.
					if ( false === strpbrk( $tag, '_-' ) && false === strpos( $m[2], '=' ) ) {
						continue;
					}
					self::add_key( $keys, 'u:' . $tag );
				}
			}
		}
		if ( false !== strpos( $text, '<!--' ) ) {
			if ( preg_match_all( '/<!--\s+wp:([a-z][a-z0-9_-]*\/[a-z][a-z0-9_-]*)(?=[\s\/]|-->)/', $text, $matches ) ) {
				foreach ( $matches[1] as $block ) {
					if ( 0 !== strpos( $block, 'core/' ) ) {
						self::add_key( $keys, 'b:' . $block );
					}
				}
			}
			if ( preg_match_all( '/<!--\s+wp:block\s+\{[^}]*"ref"\s*:\s*(\d+)/', $text, $matches ) ) {
				foreach ( $matches[1] as $ref ) {
					$refs[] = (int) $ref;
				}
			}
		}
	}

	private static function add_key( array &$keys, string $key, ?array &$crumbs = null, string $crumb = '' ): void {
		$keys[ $key ] = isset( $keys[ $key ] ) ? $keys[ $key ] + 1 : 1;
		if ( null !== $crumbs && '' !== $crumb && ( ! isset( $crumbs[ $key ] ) || count( $crumbs[ $key ] ) < 3 ) ) {
			$crumbs[ $key ][] = function_exists( 'mb_strimwidth' ) ? mb_strimwidth( $crumb, 0, 180, '…', 'UTF-8' ) : substr( $crumb, 0, 180 );
		}
	}

	/** A switcher set to "yes" or a non-empty repeater: the extension is switched on for that element. */
	private static function is_active_setting( $value ): bool {
		if ( is_string( $value ) ) {
			return in_array( strtolower( $value ), array( 'yes', 'on', 'true', 'enable', 'enabled' ), true );
		}
		if ( is_array( $value ) && ! empty( $value ) ) {
			return array_keys( $value ) === range( 0, count( $value ) - 1 );
		}
		return false;
	}

	private static function shortcode_regex( array $tags ): string {
		$tags = array_values( array_filter( array_map( 'strval', $tags ), 'strlen' ) );
		return $tags ? get_shortcode_regex( $tags ) : '';
	}

	/**
	 * Elementor stores its layout as plain JSON. Do not unslash first: that removes the \" escapes of
	 * any text with quotes or HTML attributes and the JSON no longer parses.
	 */
	public static function decode_elementor_data( string $raw ): ?array {
		$raw = trim( $raw );
		if ( '' === $raw ) {
			return null;
		}
		$data = json_decode( $raw, true );
		if ( is_string( $data ) ) {
			$data = json_decode( $data, true ); // Double-encoded by some importers.
		}
		if ( ! is_array( $data ) ) {
			$data = json_decode( wp_unslash( $raw ), true ); // Over-slashed by some migrations.
		}
		if ( ! is_array( $data ) ) {
			return null;
		}
		if ( isset( $data['content'] ) && is_array( $data['content'] ) ) {
			$data = $data['content'];
		} elseif ( isset( $data['elType'] ) ) {
			$data = array( $data );
		}
		return $data;
	}

	/** Visits every element. $elements is the top-level list Elementor stores. */
	private static function walk_elements( array $elements, callable $visit, array $path = array(), int $depth = 0 ): void {
		if ( $depth > 60 ) {
			return;
		}
		foreach ( $elements as $el ) {
			if ( ! is_array( $el ) ) {
				continue;
			}
			$here = array_merge( $path, array( self::element_label( $el ) ) );
			$visit( $el, $here );
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
				self::walk_elements( $el['elements'], $visit, $here, $depth + 1 );
			}
		}
	}

	private static function widget_type( array $el ): string {
		return ( isset( $el['elType'], $el['widgetType'] ) && 'widget' === $el['elType'] && is_string( $el['widgetType'] ) ) ? $el['widgetType'] : '';
	}

	private static function element_label( array $el ): string {
		$custom = ( isset( $el['settings']['_title'] ) && is_string( $el['settings']['_title'] ) && '' !== $el['settings']['_title'] ) ? ' “' . $el['settings']['_title'] . '”' : '';
		$widget = self::widget_type( $el );
		if ( '' !== $widget ) {
			return $widget . $custom;
		}
		$type = isset( $el['elType'] ) ? (string) $el['elType'] : '';
		$map  = array(
			'section'       => 'Section',
			'column'        => 'Column',
			'container'     => 'Container',
			'inner-section' => 'Inner Section',
		);
		return ( isset( $map[ $type ] ) ? $map[ $type ] : ucfirst( $type ) ) . $custom;
	}

	private static function safe_unserialize( string $value ) {
		if ( ! is_serialized( $value ) ) {
			return $value;
		}
		return @unserialize( trim( $value ), array( 'allowed_classes' => false ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_unserialize, WordPress.PHP.NoSilencedErrors.Discouraged
	}

	/* ---------------------------------------------------------------------
	 * What each plugin does on the site besides page elements.
	 * Evidence strength: 2 = clear sign of use, 1 = background activity, 0 = information only.
	 * ------------------------------------------------------------------- */

	private static function collect_activity( array $state ): array {
		$act = array();
		$add = static function ( string $owner, int $strength, string $short, string $label ) use ( &$act ): void {
			if ( ! self::is_trackable_owner( $owner ) ) {
				return;
			}
			foreach ( isset( $act[ $owner ] ) ? $act[ $owner ] : array() as $existing ) {
				if ( $existing['l'] === $label ) {
					return;
				}
			}
			$act[ $owner ][] = array(
				's'  => $strength,
				'sh' => $short,
				'l'  => $label,
			);
		};

		$checks = array( 'activity_front_end', 'activity_behaviour', 'activity_theme', 'activity_specific', 'activity_post_types' );
		foreach ( $checks as $check ) {
			try {
				self::$check( $state, $add );
			} catch ( \Throwable $e ) {
				continue; // One failing check never stops the scan.
			}
		}

		$data = array(
			'tables'   => array(),
			'unlinked' => array(),
		);
		try {
			$data = self::activity_data( $add );
		} catch ( \Throwable $e ) {
			$data['error'] = $e->getMessage();
		}

		foreach ( $act as $owner => $list ) {
			usort(
				$list,
				static function ( array $a, array $b ): int {
					return $b['s'] <=> $a['s'];
				}
			);
			$act[ $owner ] = $list;
		}
		return array(
			'act'      => $act,
			'tables'   => $data['tables'],
			'unlinked' => $data['unlinked'],
		);
	}

	/** Evidence from the pages loaded as a visitor. */
	private static function activity_front_end( array $state, callable $add ): void {
		$probe   = $state['probe'];
		$checked = max( 1, (int) $probe['ok'] );
		$admin   = self::hook_footprint();

		foreach ( $probe['owners'] as $owner => $info ) {
			$pages = isset( $info['pages'] ) ? (int) $info['pages'] : 0;
			$where = $pages . ' of ' . $checked . ' checked page' . ( 1 === $checked ? '' : 's' );
			$head  = isset( $info['out']['wp_head'] ) ? (int) $info['out']['wp_head'] : 0;
			$body  = max( isset( $info['out']['wp_body_open'] ) ? (int) $info['out']['wp_body_open'] : 0, isset( $info['out']['wp_footer'] ) ? (int) $info['out']['wp_footer'] : 0 );
			if ( $head > 0 ) {
				$add( $owner, $head >= 300 ? 2 : 1, 'Adds to page <head>', 'Adds ' . size_format( $head ) . ' of code to the page <head> (' . $where . ')' );
			}
			if ( $body > 0 ) {
				$add( $owner, $body >= 300 ? 2 : 1, 'Adds to pages', 'Adds ' . size_format( $body ) . ' of HTML/scripts to the page body or footer (' . $where . ')' );
			}
			if ( ! empty( $info['out']['the_content'] ) ) {
				$add( $owner, 2, 'Changes page content', 'Changes the page content (' . $where . ')' );
			}
			if ( ! empty( $info['assets'] ) ) {
				$add( $owner, 1, 'Front-end CSS/JS', 'Loads ' . count( $info['assets'] ) . ' CSS/JS file(s) on the front end: ' . implode( ', ', array_slice( $info['assets'], 0, 5 ) ) . ( count( $info['assets'] ) > 5 ? '…' : '' ) . ' (' . $where . ')' );
			} elseif ( ! empty( $info['refs'] ) ) {
				$add( $owner, 1, 'Files in page HTML', 'Its files are referenced in the page HTML (' . $where . ')' );
			}
			foreach ( isset( $info['hooks'] ) ? $info['hooks'] : array() as $label ) {
				$admin[ $owner ][] = $label;
			}
		}
		foreach ( $admin as $owner => $labels ) {
			$labels = array_values( array_unique( $labels ) );
			$add( $owner, 1, 'Hooks: ' . $labels[0] . ( count( $labels ) > 1 ? ' +' . ( count( $labels ) - 1 ) : '' ), 'Hooks into: ' . implode( ', ', $labels ) );
		}
	}

	/** Behaviour that can be observed directly: login address, URL conversion, email, drop-ins, scheduled tasks. */
	private static function activity_behaviour( array $state, callable $add ): void {
		// Login page moved: run each login_url / site_url filter on the default address.
		$default = site_url( 'wp-login.php', 'login' );
		if ( false === strpos( (string) wp_parse_url( $default, PHP_URL_PATH ), 'wp-login.php' ) ) {
			$default = untrailingslashit( (string) get_option( 'siteurl' ) ) . '/wp-login.php';
		}
		$tests = array(
			'login_url' => array( $default, '', false ),
			'site_url'  => array( $default, 'wp-login.php', 'login', null ),
		);
		foreach ( $tests as $hook => $args ) {
			foreach ( self::isolated_results( $hook, $args ) as $result ) {
				if ( is_string( $result['value'] ) && '' !== $result['value'] && false === strpos( $result['value'], 'wp-login.php' ) ) {
					$add( $result['owner'], 2, 'Login page moved', 'Moves the login page to a custom address (wp-login.php is not used)' );
				}
			}
		}

		// Greek titles converted to Latin URLs (Greeklish). The sample must stay in Greek ("Good morning, world"):
		// a plugin counts only if it turns it into plain Latin characters, e.g. "kalimera-kosme".
		$sample = 'Καλημέρα κόσμε';
		foreach ( self::isolated_results( 'sanitize_title', array( $sample, $sample, 'save' ) ) as $result ) {
			$value = $result['value'];
			if ( is_string( $value ) && '' !== trim( $value ) && $value !== $sample && preg_match( '/^[\x20-\x7E]+$/', $value ) && preg_match( '/[A-Za-z]/', $value ) ) {
				$add( $result['owner'], 2, 'Greeklish URLs', 'Converts Greek titles to Latin URLs (“' . $sample . '” → “' . sanitize_title_with_dashes( $value ) . '”)' );
			}
		}

		// Email: a replaced wp_mail() or SMTP settings applied on phpmailer_init.
		if ( function_exists( 'wp_mail' ) ) {
			$owner = self::owner_from_file( (string) ( new ReflectionFunction( 'wp_mail' ) )->getFileName() );
			if ( self::is_trackable_owner( $owner ) ) {
				$add( $owner, 2, 'Sends the site’s email', 'Replaces WordPress’s email function, so all site email goes through it' );
			}
		}
		$smtp = self::hook_callbacks( 'phpmailer_init' );
		if ( $smtp ) {
			if ( ! class_exists( '\PHPMailer\PHPMailer\PHPMailer' ) ) {
				require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
				require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
				require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
			}
			foreach ( $smtp as $cb ) {
				$mailer = new \PHPMailer\PHPMailer\PHPMailer( true );
				try {
					call_user_func_array( $cb['function'], array( &$mailer ) );
				} catch ( \Throwable $e ) {
					continue;
				}
				if ( 'smtp' === strtolower( (string) $mailer->Mailer ) && '' !== (string) $mailer->Host ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
					$add( $cb['owner'], 2, 'SMTP email', 'Sends the site’s email through SMTP (' . sanitize_text_field( (string) $mailer->Host ) . ')' ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				}
			}
		}

		// Drop-ins in wp-content that a plugin installed.
		$dropins = array(
			'advanced-cache.php' => 'Page cache drop-in',
			'object-cache.php'   => 'Object cache drop-in',
			'db.php'             => 'Database drop-in',
		);
		foreach ( $dropins as $file => $label ) {
			$path = WP_CONTENT_DIR . '/' . $file;
			if ( ! is_readable( $path ) ) {
				continue;
			}
			$head = (string) file_get_contents( $path, false, null, 0, 16384 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			foreach ( self::plugin_list() as $folder => $plugin ) {
				if ( ! $plugin['active'] ) {
					continue;
				}
				if ( false !== stripos( $head, '/' . $folder . '/' ) || ( strlen( $plugin['name'] ) > 5 && false !== stripos( $head, $plugin['name'] ) ) ) {
					$on = 'advanced-cache.php' !== $file || ( defined( 'WP_CACHE' ) && WP_CACHE );
					$add( 'p:' . $folder, $on ? 2 : 1, $label, $label . ' installed in wp-content/' . $file . ( $on ? '' : ' (but WP_CACHE is off)' ) );
				}
			}
		}

		// Scheduled tasks (WP-Cron) handled by the plugin.
		if ( function_exists( '_get_cron_array' ) ) {
			$tasks = array();
			foreach ( (array) _get_cron_array() as $events ) {
				foreach ( array_keys( (array) $events ) as $hook ) {
					foreach ( self::hook_callbacks( (string) $hook ) as $cb ) {
						$tasks[ $cb['owner'] ][ (string) $hook ] = true;
					}
				}
			}
			foreach ( $tasks as $owner => $hooks ) {
				$names = array_keys( $hooks );
				$add( $owner, 1, 'Scheduled tasks', 'Runs ' . count( $names ) . ' scheduled task(s): ' . implode( ', ', array_slice( $names, 0, 4 ) ) . ( count( $names ) > 4 ? '…' : '' ) );
			}
		}
	}

	/**
	 * Runs each plugin callback of a filter on its own, with the filter emptied meanwhile, so a callback
	 * that calls the same function internally (e.g. sanitize_title()) is not credited with another's work.
	 */
	private static function isolated_results( string $hook, array $args ): array {
		global $wp_filter;
		$callbacks = self::hook_callbacks( $hook );
		if ( ! $callbacks ) {
			return array();
		}
		$saved              = $wp_filter[ $hook ];
		$wp_filter[ $hook ] = new WP_Hook(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		$results            = array();
		try {
			foreach ( $callbacks as $cb ) {
				try {
					$value = call_user_func_array( $cb['function'], array_slice( $args, 0, max( 1, $cb['args'] ) ) );
				} catch ( \Throwable $e ) {
					continue;
				}
				$results[] = array(
					'owner' => $cb['owner'],
					'value' => $value,
				);
			}
		} finally {
			$wp_filter[ $hook ] = $saved; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}
		return $results;
	}

	/** Plugins the active theme requires (TGM Plugin Activation) or companion plugins named after it. */
	private static function activity_theme( array $state, callable $add ): void {
		$theme  = wp_get_theme();
		$name   = (string) $theme->get( 'Name' );
		$slugs  = array_unique( array( get_stylesheet(), get_template() ) );
		if ( isset( $GLOBALS['tgmpa'] ) && is_object( $GLOBALS['tgmpa'] ) && isset( $GLOBALS['tgmpa']->plugins ) && is_array( $GLOBALS['tgmpa']->plugins ) ) {
			foreach ( $GLOBALS['tgmpa']->plugins as $slug => $info ) {
				$required = is_array( $info ) && ! empty( $info['required'] );
				$add( 'p:' . $slug, $required ? 2 : 1, $required ? 'Required by the theme' : 'Recommended by the theme', ( $required ? 'Required' : 'Recommended' ) . ' by the active theme (' . $name . ')' );
			}
		}
		foreach ( self::plugin_list() as $folder => $plugin ) {
			foreach ( $slugs as $slug ) {
				if ( strlen( $slug ) >= 4 && ( 0 === strpos( $folder, $slug . '-' ) || 0 === stripos( $plugin['name'], $name . ' ' ) ) ) {
					// "Theme Core", "Theme Elements"… usually hold the theme's own features; others (demo importers) do not.
					$core = (bool) preg_match( '/\b(core|addons?|elements?|extensions?|framework|functionality|toolkit|plugin)\b/i', $plugin['name'] . ' ' . str_replace( '-', ' ', $folder ) );
					$add( 'p:' . $folder, $core ? 2 : 1, 'Theme companion', 'Companion plugin of the active theme (' . $name . ')' );
				}
			}
		}
	}

	/** Content the plugin's own post types hold. */
	private static function activity_post_types( array $state, callable $add ): void {
		foreach ( $state['reg']['pt'] as $name => $info ) {
			list( $owner, $label, $items, $published, $public ) = $info;
			if ( (int) $items <= 0 ) {
				continue;
			}
			if ( $public && $published > 0 ) {
				$add( $owner, 2, 'Own content', number_format_i18n( (int) $published ) . ' published ' . $label . ' (public pages)' );
			} else {
				$add( $owner, 1, 'Own items', number_format_i18n( (int) $items ) . ' ' . $label );
			}
		}
	}

	/** Specific, reliable checks for plugins commonly found on client sites. */
	private static function activity_specific( array $state, callable $add ): void {
		global $wpdb;
		$plugins = self::plugin_list();
		$on      = static function ( string $folder ) use ( $plugins ): bool {
			return isset( $plugins[ $folder ] ) && $plugins[ $folder ]['active'];
		};
		$count   = static function ( string $sql ) use ( $wpdb ): int {
			$previous = $wpdb->suppress_errors( true );
			$value    = $wpdb->get_var( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->suppress_errors( $previous );
			return (int) $value;
		};
		$table_exists = static function ( string $table ) use ( $wpdb ): bool {
			return $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) );
		};

		foreach ( array( 'wordpress-seo', 'wordpress-seo-premium' ) as $folder ) {
			if ( $on( $folder ) ) {
				$n = $count( "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key IN ('_yoast_wpseo_title','_yoast_wpseo_metadesc','_yoast_wpseo_focuskw') AND meta_value <> ''" );
				if ( $n ) {
					$add( 'p:' . $folder, 2, 'SEO set on ' . $n . ' posts', 'SEO title, meta description or focus keyphrase set on ' . number_format_i18n( $n ) . ' posts/pages' );
				}
				$options = get_option( 'wpseo' );
				if ( is_array( $options ) && ! empty( $options['enable_xml_sitemap'] ) ) {
					$add( 'p:' . $folder, 2, 'XML sitemap', 'XML sitemap is enabled' );
				}
			}
		}
		foreach ( array( 'seo-by-rank-math', 'seo-by-rank-math-pro' ) as $folder ) {
			if ( $on( $folder ) ) {
				$n = $count( "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key IN ('rank_math_title','rank_math_description','rank_math_focus_keyword') AND meta_value <> ''" );
				if ( $n ) {
					$add( 'p:' . $folder, 2, 'SEO set on ' . $n . ' posts', 'SEO title, description or focus keyword set on ' . number_format_i18n( $n ) . ' posts/pages' );
				}
			}
		}
		if ( $on( 'redirection' ) && $table_exists( $wpdb->prefix . 'redirection_items' ) ) {
			$n = $count( "SELECT COUNT(*) FROM {$wpdb->prefix}redirection_items WHERE status = 'enabled'" );
			if ( $n ) {
				$add( 'p:redirection', 2, $n . ' redirects', number_format_i18n( $n ) . ' active redirects' );
			}
		}
		if ( $on( 'litespeed-cache' ) && get_option( 'litespeed.conf.cache' ) ) {
			$add( 'p:litespeed-cache', 2, 'Page cache on', 'Page caching is enabled' );
		}
		if ( $on( 'loco-translate' ) && is_dir( WP_LANG_DIR . '/loco' ) ) {
			$files = 0;
			$iter  = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( WP_LANG_DIR . '/loco', FilesystemIterator::SKIP_DOTS ) );
			foreach ( $iter as $file ) {
				if ( preg_match( '/\.(po|mo|l10n\.php)$/', $file->getFilename() ) && ++$files >= 5000 ) {
					break;
				}
			}
			if ( $files ) {
				$add( 'p:loco-translate', 2, 'Custom translations', number_format_i18n( $files ) . ' custom translation file(s) in wp-content/languages/loco' );
			}
		}
		if ( $on( 'translatepress-multilingual' ) ) {
			$settings  = get_option( 'trp_settings' );
			$languages = ( is_array( $settings ) && isset( $settings['translation-languages'] ) && is_array( $settings['translation-languages'] ) ) ? $settings['translation-languages'] : array();
			if ( count( $languages ) > 1 ) {
				$add( 'p:translatepress-multilingual', 2, 'Site translated', 'Site published in ' . count( $languages ) . ' languages (' . implode( ', ', array_map( 'sanitize_text_field', $languages ) ) . ')' );
			}
		}
		foreach ( array( 'secure-custom-fields', 'advanced-custom-fields', 'advanced-custom-fields-pro' ) as $folder ) {
			if ( $on( $folder ) ) {
				$n = $count( "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key LIKE '\\_%' AND meta_value LIKE 'field\\_%'" );
				if ( $n ) {
					$add( 'p:' . $folder, 2, 'Field values on ' . $n . ' posts', 'Custom field values saved on ' . number_format_i18n( $n ) . ' posts/pages' );
				}
			}
		}
		if ( $on( 'wordfence' ) && defined( 'WFWAF_AUTO_PREPEND' ) && WFWAF_AUTO_PREPEND ) {
			$add( 'p:wordfence', 2, 'Firewall on', 'Firewall is loaded before WordPress (extended protection)' );
		}
		if ( $on( 'updraftplus' ) ) {
			$interval = (string) get_option( 'updraft_interval' );
			if ( '' !== $interval && 'manual' !== $interval ) {
				$add( 'p:updraftplus', 2, 'Scheduled backups', 'Automatic backups scheduled (' . sanitize_text_field( $interval ) . ')' );
			}
		}
		if ( $on( 'akismet' ) && get_option( 'wordpress_api_key' ) ) {
			$add( 'p:akismet', 2, 'Spam filter on', 'Connected with an API key (comment/form spam filtering)' );
		}
		if ( $on( 'woocommerce' ) ) {
			$orders = $table_exists( $wpdb->prefix . 'wc_orders' )
				? $count( "SELECT COUNT(*) FROM {$wpdb->prefix}wc_orders WHERE type = 'shop_order'" )
				: $count( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'shop_order'" );
			if ( $orders ) {
				$add( 'p:woocommerce', 2, $orders . ' orders', number_format_i18n( $orders ) . ' orders' );
			}
		}
	}

	/** The plugin's own database tables, post meta and settings, matched by name. */
	private static function activity_data( callable $add ): array {
		global $wpdb;
		$tables   = array();
		$unlinked = array();

		$core = array_flip( $wpdb->tables( 'all', true ) );
		$rows = $wpdb->get_results( $wpdb->prepare( 'SHOW TABLE STATUS LIKE %s', $wpdb->esc_like( $wpdb->prefix ) . '%' ) );
		foreach ( (array) $rows as $row ) {
			$name = (string) $row->Name; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			if ( isset( $core[ $name ] ) || ( is_multisite() && preg_match( '/^' . preg_quote( $wpdb->prefix, '/' ) . '\d+_/', $name ) ) ) {
				continue;
			}
			$base   = substr( $name, strlen( $wpdb->prefix ) );
			$size   = (int) $row->Data_length + (int) $row->Index_length; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			$has    = (int) $row->Rows > 0 || null !== $wpdb->get_var( 'SELECT 1 FROM `' . str_replace( '`', '``', $name ) . '` LIMIT 1' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			$entry  = array( $base, (int) $row->Rows, $size, $has ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			$owners = self::data_owners( $base, true );
			if ( ! $owners ) {
				$unlinked[] = $entry;
				continue;
			}
			foreach ( $owners as $owner ) {
				$tables[ $owner ][] = $entry;
			}
		}
		foreach ( $tables as $owner => $list ) {
			$with_data = array_filter(
				$list,
				static function ( array $t ): bool {
					return $t[3];
				}
			);
			if ( $with_data ) {
				$names = array_map(
					static function ( array $t ): string {
						return $t[0] . ( $t[1] > 0 ? ' (~' . number_format_i18n( $t[1] ) . ' rows)' : '' );
					},
					array_slice( array_values( $with_data ), 0, 4 )
				);
				$add( $owner, 1, 'Own database tables', 'Keeps data in its own database tables: ' . implode( ', ', $names ) . ( count( $with_data ) > 4 ? '…' : '' ) );
			}
		}

		$meta = array();
		foreach ( (array) $wpdb->get_results( "SELECT meta_key, COUNT(*) AS n FROM {$wpdb->postmeta} GROUP BY meta_key" ) as $row ) {
			foreach ( self::data_owners( (string) $row->meta_key, false ) as $owner ) {
				$meta[ $owner ]['n']                        = ( isset( $meta[ $owner ]['n'] ) ? $meta[ $owner ]['n'] : 0 ) + (int) $row->n;
				$meta[ $owner ]['k'][ (string) $row->meta_key ] = (int) $row->n;
			}
		}
		foreach ( $meta as $owner => $info ) {
			arsort( $info['k'] );
			$add( $owner, 1, 'Data on posts', 'Stores ' . number_format_i18n( $info['n'] ) . ' values on posts (' . implode( ', ', array_slice( array_keys( $info['k'] ), 0, 3 ) ) . ( count( $info['k'] ) > 3 ? '…' : '' ) . ')' );
		}

		$options = array();
		foreach ( (array) $wpdb->get_col( "SELECT option_name FROM {$wpdb->options} WHERE option_name NOT LIKE '\\_%transient\\_%'" ) as $name ) {
			foreach ( self::data_owners( (string) $name, false ) as $owner ) {
				$options[ $owner ][] = (string) $name;
			}
		}
		foreach ( $options as $owner => $names ) {
			$add( $owner, 0, 'Settings', count( $names ) . ' saved setting(s): ' . implode( ', ', array_slice( $names, 0, 4 ) ) . ( count( $names ) > 4 ? '…' : '' ) );
		}

		return array(
			'tables'   => $tables,
			'unlinked' => $unlinked,
		);
	}

	/** Matches a table / meta key / option name to installed plugins by its prefix. */
	private static function data_owners( string $name, bool $is_table ): array {
		static $map = null;
		if ( null === $map ) {
			$map = array();
			foreach ( self::plugin_list() as $folder => $plugin ) {
				$base   = strtolower( (string) preg_replace( '/\.php$/', '', $folder ) );
				$tokens = array( str_replace( array( '-', '_', '.' ), '', $base ) => 'folder' );
				foreach ( preg_split( '/[-_.]+/', $base . '-' . strtolower( $plugin['td'] ) ) as $token ) {
					$tokens[ $token ] = isset( $tokens[ $token ] ) ? $tokens[ $token ] : 'word';
				}
				if ( preg_match_all( '/[a-z0-9]+/', strtolower( remove_accents( $plugin['name'] ) ), $m ) ) {
					foreach ( $m[0] as $token ) {
						$tokens[ $token ] = isset( $tokens[ $token ] ) ? $tokens[ $token ] : 'word';
					}
				}
				foreach ( isset( self::DATA_ALIASES[ $folder ] ) ? self::DATA_ALIASES[ $folder ] : array() as $token ) {
					$tokens[ $token ] = 'alias';
				}
				foreach ( $tokens as $token => $kind ) {
					if ( 'alias' !== $kind && ( strlen( (string) $token ) < 4 || in_array( (string) $token, self::DATA_STOPLIST, true ) ) ) {
						continue;
					}
					$map[ (string) $token ][ 'p:' . $folder ] = $kind;
				}
			}
		}
		$parts = preg_split( '/[_\-]+/', strtolower( ltrim( $name, '_' ) ) );
		if ( ! $parts || '' === $parts[0] ) {
			return array();
		}
		$candidates = array();
		if ( count( $parts ) >= 3 ) {
			$candidates[] = $parts[0] . $parts[1] . $parts[2];
		}
		if ( count( $parts ) >= 2 ) {
			$candidates[] = $parts[0] . '_' . $parts[1];
			$candidates[] = $parts[0] . $parts[1];
		}
		$candidates[] = $parts[0];
		foreach ( $candidates as $candidate ) {
			if ( ! isset( $map[ $candidate ] ) ) {
				continue;
			}
			if ( 'e' === $candidate && ! $is_table ) {
				continue; // Elementor's short table prefix is too short for meta keys and options.
			}
			$owners = $map[ $candidate ];
			foreach ( array( 'folder', 'alias' ) as $preferred ) {
				$best = array_keys( $owners, $preferred, true );
				if ( $best ) {
					return $best;
				}
			}
			return count( $owners ) <= 2 ? array_keys( $owners ) : array();
		}
		// "cookie_consent_logs" → folder "cookie-consent-banner": the name's start matches one plugin folder.
		if ( count( $parts ) >= 2 ) {
			$start   = $parts[0] . $parts[1];
			$matches = array();
			foreach ( array_keys( self::plugin_list() ) as $folder ) {
				if ( strlen( $start ) >= 8 && 0 === strpos( str_replace( array( '-', '_', '.' ), '', strtolower( $folder ) ), $start ) ) {
					$matches[] = 'p:' . $folder;
				}
			}
			if ( 1 === count( $matches ) ) {
				return $matches;
			}
		}
		return array();
	}

	/* ---------------------------------------------------------------------
	 * Turning the raw scan into the inventory
	 * ------------------------------------------------------------------- */

	private static function finalize( array $state ): array {
		$reg   = $state['reg'];
		$posts = $state['posts'];

		// Which places are actually shown to visitors.
		$embedded_by = array();
		foreach ( $posts as $id => $post ) {
			foreach ( isset( $post['r'] ) ? $post['r'] : array() as $ref ) {
				if ( $ref !== $id ) {
					$embedded_by[ $ref ][ $id ] = true;
				}
			}
		}
		$live = array();
		foreach ( $posts as $id => $post ) {
			if ( 'elementor_library' === $post['y'] ) {
				if ( 'publish' === $post['s'] && self::has_include_condition( isset( $post['cn'] ) ? $post['cn'] : array() ) ) {
					$live[ $id ] = 'conditions';
				}
			} elseif ( in_array( $post['y'], array( 'wp_template', 'wp_template_part' ), true ) ) {
				if ( 'publish' === $post['s'] ) {
					$live[ $id ] = 'theme';
				}
			} elseif ( 'wp_block' !== $post['y'] && in_array( $post['s'], array( 'publish', 'future' ), true ) ) {
				$live[ $id ] = 'published';
			}
		}
		$queue = array_keys( $live );
		while ( $queue ) {
			$id = array_pop( $queue );
			foreach ( isset( $posts[ $id ]['r'] ) ? $posts[ $id ]['r'] : array() as $ref ) {
				if ( isset( $posts[ $ref ] ) && ! isset( $live[ $ref ] ) && 'publish' === $posts[ $ref ]['s'] ) {
					$live[ $ref ] = 'embedded';
					$queue[]      = $ref;
				}
			}
		}

		// Map every found element to the plugin that provides it.
		$usage   = array();
		$orphans = array();
		$direct  = array();
		$mapped  = array();
		foreach ( $posts as $id => $post ) {
			foreach ( $post['k'] as $key => $count ) {
				$key = (string) $key;
				if ( ! isset( $mapped[ $key ] ) ) {
					$mapped[ $key ] = self::map_key( $key, $reg );
				}
				$map = $mapped[ $key ];
				if ( $map['orphan'] ) {
					self::add_orphan( $orphans, $key, $map, $id, $count );
					$direct[ $id ]['!'] = true;
					continue;
				}
				foreach ( $map['owners'] as $owner ) {
					$hit = array(
						'l' => $map['label'],
						'n' => $count,
					);
					if ( $map['probable'] ) {
						$hit['p'] = 1;
					}
					if ( 'p:elementor' !== $owner && ! empty( $post['c'][ $key ] ) ) {
						$hit['c'] = $post['c'][ $key ];
					}
					$usage[ $owner ][ $id ][] = $hit;
					$direct[ $id ][ $owner ]  = true;
				}
			}
		}

		$areas = array();
		self::scan_widget_areas( $reg, $areas, $usage, $orphans );

		// Per page/post: which plugins it uses, directly or through embedded templates.
		$index = array();
		foreach ( $posts as $id => $post ) {
			if ( ! in_array( $post['y'], array( 'page', 'post' ), true ) ) {
				continue;
			}
			$entry = array();
			foreach ( array_keys( isset( $direct[ $id ] ) ? $direct[ $id ] : array() ) as $owner ) {
				$entry[ $owner ] = 'd';
			}
			$seen  = array( $id => true );
			$stack = isset( $post['r'] ) ? $post['r'] : array();
			while ( $stack ) {
				$ref = array_pop( $stack );
				if ( isset( $seen[ $ref ] ) || ! isset( $posts[ $ref ] ) ) {
					continue;
				}
				$seen[ $ref ] = true;
				foreach ( array_keys( isset( $direct[ $ref ] ) ? $direct[ $ref ] : array() ) as $owner ) {
					if ( ! isset( $entry[ $owner ] ) ) {
						$entry[ $owner ] = 'v';
					}
				}
				foreach ( isset( $posts[ $ref ]['r'] ) ? $posts[ $ref ]['r'] : array() as $next ) {
					$stack[] = $next;
				}
			}
			if ( $entry ) {
				$index[ $id ] = $entry;
			}
		}

		// Keep only the posts the report needs.
		$keep = $index;
		foreach ( $usage as $locations ) {
			foreach ( array_keys( $locations ) as $loc ) {
				if ( is_int( $loc ) ) {
					$keep[ $loc ] = true;
				}
			}
		}
		foreach ( $orphans as $orphan ) {
			foreach ( array_keys( $orphan['at'] ) as $loc ) {
				if ( is_int( $loc ) ) {
					$keep[ $loc ] = true;
				}
			}
		}
		foreach ( array_keys( $keep ) as $id ) {
			foreach ( array_keys( isset( $embedded_by[ $id ] ) ? $embedded_by[ $id ] : array() ) as $from ) {
				$keep[ $from ] = true;
			}
		}
		$out_posts = array();
		foreach ( array_keys( $keep ) as $id ) {
			if ( ! isset( $posts[ $id ] ) ) {
				continue;
			}
			$post             = $posts[ $id ];
			$out_posts[ $id ] = array(
				't'    => $post['t'],
				'y'    => $post['y'],
				's'    => $post['s'],
				'e'    => ! empty( $post['e'] ),
				'live' => isset( $live[ $id ] ) ? $live[ $id ] : '',
				'by'   => array_keys( isset( $embedded_by[ $id ] ) ? $embedded_by[ $id ] : array() ),
				'tt'   => isset( $post['tt'] ) ? $post['tt'] : '',
				'cn'   => isset( $post['cn'] ) ? $post['cn'] : array(),
			);
		}

		return array(
			'v'           => self::VERSION,
			'time'        => time(),
			'duration'    => round( (float) $state['elapsed'], 1 ),
			'scanned'     => (int) $state['scanned'],
			'elementor'   => (int) $state['elementor'],
			'undecodable' => $state['undecodable'],
			'probe'       => array(
				'via'    => $state['probe']['via'],
				'tried'  => $state['probe']['tried'],
				'ok'     => $state['probe']['ok'],
				'pages'  => $state['probe']['pages'],
				'errors' => array_slice( $state['probe']['errors'], 0, 5 ),
			),
			'activity'    => isset( $state['activity']['act'] ) ? $state['activity']['act'] : array(),
			'tables'      => isset( $state['activity']['tables'] ) ? $state['activity']['tables'] : array(),
			'unlinked'    => isset( $state['activity']['unlinked'] ) ? $state['activity']['unlinked'] : array(),
			'active'      => $state['active'],
			'provides'    => self::summarize_provides( $reg ),
			'usage'       => $usage,
			'orphans'     => $orphans,
			'posts'       => $out_posts,
			'areas'       => $areas,
			'index'       => $index,
		);
	}

	private static function map_key( string $key, array $reg ): array {
		$kind = $key[0];
		$name = (string) substr( $key, 2 );
		$res  = array(
			'owners'   => array(),
			'probable' => false,
			'orphan'   => false,
			'label'    => $name,
			'hint'     => '',
		);
		switch ( $kind ) {
			case 'w':
				if ( isset( $reg['w'][ $name ] ) ) {
					$res['owners'] = array( $reg['w'][ $name ][0] );
					$res['label']  = 'Elementor widget: ' . $reg['w'][ $name ][1] . ' (' . $name . ')';
				} else {
					$token        = self::token_of( $name );
					$res['label'] = 'Elementor widget: ' . $name;
					if ( '' !== $token && ! empty( $reg['tokens'][ $token ] ) ) {
						$res['owners']   = $reg['tokens'][ $token ];
						$res['probable'] = true;
						$res['label']   .= ' — not registered (switched off in the plugin’s settings?)';
					} else {
						$res['orphan'] = true;
						$res['hint']   = self::hint_for( $key );
					}
				}
				break;
			case 's':
				$res['owners'] = array( isset( $reg['sc'][ $name ] ) ? $reg['sc'][ $name ] : '' );
				$res['label']  = 'Shortcode [' . $name . ']';
				break;
			case 'u':
				$res['orphan'] = true;
				$res['label']  = 'Shortcode [' . $name . ']';
				$res['hint']   = self::hint_for( $key );
				break;
			case 'b':
				$res['label'] = 'Block ' . $name;
				if ( isset( $reg['b'][ $name ] ) ) {
					$res['owners'] = array( $reg['b'][ $name ] );
				} else {
					$owner = self::owner_from_slug( (string) strtok( $name, '/' ), true );
					if ( '' !== $owner ) {
						$res['owners']   = array( $owner );
						$res['probable'] = true;
						$res['label']   .= ' — not registered';
					} else {
						$res['orphan'] = true;
						$res['hint']   = self::hint_for( $key );
					}
				}
				break;
			case 'd':
				$res['label'] = 'Elementor dynamic tag: ' . $name;
				if ( isset( $reg['d'][ $name ] ) ) {
					$res['owners'] = array( $reg['d'][ $name ] );
				} else {
					$res['orphan'] = true;
					$res['hint']   = self::hint_for( $key );
				}
				break;
			case 'x':
				$res['owners']   = isset( $reg['tokens'][ $name ] ) ? $reg['tokens'][ $name ] : array();
				$res['probable'] = count( $res['owners'] ) > 1;
				$res['label']    = 'Elementor extension settings (' . $name . '_…)';
				break;
		}
		$res['owners'] = array_values( array_filter( array_unique( $res['owners'] ), array( __CLASS__, 'is_trackable_owner' ) ) );
		return $res;
	}

	/** @param int|string $loc */
	private static function add_orphan( array &$orphans, string $key, array $map, $loc, int $count ): void {
		if ( ! isset( $orphans[ $key ] ) ) {
			$orphans[ $key ] = array(
				'l'  => $map['label'],
				'h'  => $map['hint'],
				'at' => array(),
			);
		}
		$orphans[ $key ]['at'][ $loc ] = ( isset( $orphans[ $key ]['at'][ $loc ] ) ? $orphans[ $key ]['at'][ $loc ] : 0 ) + $count;
	}

	/** Best guess for elements no active plugin provides: [label, folder slugs]. */
	private static function hint_for( string $key ): string {
		$guess = self::hint_entry( $key );
		return $guess ? $guess[0] : '';
	}

	private static function hint_entry( string $key ): ?array {
		$kind = $key[0];
		$name = strtolower( (string) substr( $key, 2 ) );
		if ( 'w' === $kind ) {
			if ( in_array( $name, self::ELEMENTOR_PRO_WIDGETS, true ) || preg_match( '/^(theme|woocommerce|facebook)-/', $name ) ) {
				return self::HINTS['w:elementor-pro'];
			}
			$token = self::token_of( $name );
			return isset( self::HINTS[ 'w:' . $token ] ) ? self::HINTS[ 'w:' . $token ] : null;
		}
		if ( 's' === $kind || 'u' === $kind ) {
			foreach ( self::HINTS as $hint_key => $hint ) {
				if ( 0 === strpos( $hint_key, 's:' ) && 0 === strpos( $name, substr( $hint_key, 2 ) ) ) {
					return $hint;
				}
			}
			return null;
		}
		if ( 'd' === $kind ) {
			$token = self::token_of( $name );
			return isset( self::HINTS[ 'd:' . $token ] ) ? self::HINTS[ 'd:' . $token ] : null;
		}
		if ( 'b' === $kind ) {
			$ns = (string) strtok( $name, '/' );
			foreach ( self::plugin_list() as $folder => $plugin ) {
				if ( $ns === $folder || $ns === $plugin['td'] || 0 === strpos( $folder, $ns . '-' ) ) {
					return array( $plugin['name'], array( $folder ) );
				}
			}
			return array( $ns, array( $ns ) );
		}
		return null;
	}

	private static function has_include_condition( array $conditions ): bool {
		foreach ( $conditions as $condition ) {
			if ( is_string( $condition ) && 0 === strpos( $condition, 'include/' ) ) {
				return true;
			}
		}
		return false;
	}

	private static function scan_widget_areas( array $reg, array &$areas, array &$usage, array &$orphans ): void {
		if ( ! function_exists( 'wp_get_sidebars_widgets' ) ) {
			return;
		}
		global $wp_registered_sidebars;
		$context = array(
			'sc_regex' => self::shortcode_regex( array_keys( $reg['sc'] ) ),
			'sc_set'   => $reg['sc'],
			'tokens'   => array(),
			'widgets'  => array(),
		);
		foreach ( (array) wp_get_sidebars_widgets() as $sidebar => $widgets ) {
			if ( 'wp_inactive_widgets' === $sidebar || 'array_version' === $sidebar || ! is_array( $widgets ) || empty( $widgets ) ) {
				continue;
			}
			$registered        = isset( $wp_registered_sidebars[ $sidebar ] );
			$loc               = 'sb:' . $sidebar;
			$areas[ $sidebar ] = array(
				't'    => $registered ? wp_strip_all_tags( (string) $wp_registered_sidebars[ $sidebar ]['name'] ) : (string) $sidebar,
				'live' => $registered && 0 !== strpos( (string) $sidebar, 'orphaned_widgets' ),
			);
			foreach ( $widgets as $widget_id ) {
				if ( ! preg_match( '/^(.+)-(\d+)$/', (string) $widget_id, $m ) ) {
					continue;
				}
				$base = $m[1];
				$keys = array();
				$refs = array();
				if ( in_array( $base, array( 'block', 'text', 'custom_html' ), true ) ) {
					$instances = get_option( 'widget_' . $base );
					$instance  = ( is_array( $instances ) && isset( $instances[ (int) $m[2] ] ) && is_array( $instances[ (int) $m[2] ] ) ) ? $instances[ (int) $m[2] ] : array();
					foreach ( array( 'content', 'text' ) as $field ) {
						if ( ! empty( $instance[ $field ] ) && is_string( $instance[ $field ] ) ) {
							self::scan_string( $instance[ $field ], $keys, $refs, $context, true );
						}
					}
				} elseif ( isset( $reg['ww'][ $base ] ) ) {
					$owner = $reg['ww'][ $base ][0];
					if ( self::is_trackable_owner( $owner ) ) {
						self::add_area_hit( $usage, $owner, $loc, 'Widget: ' . $reg['ww'][ $base ][1] );
					}
				} else {
					self::add_orphan(
						$orphans,
						'v:' . $base,
						array(
							'label' => 'Widget “' . $base . '”',
							'hint'  => '',
						),
						$loc,
						1
					);
				}
				foreach ( $keys as $key => $count ) {
					$map = self::map_key( (string) $key, $reg );
					if ( $map['orphan'] ) {
						self::add_orphan( $orphans, (string) $key, $map, $loc, $count );
						continue;
					}
					foreach ( $map['owners'] as $owner ) {
						self::add_area_hit( $usage, $owner, $loc, $map['label'], $count );
					}
				}
			}
		}
	}

	private static function add_area_hit( array &$usage, string $owner, string $loc, string $label, int $count = 1 ): void {
		foreach ( isset( $usage[ $owner ][ $loc ] ) ? $usage[ $owner ][ $loc ] : array() as $i => $hit ) {
			if ( $hit['l'] === $label ) {
				$usage[ $owner ][ $loc ][ $i ]['n'] += $count;
				return;
			}
		}
		$usage[ $owner ][ $loc ][] = array(
			'l' => $label,
			'n' => $count,
		);
	}

	private static function summarize_provides( array $reg ): array {
		$prov = array();
		foreach ( $reg['w'] as $name => $info ) {
			if ( self::is_trackable_owner( $info[0] ) && 0 !== strpos( (string) $name, 'wp-widget-' ) ) {
				$prov[ $info[0] ]['w'][ $name ] = $info[1];
			}
		}
		foreach ( $reg['sc'] as $tag => $owner ) {
			if ( self::is_trackable_owner( $owner ) ) {
				$prov[ $owner ]['sc'][] = $tag;
			}
		}
		foreach ( $reg['b'] as $name => $owner ) {
			if ( self::is_trackable_owner( $owner ) ) {
				$prov[ $owner ]['b'][] = $name;
			}
		}
		foreach ( $reg['d'] as $name => $owner ) {
			if ( self::is_trackable_owner( $owner ) ) {
				$prov[ $owner ]['d'][] = $name;
			}
		}
		foreach ( $reg['ww'] as $base => $info ) {
			if ( self::is_trackable_owner( $info[0] ) ) {
				$prov[ $info[0] ]['ww'][ $base ] = $info[1];
			}
		}
		foreach ( $reg['pt'] as $name => $info ) {
			if ( self::is_trackable_owner( $info[0] ) ) {
				$prov[ $info[0] ]['pt'][ $name ] = array( $info[1], $info[2], $info[3], $info[4] );
			}
		}
		foreach ( $reg['tokens'] as $token => $owners ) {
			foreach ( $owners as $owner ) {
				$prov[ $owner ]['x'][] = $token;
			}
		}
		return $prov;
	}

	private static function get_result(): ?array {
		if ( false === self::$result_cache ) {
			$result             = get_option( self::OPT_RESULT );
			self::$result_cache = ( is_array( $result ) && isset( $result['v'], $result['usage'] ) ) ? $result : null;
		}
		return self::$result_cache;
	}

	/* ---------------------------------------------------------------------
	 * Verdict per plugin
	 * ------------------------------------------------------------------- */

	private static function plugin_rows( array $r ): array {
		if ( null !== self::$rows_cache ) {
			return self::$rows_cache;
		}
		$plugins = self::plugin_list();

		$dependents = array();
		foreach ( $plugins as $folder => $plugin ) {
			if ( ! $plugin['active'] ) {
				continue;
			}
			$requires = $plugin['requires'];
			if ( 'elementor' !== $folder && isset( $r['provides'][ 'p:' . $folder ]['w'] ) && count( $r['provides'][ 'p:' . $folder ]['w'] ) >= 3 ) {
				$requires[] = 'elementor';
			}
			foreach ( array_unique( $requires ) as $slug ) {
				$dependents[ $slug ][] = $plugin['name'];
			}
		}

		$leftovers = array();
		foreach ( $r['orphans'] as $key => $orphan ) {
			$entry = self::hint_entry( (string) $key );
			if ( ! $entry ) {
				continue;
			}
			foreach ( $plugins as $folder => $plugin ) {
				foreach ( $entry[1] as $slug ) {
					$match = '*' === substr( $slug, -1 ) ? 0 === strpos( $folder, rtrim( $slug, '*' ) ) : $folder === $slug;
					if ( $match ) {
						$leftovers[ $folder ][ $key ] = $orphan;
					}
				}
			}
		}

		$rows = array();
		foreach ( $plugins as $folder => $plugin ) {
			$owner = 'p:' . $folder;
			if ( self::self_owner() === $owner ) {
				continue;
			}
			$usage      = isset( $r['usage'][ $owner ] ) ? $r['usage'][ $owner ] : array();
			$prov       = isset( $r['provides'][ $owner ] ) ? $r['provides'][ $owner ] : array();
			$was_active = in_array( $owner, $r['active'], true );
			$live       = array();
			$hidden     = array();
			$sitewide   = false;
			foreach ( array_keys( $usage ) as $loc ) {
				if ( self::loc_is_live( $loc, $r ) ) {
					$live[]   = $loc;
					$sitewide = $sitewide || self::loc_is_sitewide( $loc, $r );
				} else {
					$hidden[] = $loc;
				}
			}
			$activity  = isset( $r['activity'][ $owner ] ) ? $r['activity'][ $owner ] : array();
			$needed_by = isset( $dependents[ $folder ] ) ? array_values( array_unique( $dependents[ $folder ] ) ) : array();
			if ( $needed_by ) {
				array_unshift(
					$activity,
					array(
						's'  => 2,
						'sh' => 'Needed by other plugins',
						'l'  => 'Other active plugins need it: ' . implode( ', ', $needed_by ),
					)
				);
			}
			$strong = 0;
			$medium = 0;
			foreach ( $activity as $evidence ) {
				$strong += 2 === $evidence['s'] ? 1 : 0;
				$medium += 1 === $evidence['s'] ? 1 : 0;
			}

			if ( ! $plugin['active'] ) {
				$verdict = 'inactive';
			} elseif ( ! $was_active ) {
				$verdict = 'rescan';
			} elseif ( $live ) {
				$verdict = 'used';
			} elseif ( $strong ) {
				$verdict = 'active';
			} elseif ( $hidden ) {
				$verdict = 'hidden';
			} elseif ( $medium ) {
				$verdict = 'quiet';
			} else {
				$verdict = 'unused';
			}

			$data_left = array();
			foreach ( isset( $r['tables'][ $owner ] ) ? $r['tables'][ $owner ] : array() as $table ) {
				if ( $table[3] ) {
					$data_left[] = $table;
				}
			}

			$left_locs = array();
			foreach ( isset( $leftovers[ $folder ] ) ? $leftovers[ $folder ] : array() as $orphan ) {
				foreach ( array_keys( $orphan['at'] ) as $loc ) {
					$left_locs[ (string) $loc ] = true;
				}
			}

			$rows[ $folder ] = array(
				'folder'      => $folder,
				'owner'       => $owner,
				'plugin'      => $plugin,
				'verdict'     => $verdict,
				'usage'       => $usage,
				'prov'        => $prov,
				'live'        => $live,
				'hidden'      => $hidden,
				'sitewide'    => $sitewide,
				'activity'    => $activity,
				'strong'      => $strong,
				'data_left'   => $data_left,
				'dependents'  => $needed_by,
				'leftovers'   => isset( $leftovers[ $folder ] ) ? $leftovers[ $folder ] : array(),
				'left_count'  => count( $left_locs ),
			);
		}
		self::$rows_cache = $rows;
		return $rows;
	}

	/** @param int|string $loc */
	private static function loc_is_live( $loc, array $r ): bool {
		if ( is_string( $loc ) && 0 === strpos( $loc, 'sb:' ) ) {
			$area = substr( $loc, 3 );
			return ! empty( $r['areas'][ $area ]['live'] );
		}
		return ! empty( $r['posts'][ $loc ]['live'] );
	}

	/** @param int|string $loc */
	private static function loc_is_sitewide( $loc, array $r ): bool {
		if ( is_string( $loc ) && 0 === strpos( $loc, 'sb:' ) ) {
			return true;
		}
		return isset( $r['posts'][ $loc ] ) && in_array( $r['posts'][ $loc ]['live'], array( 'conditions', 'theme' ), true );
	}

	/* ---------------------------------------------------------------------
	 * Admin page
	 * ------------------------------------------------------------------- */

	public static function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'aboutnet-plugin-usage-scanner' ) );
		}
		$tab = ( isset( $_GET['tab'] ) && 'search' === sanitize_key( wp_unslash( $_GET['tab'] ) ) ) ? 'search' : 'inventory'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<div class="wrap pus-wrap">
			<h1>Plugin Usage Scanner</h1>
			<nav class="nav-tab-wrapper" aria-label="Scanner sections">
				<a href="<?php echo esc_url( self::page_url() ); ?>" class="nav-tab<?php echo 'inventory' === $tab ? ' nav-tab-active' : ''; ?>"<?php echo 'inventory' === $tab ? ' aria-current="page"' : ''; ?>>Plugin inventory</a>
				<a href="<?php echo esc_url( self::page_url( array( 'tab' => 'search' ) ) ); ?>" class="nav-tab<?php echo 'search' === $tab ? ' nav-tab-active' : ''; ?>"<?php echo 'search' === $tab ? ' aria-current="page"' : ''; ?>>Custom search</a>
			</nav>
			<?php
			if ( 'search' === $tab ) {
				self::render_search_tab();
			} else {
				self::render_inventory_tab();
			}
			?>
		</div>
		<?php
	}

	private static function render_inventory_tab(): void {
		$state = get_option( self::OPT_STATE );
		if ( is_array( $state ) && self::VERSION === ( $state['v'] ?? '' ) ) {
			self::render_progress( $state, isset( $_GET['pus_step'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		$r = self::get_result();
		if ( isset( $_GET['scanned'] ) && $r ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			printf( '<div class="notice notice-success is-dismissible"><p>Scan finished: %s items checked in %s s.</p></div>', esc_html( number_format_i18n( $r['scanned'] ) ), esc_html( number_format_i18n( $r['duration'], 1 ) ) );
		}
		?>
		<div class="pus-top-panel">
			<p style="margin-top:0;">For every installed plugin: <strong>where its elements are used</strong> (Elementor widgets, shortcodes, blocks, widgets) and <strong>what it does on the site</strong> (output on pages, login, email, URLs, cache, its own data). Nothing is changed on the site.</p>
			<form method="post" action="<?php echo esc_url( self::page_url() ); ?>" id="pus-scan-form" data-probe-urls="<?php echo esc_attr( (string) wp_json_encode( self::probe_urls() ) ); ?>" data-plugins-path="<?php echo esc_attr( (string) wp_parse_url( plugins_url( '/' ), PHP_URL_PATH ) ); ?>">
				<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME ); ?>
				<input type="hidden" name="pus_action" value="scan_start">
				<input type="hidden" name="pus_probe" value="">
				<?php submit_button( $r ? 'Scan again' : 'Scan site', 'primary', 'pus_scan', false ); ?>
				<span id="pus-probe-status" class="pus-muted" role="status" aria-live="polite" style="margin-left:10px;"></span>
				<?php if ( $r ) : ?>
					<span class="pus-muted pus-last-scan">
						Last scan: <?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $r['time'] ) ); ?>
						(<?php echo esc_html( human_time_diff( (int) $r['time'] ) ); ?> ago) · <?php echo esc_html( number_format_i18n( $r['scanned'] ) ); ?> items · <?php echo esc_html( number_format_i18n( $r['elementor'] ) ); ?> built with Elementor
					</span>
				<?php endif; ?>
			</form>
			<?php if ( $r && self::VERSION === $r['v'] && isset( $r['probe'] ) ) : ?>
				<?php if ( $r['probe']['ok'] > 0 ) : ?>
					<p class="pus-muted pus-small" style="margin-bottom:0;">Front end checked as a visitor on <?php echo esc_html( (string) $r['probe']['ok'] ); ?> page(s)<?php echo 'server' === $r['probe']['via'] ? ' (from the server)' : ''; ?>: <?php echo esc_html( implode( ' · ', $r['probe']['pages'] ) ); ?></p>
				<?php else : ?>
					<p class="pus-warn">The front end could not be checked<?php echo $r['probe']['errors'] ? ' (' . esc_html( $r['probe']['errors'][0] ) . ')' : ''; ?>. Output on pages is not part of these results; scan again from a browser that can open the site.</p>
				<?php endif; ?>
			<?php endif; ?>
			<?php if ( $r && self::VERSION !== $r['v'] ) : ?>
				<p class="pus-warn">These results come from an older version of the scanner. Scan again to see them.</p>
			<?php endif; ?>
		</div>
		<script>
		(function () {
			var form = document.getElementById('pus-scan-form');
			if (!form || !window.fetch) { return; }
			var status = document.getElementById('pus-probe-status');
			var field = form.querySelector('input[name="pus_probe"]');
			var urls = [];
			try { urls = JSON.parse(form.getAttribute('data-probe-urls') || '[]'); } catch (e) { urls = []; }
			var base = form.getAttribute('data-plugins-path') || '/wp-content/plugins/';
			function esc(text) { return text.replace(/[.*+?^${}()|[\]\\\/]/g, '\\$&'); }
			var pathRe = new RegExp('(?:' + esc(base) + '|' + esc(base.replace(/\//g, '\\/')) + ')([A-Za-z0-9._-]+)(?:/|\\\\/)', 'g');
			function load(url, credentials) {
				var ctrl = window.AbortController ? new AbortController() : null;
				var timer = ctrl ? setTimeout(function () { ctrl.abort(); }, 20000) : null;
				return fetch(url, { credentials: credentials, cache: 'no-store', redirect: 'follow', signal: ctrl ? ctrl.signal : undefined })
					.then(function (res) { return res.text().then(function (html) { if (timer) { clearTimeout(timer); } return { s: res.status, html: html }; }); });
			}
			function read(url, res) {
				var m = res.html.match(/<script type="application\/json" id="aboutnet-pus-probe">([\s\S]*?)<\/script>/);
				var data = null;
				if (m) { try { data = JSON.parse(m[1]); } catch (e) { data = null; } }
				var paths = {}, found;
				pathRe.lastIndex = 0;
				while ((found = pathRe.exec(res.html))) { paths[found[1]] = (paths[found[1]] || 0) + 1; }
				return { u: url, s: res.s, d: data, p: paths };
			}
			function probe(url) {
				// First as an anonymous visitor; if the page needs a login or HTTP auth, again with the admin's session.
				return load(url, 'omit').then(function (res) {
					var first = read(url, res);
					if (first.d) { return first; }
					return load(url, 'same-origin').then(function (res2) { var second = read(url, res2); return second.d ? second : first; });
				}).catch(function (err) { return { u: url, s: 0, d: null, p: {}, e: String((err && err.message) || err) }; });
			}
			form.addEventListener('submit', function (event) {
				if (form.getAttribute('data-probed') === '1' || !urls.length) { return; }
				event.preventDefault();
				var button = form.querySelector('[type="submit"]');
				if (button) { button.disabled = true; }
				var results = [], i = 0;
				(function next() {
					if (i >= urls.length) {
						field.value = JSON.stringify(results);
						form.setAttribute('data-probed', '1');
						if (status) { status.textContent = 'Scanning content…'; }
						HTMLFormElement.prototype.submit.call(form);
						return;
					}
					var url = urls[i++];
					if (status) { status.textContent = 'Checking the site as a visitor (' + i + ' of ' + urls.length + ')…'; }
					probe(url).then(function (result) { results.push(result); next(); });
				})();
			});
		})();
		</script>
		<?php
		if ( $r && self::VERSION === $r['v'] ) {
			self::render_inventory( $r );
		}
	}

	private static function short_url( string $url ): string {
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		return '' === $path || '/' === $path ? 'home page' : urldecode( untrailingslashit( $path ) );
	}

	private static function render_progress( array $state, bool $auto ): void {
		$total = max( 1, (int) $state['total'] );
		$pct   = min( 100, (int) floor( (int) $state['scanned'] / $total * 100 ) );
		?>
		<div class="pus-top-panel">
			<h2 style="margin-top:0;"><?php echo $auto ? 'Scanning…' : 'A scan was interrupted'; ?></h2>
			<p>Checked <?php echo esc_html( number_format_i18n( (int) $state['scanned'] ) ); ?> of about <?php echo esc_html( number_format_i18n( $total ) ); ?> items.</p>
			<progress max="100" value="<?php echo esc_attr( (string) $pct ); ?>" style="width:100%;max-width:520px;height:18px;" aria-label="Scan progress"><?php echo esc_html( $pct . '%' ); ?></progress>
			<div style="margin-top:12px;display:flex;gap:10px;align-items:center;">
				<form id="pus-continue" method="post" action="<?php echo esc_url( self::page_url() ); ?>">
					<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME ); ?>
					<input type="hidden" name="pus_action" value="scan_continue">
					<?php submit_button( 'Continue', $auto ? 'secondary' : 'primary', 'pus_continue', false ); ?>
				</form>
				<form method="post" action="<?php echo esc_url( self::page_url() ); ?>">
					<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME ); ?>
					<input type="hidden" name="pus_action" value="scan_cancel">
					<button type="submit" class="button-link">Cancel scan</button>
				</form>
			</div>
			<?php if ( $auto ) : ?>
				<p class="pus-muted pus-small">The scan runs in short steps so the site stays responsive. Keep this tab open.</p>
				<script>setTimeout(function () { var f = document.getElementById('pus-continue'); if (f) { HTMLFormElement.prototype.submit.call(f); } }, 250);</script>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function render_inventory( array $r ): void {
		if ( function_exists( '_prime_post_caches' ) && ! empty( $r['posts'] ) ) {
			_prime_post_caches( array_map( 'intval', array_keys( $r['posts'] ) ), false, false ); // One query instead of one per link.
		}
		$rows   = self::plugin_rows( $r );
		$counts = array_fill_keys( array_keys( self::VERDICTS ), 0 );
		foreach ( $rows as $row ) {
			++$counts[ $row['verdict'] ];
		}
		?>
		<div class="pus-toolbar">
			<div class="pus-chips" role="group" aria-label="Filter plugins">
				<button type="button" class="pus-chip is-active" data-filter="all" aria-pressed="true">All <span><?php echo esc_html( (string) count( $rows ) ); ?></span></button>
				<?php foreach ( self::VERDICTS as $key => $verdict ) : ?>
					<?php if ( $counts[ $key ] ) : ?>
						<button type="button" class="pus-chip" data-filter="<?php echo esc_attr( $key ); ?>" aria-pressed="false" title="<?php echo esc_attr( $verdict[1] ); ?>"><span class="pus-dot pus-v-<?php echo esc_attr( $key ); ?>"></span><?php echo esc_html( $verdict[0] ); ?> <span><?php echo esc_html( (string) $counts[ $key ] ); ?></span></button>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
			<label class="screen-reader-text" for="pus-q">Search plugins</label>
			<input type="search" id="pus-q" class="pus-search" placeholder="Search plugins…">
		</div>

		<table class="widefat pus-inv">
			<thead>
				<tr>
					<th scope="col">Plugin</th>
					<th scope="col">Result</th>
					<th scope="col">What it adds</th>
					<th scope="col">Where / how it is used</th>
					<th scope="col"><span class="screen-reader-text">Details</span></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $rows as $row ) : ?>
					<?php self::render_plugin_row( $row, $r ); ?>
				<?php endforeach; ?>
			</tbody>
		</table>

		<?php self::render_orphans( $r ); ?>
		<?php self::render_unlinked_tables( $r ); ?>

		<?php if ( ! empty( $r['undecodable'] ) ) : ?>
			<div class="notice notice-warning inline" style="margin-top:16px;"><p>
				<?php echo esc_html( count( $r['undecodable'] ) ); ?> Elementor page(s) have damaged layout data and were checked by widget names only (no positions):
				<?php echo wp_kses_post( implode( ', ', array_map( array( __CLASS__, 'post_link_html' ), array_slice( $r['undecodable'], 0, 10 ) ) ) ); ?>
			</p></div>
		<?php endif; ?>

		<details class="pus-advanced" style="margin-top:18px;">
			<summary>What the scan can and cannot see</summary>
			<div class="pus-hint-box" style="margin-top:8px;">
				<p style="margin-top:0;"><strong>Page elements:</strong> all content (pages, posts, products, custom post types, Elementor templates, theme templates, reusable blocks), the Elementor layout of every page built with it, templates embedded in pages or shown by display conditions, and the theme’s widget areas.</p>
				<p><strong>What plugins do:</strong> a few live pages are opened as a visitor and every plugin’s output is measured; the login address, Greek-to-Latin URL conversion and email sending are tested; drop-ins, scheduled tasks, theme requirements, each plugin’s database tables, post data and settings are checked, plus specific checks for common plugins (Yoast, Rank Math, Redirection, LiteSpeed, Loco, TranslatePress, ACF/SCF, Wordfence, UpdraftPlus, Akismet, WooCommerce).</p>
				<p><strong>Not visible to it:</strong> things that happen only on other pages or occasionally (e.g. a redirect on one URL, an email on checkout), shortcodes called from theme PHP files, and menus. <em>Background only</em> means it hooks into WordPress or keeps data — a human decides whether that is still needed.</p>
				<p style="margin-bottom:0;"><strong>Before deleting:</strong> take a backup, <em>deactivate</em> the plugin first, clear caches and check the pages listed here. Delete only after the site looks right.</p>
			</div>
		</details>

		<script>
		(function () {
			var chips = document.querySelectorAll('.pus-chip');
			var rows = document.querySelectorAll('tr.pus-row');
			var search = document.getElementById('pus-q');
			var filter = 'all';
			function apply() {
				var term = (search && search.value || '').toLowerCase().trim();
				rows.forEach(function (row) {
					var show = (filter === 'all' || row.getAttribute('data-verdict') === filter) && (!term || row.getAttribute('data-name').indexOf(term) !== -1);
					row.hidden = !show;
					var details = document.getElementById(row.getAttribute('data-details'));
					if (details && !show) { details.hidden = true; var b = row.querySelector('.pus-toggle'); if (b) { b.setAttribute('aria-expanded', 'false'); b.textContent = 'Details'; } }
				});
			}
			chips.forEach(function (chip) {
				chip.addEventListener('click', function () {
					filter = chip.getAttribute('data-filter');
					chips.forEach(function (c) { var on = c === chip; c.classList.toggle('is-active', on); c.setAttribute('aria-pressed', on ? 'true' : 'false'); });
					apply();
				});
			});
			if (search) { search.addEventListener('input', apply); }
			document.querySelectorAll('.pus-toggle').forEach(function (button) {
				button.addEventListener('click', function () {
					var details = document.getElementById(button.getAttribute('aria-controls'));
					if (!details) { return; }
					var open = details.hidden;
					details.hidden = !open;
					button.setAttribute('aria-expanded', open ? 'true' : 'false');
					button.textContent = open ? 'Hide' : 'Details';
				});
			});
			if (window.location.hash) {
				var target = document.getElementById(window.location.hash.slice(1));
				if (target) {
					var toggle = target.querySelector('.pus-toggle');
					if (toggle && toggle.getAttribute('aria-expanded') !== 'true') { toggle.click(); }
					target.scrollIntoView({ block: 'center' });
				}
			}
		})();
		</script>
		<?php
	}

	private static function render_plugin_row( array $row, array $r ): void {
		$plugin  = $row['plugin'];
		$verdict = $row['verdict'];
		$anchor  = 'pus-plugin-' . sanitize_html_class( $row['folder'] );
		$details = 'pus-details-' . sanitize_html_class( $row['folder'] );
		?>
		<tr class="pus-row" id="<?php echo esc_attr( $anchor ); ?>" data-verdict="<?php echo esc_attr( $verdict ); ?>" data-name="<?php echo esc_attr( strtolower( $plugin['name'] . ' ' . $row['folder'] ) ); ?>" data-details="<?php echo esc_attr( $details ); ?>">
			<td>
				<span class="pus-name"><?php echo esc_html( $plugin['name'] ); ?></span>
				<div class="pus-muted pus-small"><?php echo esc_html( $row['folder'] . ( '' !== $plugin['version'] ? ' · v' . $plugin['version'] : '' ) ); ?> · <?php echo $plugin['active'] ? 'Active' : 'Inactive'; ?></div>
				<?php if ( $row['dependents'] ) : ?>
					<div class="pus-req">Needed by: <?php echo esc_html( implode( ', ', $row['dependents'] ) ); ?></div>
				<?php endif; ?>
			</td>
			<td><?php self::verdict_badge( $verdict ); ?></td>
			<td class="pus-small"><?php echo esc_html( self::provides_summary( $row['prov'] ) ); ?></td>
			<td class="pus-small"><?php echo wp_kses_post( self::usage_summary( $row ) ); ?></td>
			<td><button type="button" class="button button-small pus-toggle" aria-expanded="false" aria-controls="<?php echo esc_attr( $details ); ?>">Details</button></td>
		</tr>
		<tr class="pus-details" id="<?php echo esc_attr( $details ); ?>" hidden>
			<td colspan="5"><?php self::render_plugin_details( $row, $r ); ?></td>
		</tr>
		<?php
	}

	private static function verdict_badge( string $verdict ): void {
		printf(
			'<span class="pus-v pus-v-%1$s" title="%3$s">%2$s</span>',
			esc_attr( $verdict ),
			esc_html( self::VERDICTS[ $verdict ][0] ),
			esc_attr( self::VERDICTS[ $verdict ][1] )
		);
	}

	private static function provides_summary( array $prov ): string {
		$parts = array();
		if ( ! empty( $prov['w'] ) ) {
			$parts[] = count( $prov['w'] ) . ' Elementor widget' . ( 1 === count( $prov['w'] ) ? '' : 's' );
		}
		if ( ! empty( $prov['x'] ) ) {
			$parts[] = 'Elementor extensions';
		}
		if ( ! empty( $prov['sc'] ) ) {
			$parts[] = count( $prov['sc'] ) . ' shortcode' . ( 1 === count( $prov['sc'] ) ? '' : 's' );
		}
		if ( ! empty( $prov['b'] ) ) {
			$parts[] = count( $prov['b'] ) . ' block' . ( 1 === count( $prov['b'] ) ? '' : 's' );
		}
		if ( ! empty( $prov['ww'] ) ) {
			$parts[] = count( $prov['ww'] ) . ' widget' . ( 1 === count( $prov['ww'] ) ? '' : 's' );
		}
		if ( ! empty( $prov['d'] ) ) {
			$parts[] = count( $prov['d'] ) . ' dynamic tag' . ( 1 === count( $prov['d'] ) ? '' : 's' );
		}
		foreach ( isset( $prov['pt'] ) ? $prov['pt'] : array() as $pt ) {
			if ( (int) $pt[1] > 0 ) {
				$parts[] = $pt[0] . ' (' . number_format_i18n( (int) $pt[1] ) . ')';
			}
		}
		return $parts ? implode( ' · ', $parts ) : '—';
	}

	private static function usage_summary( array $row ): string {
		$out = array();
		if ( $row['live'] ) {
			$out[] = '<strong>' . esc_html( count( $row['live'] ) . ' live' ) . '</strong>';
		}
		if ( $row['sitewide'] ) {
			$out[] = '<span class="pus-tag">site-wide</span>';
		}
		if ( $row['hidden'] ) {
			$out[] = esc_html( count( $row['hidden'] ) . ' unpublished' );
		}
		if ( $row['left_count'] ) {
			$out[] = '<span class="pus-tag pus-tag-warn">leftovers on ' . esc_html( (string) $row['left_count'] ) . '</span>';
		}
		if ( 'inactive' === $row['verdict'] && $row['data_left'] ) {
			$out[] = '<span class="pus-tag pus-tag-warn">data in ' . esc_html( count( $row['data_left'] ) . ' table' . ( 1 === count( $row['data_left'] ) ? '' : 's' ) ) . '</span>';
		}
		$html    = $out ? implode( ' · ', $out ) : '';
		$signals = self::signals( $row );
		if ( $signals ) {
			$html .= ( '' !== $html ? '<div class="pus-signals">' : '<div class="pus-signals" style="margin-top:0;">' ) . implode( ' ', $signals ) . '</div>';
		}
		return '' !== $html ? $html : '<span class="pus-muted">—</span>';
	}

	/** Short labels of the strongest evidence, for the table and the Plugins column. */
	private static function signals( array $row, bool $plain = false ): array {
		if ( in_array( $row['verdict'], array( 'inactive', 'rescan' ), true ) ) {
			return array();
		}
		$strong = array();
		$medium = array();
		foreach ( $row['activity'] as $evidence ) {
			if ( 2 === $evidence['s'] ) {
				$strong[ $evidence['sh'] ] = true;
			} elseif ( 1 === $evidence['s'] ) {
				$medium[ $evidence['sh'] ] = true;
			}
		}
		if ( 'used' === $row['verdict'] ) {
			$medium = array(); // Already a clear "keep"; background details stay in Details.
		}
		$labels = $strong ? array_keys( $strong ) : array_keys( $medium );
		$more   = count( $labels ) - 3;
		$labels = array_slice( $labels, 0, 3 );
		if ( $plain ) {
			return $labels ? array( implode( ' · ', $labels ) . ( $more > 0 ? ' +' . $more : '' ) ) : array();
		}
		$class = $strong ? 'pus-tag pus-tag-strong' : 'pus-tag';
		$out   = array();
		foreach ( $labels as $label ) {
			$out[] = '<span class="' . $class . '">' . esc_html( $label ) . '</span>';
		}
		if ( $more > 0 ) {
			$out[] = '<span class="pus-muted pus-small">+' . esc_html( (string) $more ) . '</span>';
		}
		return $out;
	}

	private static function render_plugin_details( array $row, array $r ): void {
		$prov = $row['prov'];
		echo '<p class="pus-muted" style="margin-top:0;">' . esc_html( self::VERDICTS[ $row['verdict'] ][1] ) . '</p>';

		if ( $row['dependents'] ) {
			echo '<p class="pus-warn">Other active plugins need this one: ' . esc_html( implode( ', ', $row['dependents'] ) ) . '. Removing it breaks them.</p>';
		}

		$lists = array();
		if ( ! empty( $prov['w'] ) ) {
			$lists['Elementor widgets'] = array_values( $prov['w'] );
		}
		if ( ! empty( $prov['x'] ) ) {
			$lists['Elementor extension settings'] = array_map(
				static function ( string $token ): string {
					return $token . '_…';
				},
				$prov['x']
			);
		}
		if ( ! empty( $prov['sc'] ) ) {
			$lists['Shortcodes'] = array_map(
				static function ( $tag ): string {
					return '[' . $tag . ']';
				},
				$prov['sc']
			);
		}
		if ( ! empty( $prov['b'] ) ) {
			$lists['Blocks'] = $prov['b'];
		}
		if ( ! empty( $prov['ww'] ) ) {
			$lists['Widgets'] = array_values( $prov['ww'] );
		}
		if ( ! empty( $prov['d'] ) ) {
			$lists['Elementor dynamic tags'] = $prov['d'];
		}
		if ( ! empty( $prov['pt'] ) ) {
			$lists['Post types'] = array_map(
				static function ( array $pt ): string {
					return $pt[0] . ': ' . number_format_i18n( (int) $pt[1] ) . ' items (' . number_format_i18n( (int) $pt[2] ) . ' published' . ( $pt[3] ? ', public' : '' ) . ')';
				},
				array_values( $prov['pt'] )
			);
		}
		if ( $lists ) {
			echo '<h4 class="pus-h4">What it adds</h4><div class="pus-provides">';
			foreach ( $lists as $title => $items ) {
				$shown = array_slice( $items, 0, 25 );
				$more  = count( $items ) - count( $shown );
				echo '<div><strong>' . esc_html( $title ) . ':</strong> ' . esc_html( implode( ', ', $shown ) ) . ( $more > 0 ? ' <span class="pus-muted">+' . esc_html( (string) $more ) . ' more</span>' : '' ) . '</div>';
			}
			echo '</div>';
		}

		if ( $row['activity'] && 'rescan' !== $row['verdict'] ) {
			echo '<h4 class="pus-h4">' . ( 'inactive' === $row['verdict'] ? 'What it left on the site' : 'What it does on the site' ) . '</h4><ul class="pus-evidence">';
			foreach ( $row['activity'] as $evidence ) {
				$kind = 2 === $evidence['s'] ? array( 'strong', 'Clear sign of use' ) : ( 1 === $evidence['s'] ? array( 'medium', 'Background' ) : array( 'info', 'Info' ) );
				echo '<li class="pus-ev-' . esc_attr( $kind[0] ) . '"><span class="pus-ev-tag">' . esc_html( $kind[1] ) . '</span> ' . esc_html( $evidence['l'] ) . '</li>';
			}
			echo '</ul>';
		} elseif ( ! $lists && 'inactive' !== $row['verdict'] && 'rescan' !== $row['verdict'] ) {
			echo '<p>Nothing it adds can be placed on a page, and no activity of it was found. Check its settings page to see what it is for, or look for its data with <a href="' . esc_url( self::page_url( array( 'tab' => 'search' ) ) ) . '">Custom search</a>.</p>';
		}
		if ( $row['data_left'] && 'inactive' === $row['verdict'] ) {
			echo '<p class="pus-small">Tables it left: ' . esc_html( implode( ', ', array_map( array( __CLASS__, 'table_label' ), $row['data_left'] ) ) ) . '</p>';
		}
		if ( $row['usage'] ) {
			echo '<h4 class="pus-h4">Where its elements are used</h4>';
		}

		if ( $row['usage'] ) {
			$locs = $row['usage'];
			uksort(
				$locs,
				static function ( $a, $b ) use ( $r ): int {
					$live_a = self::loc_is_live( $a, $r ) ? 0 : 1;
					$live_b = self::loc_is_live( $b, $r ) ? 0 : 1;
					return $live_a <=> $live_b ?: strcasecmp( self::loc_title( $a, $r ), self::loc_title( $b, $r ) );
				}
			);
			self::render_locations( $locs, $r );
		} elseif ( 'unused' === $row['verdict'] ) {
			echo '<p><strong>None of its elements was found on any page, template or widget area, and no activity of it was found.</strong> Deactivate it first, check the site, then delete it.</p>';
		}

		if ( $row['leftovers'] ) {
			echo '<h4 style="margin-bottom:4px;">Leftovers of this plugin still saved in content</h4>';
			echo '<p class="pus-muted" style="margin-top:0;">The plugin is not active, so these show nothing (or raw text) on the site. Remove them from the pages or reactivate the plugin.</p>';
			self::render_orphan_table( $row['leftovers'], $r );
		}
	}

	private static function render_locations( array $locs, array $r ): void {
		$total = count( $locs );
		$locs  = array_slice( $locs, 0, self::MAX_LOCATIONS, true );
		?>
		<table class="pus-loc-table">
			<thead><tr><th scope="col">Where</th><th scope="col">Shown to visitors?</th><th scope="col">What was found</th></tr></thead>
			<tbody>
			<?php foreach ( $locs as $loc => $hits ) : ?>
				<tr>
					<td><?php echo wp_kses_post( self::loc_cell( $loc, $r ) ); ?></td>
					<td><?php echo wp_kses_post( self::loc_status( $loc, $r ) ); ?></td>
					<td>
						<?php foreach ( $hits as $hit ) : ?>
							<div class="pus-hit">
								<?php echo esc_html( $hit['l'] ); ?><?php echo $hit['n'] > 1 ? ' <span class="pus-muted">×' . esc_html( (string) $hit['n'] ) . '</span>' : ''; ?>
								<?php if ( ! empty( $hit['p'] ) ) : ?><span class="pus-tag" title="Matched by name, not by the plugin’s registration">probable</span><?php endif; ?>
								<?php foreach ( isset( $hit['c'] ) ? $hit['c'] : array() as $crumb ) : ?>
									<div class="pus-breadcrumb"><?php echo esc_html( $crumb ); ?></div>
								<?php endforeach; ?>
							</div>
						<?php endforeach; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php if ( $total > self::MAX_LOCATIONS ) : ?>
			<p class="pus-muted">Showing <?php echo esc_html( (string) self::MAX_LOCATIONS ); ?> of <?php echo esc_html( (string) $total ); ?> places.</p>
		<?php endif; ?>
		<?php
	}

	/** @param int|string $loc */
	private static function loc_title( $loc, array $r ): string {
		if ( is_string( $loc ) && 0 === strpos( $loc, 'sb:' ) ) {
			$area = substr( $loc, 3 );
			return 'Widget area: ' . ( isset( $r['areas'][ $area ]['t'] ) ? $r['areas'][ $area ]['t'] : $area );
		}
		$title = isset( $r['posts'][ $loc ]['t'] ) ? (string) $r['posts'][ $loc ]['t'] : '';
		return '' !== $title ? $title : '(no title)';
	}

	/** @param int|string $loc */
	private static function loc_cell( $loc, array $r ): string {
		if ( is_string( $loc ) && 0 === strpos( $loc, 'sb:' ) ) {
			return '<strong>' . esc_html( self::loc_title( $loc, $r ) ) . '</strong><div class="pus-links"><a href="' . esc_url( admin_url( 'widgets.php' ) ) . '">Widgets</a></div>';
		}
		$id   = (int) $loc;
		$post = isset( $r['posts'][ $id ] ) ? $r['posts'][ $id ] : null;
		if ( ! $post ) {
			return esc_html( '#' . $id );
		}
		$html  = '<strong>' . esc_html( self::loc_title( $id, $r ) ) . '</strong>';
		$html .= '<div class="pus-muted pus-small">' . esc_html( self::type_label( $post ) ) . ' · ID ' . esc_html( (string) $id ) . '</div>';
		$html .= '<div class="pus-links">' . self::post_links( $id, $post ) . '</div>';
		return $html;
	}

	private static function post_links( int $id, array $post ): string {
		$links = array();
		$edit  = get_edit_post_link( $id, 'raw' );
		if ( $edit ) {
			$links[] = '<a href="' . esc_url( $edit ) . '">Edit</a>';
		}
		if ( ! empty( $post['e'] ) && current_user_can( 'edit_post', $id ) ) {
			$links[] = '<a href="' . esc_url( admin_url( 'post.php?post=' . $id . '&action=elementor' ) ) . '">Edit with Elementor</a>';
		}
		if ( 'publish' === $post['s'] && ! in_array( $post['y'], self::TEMPLATE_TYPES, true ) && is_post_type_viewable( $post['y'] ) ) {
			$links[] = '<a href="' . esc_url( (string) get_permalink( $id ) ) . '" target="_blank" rel="noopener noreferrer">View<span class="screen-reader-text"> (opens in a new tab)</span></a>';
		}
		return implode( ' ', $links );
	}

	private static function post_link_html( $id ): string {
		$id    = (int) $id;
		$edit  = get_edit_post_link( $id, 'raw' );
		$title = get_the_title( $id );
		$title = '' !== $title ? $title : '#' . $id;
		return $edit ? '<a href="' . esc_url( $edit ) . '">' . esc_html( $title ) . '</a>' : esc_html( $title );
	}

	private static function type_label( array $post ): string {
		if ( 'elementor_library' === $post['y'] ) {
			return 'Elementor template' . ( '' !== $post['tt'] ? ' (' . $post['tt'] . ')' : '' );
		}
		$object = get_post_type_object( $post['y'] );
		return $object ? (string) $object->labels->singular_name : $post['y'];
	}

	/** @param int|string $loc */
	private static function loc_status( $loc, array $r ): string {
		if ( is_string( $loc ) && 0 === strpos( $loc, 'sb:' ) ) {
			return self::loc_is_live( $loc, $r )
				? '<span class="pus-tag pus-tag-live">Yes</span> <span class="pus-muted pus-small">if the theme shows this area</span>'
				: '<span class="pus-tag">No</span> <span class="pus-muted pus-small">area not in the current theme</span>';
		}
		$post = isset( $r['posts'][ $loc ] ) ? $r['posts'][ $loc ] : null;
		if ( ! $post ) {
			return '';
		}
		$statuses = array(
			'publish' => 'Published',
			'future'  => 'Scheduled',
			'draft'   => 'Draft',
			'pending' => 'Pending review',
			'private' => 'Private',
		);
		$status = isset( $statuses[ $post['s'] ] ) ? $statuses[ $post['s'] ] : $post['s'];
		$html   = '' !== $post['live'] ? '<span class="pus-tag pus-tag-live">Yes</span> ' : '<span class="pus-tag">No</span> ';

		$notes = array();
		if ( 'conditions' === $post['live'] ) {
			$notes[] = 'Display conditions: ' . esc_html( self::conditions_text( $post['cn'] ) );
		} elseif ( 'theme' === $post['live'] ) {
			$notes[] = 'Theme template';
		} elseif ( 'publish' !== $post['s'] ) {
			$notes[] = esc_html( $status );
		}
		if ( $post['by'] ) {
			$by = array();
			foreach ( array_slice( $post['by'], 0, 8 ) as $from ) {
				$label = esc_html( self::loc_title( $from, $r ) );
				if ( isset( $r['posts'][ $from ] ) && '' === $r['posts'][ $from ]['live'] ) {
					$label .= ' <span class="pus-muted">(not live)</span>';
				}
				$by[] = $label;
			}
			$notes[] = 'Embedded in: ' . implode( ', ', $by ) . ( count( $post['by'] ) > 8 ? ' …' : '' );
		} elseif ( in_array( $post['y'], array( 'elementor_library', 'wp_block' ), true ) && '' === $post['live'] ) {
			$notes[] = 'Not used by any page and no display conditions';
		}
		if ( $notes ) {
			$html .= '<div class="pus-small">' . implode( '<br>', $notes ) . '</div>';
		}
		return $html;
	}

	private static function conditions_text( array $conditions ): string {
		$include = array();
		foreach ( $conditions as $condition ) {
			if ( 0 !== strpos( (string) $condition, 'include/' ) ) {
				continue;
			}
			$condition = substr( (string) $condition, 8 );
			$include[] = 'general' === $condition ? 'Entire site' : str_replace( '/', ' › ', $condition );
		}
		return $include ? implode( ', ', $include ) : '—';
	}

	private static function render_orphans( array $r ): void {
		if ( empty( $r['orphans'] ) ) {
			return;
		}
		?>
		<h2 style="margin-top:28px;">Elements no active plugin provides</h2>
		<p class="pus-muted" style="max-width:860px;">These are saved in content but nothing active renders them: they come from inactive or deleted plugins (visitors see nothing, or raw <code>[shortcode]</code> text). Clean them up, or reactivate the plugin they belong to.</p>
		<?php
		self::render_orphan_table( $r['orphans'], $r );
	}

	private static function table_label( array $table ): string {
		global $wpdb;
		return $wpdb->prefix . $table[0] . ( $table[1] > 0 ? ' (~' . number_format_i18n( $table[1] ) . ' rows)' : '' );
	}

	private static function render_unlinked_tables( array $r ): void {
		global $wpdb;
		if ( empty( $r['unlinked'] ) ) {
			return;
		}
		$tables = $r['unlinked'];
		usort(
			$tables,
			static function ( array $a, array $b ): int {
				return $b[2] <=> $a[2];
			}
		);
		?>
		<details class="pus-advanced" style="margin-top:22px;">
			<summary>Database tables no installed plugin explains (<?php echo esc_html( (string) count( $tables ) ); ?>)</summary>
			<p class="pus-muted" style="max-width:860px;">Usually left behind by plugins that were deleted. They are matched by name only, so check before removing anything, and take a backup first.</p>
			<table class="pus-loc-table" style="max-width:720px;">
				<thead><tr><th scope="col">Table</th><th scope="col">Rows (approx.)</th><th scope="col">Size</th></tr></thead>
				<tbody>
				<?php foreach ( $tables as $table ) : ?>
					<tr>
						<td><code><?php echo esc_html( $wpdb->prefix . $table[0] ); ?></code></td>
						<td><?php echo $table[3] ? esc_html( number_format_i18n( $table[1] ) ) : 'empty'; ?></td>
						<td><?php echo esc_html( size_format( $table[2] ) ? size_format( $table[2] ) : '—' ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</details>
		<?php
	}

	private static function render_orphan_table( array $orphans, array $r ): void {
		uasort(
			$orphans,
			static function ( array $a, array $b ): int {
				return count( $b['at'] ) <=> count( $a['at'] );
			}
		);
		?>
		<table class="pus-loc-table">
			<thead><tr><th scope="col">Element</th><th scope="col">Probably from</th><th scope="col">Found on</th></tr></thead>
			<tbody>
			<?php foreach ( $orphans as $orphan ) : ?>
				<tr>
					<td><?php echo esc_html( $orphan['l'] ); ?></td>
					<td><?php echo '' !== $orphan['h'] ? esc_html( $orphan['h'] ) : '<span class="pus-muted">—</span>'; ?></td>
					<td>
						<?php
						$links = array();
						foreach ( array_slice( $orphan['at'], 0, 15, true ) as $loc => $count ) {
							$label = esc_html( self::loc_title( $loc, $r ) );
							if ( is_int( $loc ) && isset( $r['posts'][ $loc ] ) ) {
								$edit  = get_edit_post_link( $loc, 'raw' );
								$label = $edit ? '<a href="' . esc_url( $edit ) . '">' . $label . '</a>' : $label;
								$label .= '' === $r['posts'][ $loc ]['live'] ? ' <span class="pus-muted">(not live)</span>' : '';
							}
							$links[] = $label;
						}
						echo wp_kses_post( implode( ', ', $links ) . ( count( $orphan['at'] ) > 15 ? ' …' : '' ) );
						?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Columns on Plugins and Pages/Posts lists
	 * ------------------------------------------------------------------- */

	public static function add_plugins_column( $columns ) {
		if ( is_array( $columns ) && current_user_can( 'manage_options' ) ) {
			$columns['pus_usage'] = 'Usage';
		}
		return $columns;
	}

	public static function render_plugins_column( $column, $plugin_file, $plugin_data = array() ): void {
		if ( 'pus_usage' !== $column || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$r = self::get_result();
		if ( ! $r ) {
			echo '<a href="' . esc_url( self::page_url() ) . '">Scan usage</a>';
			return;
		}
		$folder = false !== strpos( (string) $plugin_file, '/' ) ? dirname( (string) $plugin_file ) : (string) $plugin_file;
		$rows   = self::plugin_rows( $r );
		if ( ! isset( $rows[ $folder ] ) ) {
			echo '<span class="pus-muted">—</span>';
			return;
		}
		$row = $rows[ $folder ];
		self::verdict_badge( $row['verdict'] );
		$where = array();
		if ( $row['live'] ) {
			$where[] = count( $row['live'] ) . ' live';
		}
		if ( $row['hidden'] ) {
			$where[] = count( $row['hidden'] ) . ' unpublished';
		}
		if ( $row['left_count'] ) {
			$where[] = 'leftovers on ' . $row['left_count'];
		}
		$where = array_merge( $where, self::signals( $row, true ) );
		if ( $where ) {
			echo '<div class="pus-small">' . esc_html( implode( ' · ', $where ) ) . '</div>';
		}
		if ( $row['dependents'] ) {
			echo '<div class="pus-req">Needed by: ' . esc_html( implode( ', ', $row['dependents'] ) ) . '</div>';
		}
		echo '<div class="pus-small"><a href="' . esc_url( self::page_url() . '#pus-plugin-' . sanitize_html_class( $folder ) ) . '">Where?</a></div>';
	}

	public static function add_posts_column( $columns ) {
		if ( ! is_array( $columns ) || ! current_user_can( 'manage_options' ) || ! self::get_result() ) {
			return $columns;
		}
		$out = array();
		foreach ( $columns as $key => $label ) {
			$out[ $key ] = $label;
			if ( 'title' === $key ) {
				$out['pus_plugins'] = 'Plugins used';
			}
		}
		if ( ! isset( $out['pus_plugins'] ) ) {
			$out['pus_plugins'] = 'Plugins used';
		}
		return $out;
	}

	public static function render_posts_column( $column, $post_id ): void {
		if ( 'pus_plugins' !== $column ) {
			return;
		}
		$r     = self::get_result();
		$entry = ( $r && isset( $r['index'][ (int) $post_id ] ) ) ? $r['index'][ (int) $post_id ] : array();
		if ( ! $entry ) {
			echo '<span class="pus-muted">—</span>';
			return;
		}
		foreach ( $entry as $owner => $how ) {
			if ( '!' === $owner ) {
				continue;
			}
			$name = self::owner_name( (string) $owner, true );
			if ( 'v' === $how ) {
				printf( '<span class="pus-page-badge pus-page-badge-via" title="%s">%s</span>', esc_attr( 'Through an embedded template' ), esc_html( '↳ ' . $name ) );
			} else {
				printf( '<span class="pus-page-badge">%s</span>', esc_html( $name ) );
			}
		}
		if ( isset( $entry['!'] ) ) {
			echo '<span class="pus-page-badge pus-page-badge-warn" title="Contains an element from an inactive or deleted plugin">Missing element</span>';
		}
	}

	public static function render_posts_filter( $post_type, $which = 'top' ): void {
		if ( ! in_array( $post_type, array( 'page', 'post' ), true ) || 'top' !== $which || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$r = self::get_result();
		if ( ! $r ) {
			return;
		}
		$counts = array();
		foreach ( $r['index'] as $id => $entry ) {
			if ( ! isset( $r['posts'][ $id ] ) || $post_type !== $r['posts'][ $id ]['y'] ) {
				continue;
			}
			foreach ( array_keys( $entry ) as $owner ) {
				$counts[ $owner ] = isset( $counts[ $owner ] ) ? $counts[ $owner ] + 1 : 1;
			}
		}
		if ( ! $counts ) {
			return;
		}
		$selected = self::selected_owner_filter();
		$options  = array();
		foreach ( $counts as $owner => $count ) {
			$options[ (string) $owner ] = ( '!' === $owner ? 'Missing elements' : 'Uses: ' . self::owner_name( (string) $owner, false ) ) . ' (' . $count . ')';
		}
		asort( $options );
		echo '<label class="screen-reader-text" for="pus_owner">Filter by plugin</label>';
		echo '<select name="pus_owner" id="pus_owner"><option value="">All plugins</option>';
		foreach ( $options as $owner => $label ) {
			printf( '<option value="%s"%s>%s</option>', esc_attr( $owner ), selected( $selected, $owner, false ), esc_html( $label ) );
		}
		echo '</select>';
	}

	private static function selected_owner_filter(): string {
		$value = isset( $_GET['pus_owner'] ) ? sanitize_text_field( wp_unslash( $_GET['pus_owner'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return ( '!' === $value || preg_match( '/^(p|t|mu):[A-Za-z0-9._ -]+$/', $value ) ) ? $value : '';
	}

	public static function apply_posts_filter( $query ): void {
		global $pagenow;
		if ( ! is_admin() || 'edit.php' !== $pagenow || ! ( $query instanceof WP_Query ) || ! $query->is_main_query() ) {
			return;
		}
		$owner     = self::selected_owner_filter();
		$post_type = $query->get( 'post_type' );
		$post_type = '' === $post_type ? 'post' : $post_type;
		if ( '' === $owner || ! in_array( $post_type, array( 'page', 'post' ), true ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$r   = self::get_result();
		$ids = array();
		foreach ( $r ? $r['index'] : array() as $id => $entry ) {
			if ( isset( $entry[ $owner ] ) ) {
				$ids[] = (int) $id;
			}
		}
		$query->set( 'post__in', $ids ? $ids : array( 0 ) );
	}

	private static function owner_name( string $owner, bool $short ): string {
		if ( 0 === strpos( $owner, 'p:' ) ) {
			$plugins = self::plugin_list();
			$folder  = substr( $owner, 2 );
			$name    = isset( $plugins[ $folder ] ) ? $plugins[ $folder ]['name'] : $folder;
			if ( $short ) {
				// Short badge names: "Essential Addons for Elementor" → "Essential Addons". "για" is Greek for "for",
				// so translated plugin names are shortened too. Then drop taglines after a dash, pipe or colon.
				$name = (string) preg_replace( '/\s+(for|για)\s+Elementor\b.*$/iu', '', $name );
				$name = (string) preg_replace( '/\s+[–—|:-]\s+.*$/u', '', $name );
				$name = trim( $name );
			}
			return '' !== $name ? $name : $folder;
		}
		if ( 0 === strpos( $owner, 't:' ) ) {
			return 'Theme: ' . substr( $owner, 2 );
		}
		if ( 0 === strpos( $owner, 'mu:' ) ) {
			return 'MU: ' . substr( $owner, 3 );
		}
		return $owner;
	}

	/* ---------------------------------------------------------------------
	 * Custom search (pattern based, for inactive or back-end plugins)
	 * ------------------------------------------------------------------- */

	private static function render_search_tab(): void {
		$presets          = self::get_presets();
		$selected_preset  = self::get_valid_preset_key( isset( $_GET['preset'] ) ? sanitize_key( wp_unslash( $_GET['preset'] ) ) : 'happy_addons' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$selected_scope   = 'pages_templates';
		$patterns_input   = $presets[ $selected_preset ]['patterns'];
		$selected_sources = $presets[ $selected_preset ]['recommended_sources'];
		$results          = null;

		if ( 'POST' === self::request_method() && isset( $_POST['pus_action'] ) && 'search' === $_POST['pus_action'] ) {
			check_admin_referer( self::NONCE_ACTION, self::NONCE_NAME );

			$selected_preset = isset( $_POST['preset'] ) ? self::get_valid_preset_key( sanitize_key( wp_unslash( $_POST['preset'] ) ) ) : 'happy_addons';
			$selected_scope  = isset( $_POST['scope'] ) ? sanitize_key( wp_unslash( $_POST['scope'] ) ) : 'pages_templates';
			if ( ! in_array( $selected_scope, array( 'pages', 'pages_templates', 'all' ), true ) ) {
				$selected_scope = 'pages_templates';
			}
			$patterns_input   = isset( $_POST['patterns'] ) ? sanitize_textarea_field( wp_unslash( $_POST['patterns'] ) ) : '';
			$selected_sources = isset( $_POST['sources'] ) && is_array( $_POST['sources'] ) ? array_map( 'sanitize_key', wp_unslash( $_POST['sources'] ) ) : array();
			$selected_sources = array_values( array_intersect( $selected_sources, array( 'elementor', 'posts', 'postmeta', 'options' ) ) );

			$results = self::run_search(
				self::parse_patterns( $patterns_input ),
				$selected_sources,
				self::get_scope_post_types( $selected_scope ),
				self::get_preset_scan_config( $presets[ $selected_preset ] )
			);
		}

		$current_preset = $presets[ $selected_preset ];
		?>
		<p class="pus-muted" style="margin-top:14px;">Searches for a plugin’s names, prefixes or shortcodes. Useful for inactive plugins and for back-end plugins that leave data in settings.</p>

		<form method="post" action="<?php echo esc_url( self::page_url( array( 'tab' => 'search' ) ) ); ?>">
			<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME ); ?>
			<input type="hidden" name="pus_action" value="search">

			<div class="pus-top-panel">
				<div class="pus-panel-grid">
					<div>
						<label for="preset"><strong>What do you want to check?</strong></label><br>
						<select id="preset" name="preset" class="pus-select-lg">
							<?php foreach ( $presets as $preset_key => $preset ) : ?>
								<option value="<?php echo esc_attr( $preset_key ); ?>" <?php selected( $selected_preset, $preset_key ); ?>><?php echo esc_html( $preset['label'] ); ?></option>
							<?php endforeach; ?>
						</select>

						<fieldset class="pus-scope-row" style="margin-top:14px;">
							<legend><strong>Show results from:</strong></legend>
							<label><input type="radio" name="scope" value="pages" <?php checked( $selected_scope, 'pages' ); ?>> WordPress pages only</label>
							<label><input type="radio" name="scope" value="pages_templates" <?php checked( $selected_scope, 'pages_templates' ); ?>> Pages + Elementor/global templates</label>
							<label><input type="radio" name="scope" value="all" <?php checked( $selected_scope, 'all' ); ?>> Everything in the selected scan areas</label>
						</fieldset>
					</div>
					<div>
						<div id="pus-hint-box" class="pus-hint-box"><?php echo wp_kses_post( $current_preset['hint'] ); ?></div>
						<p class="pus-muted pus-small" style="margin-top:9px;">Tip: start with <strong>Pages + Elementor/global templates</strong>. Use the advanced settings only when the first search does not find enough.</p>
					</div>
				</div>
				<?php submit_button( 'Find usage', 'primary', 'submit', false, array( 'style' => 'margin-top:16px;' ) ); ?>
			</div>

			<details class="pus-advanced">
				<summary>Advanced search settings</summary>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="patterns">Search patterns</label></th>
						<td>
							<textarea id="patterns" name="patterns" rows="9" cols="70" class="large-text code"><?php echo esc_textarea( $patterns_input ); ?></textarea>
							<p class="description">One per line. Patterns ending in <code>-</code> or <code>_</code> match the start of widget names / setting names; patterns starting with <code>[</code> are shortcodes and are also looked for inside Elementor widgets. Examples: <code>[contact-form-7</code>, <code>ha-</code>, <code>eael</code>, <code>wpforms</code>.</p>
						</td>
					</tr>
					<tr>
						<th scope="row">Scan areas</th>
						<td>
							<?php
							$areas = array(
								'elementor' => 'Elementor layout data <em>(widget-level, with position)</em>',
								'posts'     => 'Posts, pages, templates, shortcodes, post types',
								'postmeta'  => 'Post meta',
								'options'   => 'WordPress options / settings',
							);
							foreach ( $areas as $val => $label ) :
								?>
								<label style="display:block;margin-bottom:5px;">
									<input type="checkbox" name="sources[]" value="<?php echo esc_attr( $val ); ?>" id="source-<?php echo esc_attr( $val ); ?>" <?php checked( in_array( $val, $selected_sources, true ) ); ?>>
									<?php echo wp_kses( $label, array( 'em' => array() ) ); ?>
									<span id="hint-src-<?php echo esc_attr( $val ); ?>" class="pus-muted pus-small" style="margin-left:6px;"></span>
								</label>
							<?php endforeach; ?>
						</td>
					</tr>
				</table>
			</details>
		</form>

		<?php if ( is_array( $results ) ) : ?>
			<?php self::render_results( $results ); ?>
		<?php endif; ?>

		<script>
		(function () {
			var presets = <?php echo wp_json_encode( $presets ); ?>;
			var presetSelect = document.getElementById('preset');
			var patterns = document.getElementById('patterns');
			var hintBox = document.getElementById('pus-hint-box');
			var sourceKeys = ['elementor', 'posts', 'postmeta', 'options'];
			if (!presetSelect || !patterns || !hintBox) { return; }

			function showHints(p) {
				hintBox.innerHTML = p.hint || '';
				sourceKeys.forEach(function (src) {
					var span = document.getElementById('hint-src-' + src);
					if (span) { span.innerHTML = p.hint_sources && p.hint_sources[src] ? '— ' + p.hint_sources[src] : ''; }
				});
			}
			function applyPreset(p) {
				patterns.value = p.patterns || '';
				sourceKeys.forEach(function (src) {
					var cb = document.getElementById('source-' + src);
					if (cb && p.recommended_sources) { cb.checked = p.recommended_sources.indexOf(src) !== -1; }
				});
				showHints(p);
			}
			presetSelect.addEventListener('change', function () {
				if (presets[presetSelect.value]) { applyPreset(presets[presetSelect.value]); }
			});
			// On load only show the hints: keep the patterns and areas the user just searched with.
			if (presets[presetSelect.value]) { showHints(presets[presetSelect.value]); }
		})();
		</script>
		<?php
	}

	private static function get_valid_preset_key( string $key ): string {
		$presets = self::get_presets();
		return isset( $presets[ $key ] ) ? $key : 'happy_addons';
	}

	private static function get_presets(): array {
		$only_elementor = array(
			'posts'    => 'Usually not needed.',
			'postmeta' => 'Usually not needed.',
			'options'  => 'Usually not needed.',
		);
		return array(
			'happy_addons'        => array(
				'label'               => 'Happy Addons for Elementor',
				'patterns'            => implode( "\n", array( 'ha-', 'happyaddons', 'happy-addons', 'happy_addons' ) ),
				'setting_prefixes'    => array( 'ha_' ),
				'recommended_sources' => array( 'elementor' ),
				'hint'                => 'Happy Addons is an Elementor widget library. The most reliable scan is <strong>Elementor layout data</strong>: widgets start with <code>ha-</code> and its extensions (floating effects, wrapper link…) use settings starting with <code>ha_</code>.',
				'hint_sources'        => array( 'elementor' => 'Primary area.' ) + $only_elementor,
			),
			'essential_addons'    => array(
				'label'               => 'Essential Addons for Elementor',
				'patterns'            => implode( "\n", array( 'eael', 'essential-addons', 'essential_addons' ) ),
				'setting_prefixes'    => array( 'eael_' ),
				'recommended_sources' => array( 'elementor' ),
				'hint'                => 'Essential Addons widgets start with <code>eael-</code>; its extensions use settings starting with <code>eael_</code>.',
				'hint_sources'        => array( 'elementor' => 'Primary area.' ) + $only_elementor,
			),
			'premium_addons'      => array(
				'label'               => 'Premium Addons for Elementor',
				'patterns'            => implode( "\n", array( 'premium-', 'premium_addons', 'premium-addons' ) ),
				'setting_prefixes'    => array( 'premium_' ),
				'recommended_sources' => array( 'elementor' ),
				'hint'                => 'Premium Addons widgets start with <code>premium-</code>; its extensions use settings starting with <code>premium_</code>.',
				'hint_sources'        => array( 'elementor' => 'Primary area.' ) + $only_elementor,
			),
			'jet_plugins'         => array(
				'label'               => 'Crocoblock / Jet Plugins',
				'patterns'            => implode( "\n", array( 'jet-', 'jet_', 'jetengine', 'jet-engine', 'jet-smart-filters', 'jetsmartfilters', 'jet-elements', 'jetelements' ) ),
				'setting_prefixes'    => array( 'jet_' ),
				'recommended_sources' => array( 'elementor', 'postmeta', 'options' ),
				'hint'                => 'Jet plugins may appear as Elementor widgets, extension settings, post meta, custom post type configuration and options.',
				'hint_sources'        => array(
					'elementor' => 'Primary for Jet Elementor widgets.',
					'posts'     => 'Optional, only when Jet shortcodes/post types are in content.',
					'postmeta'  => 'Recommended for JetEngine meta values.',
					'options'   => 'Recommended for JetEngine configuration.',
				),
			),
			'elementor_pro_forms' => array(
				'label'                        => 'Elementor Pro Forms',
				'patterns'                     => implode( "\n", array( '"widgetType":"form"' ) ),
				'recommended_sources'          => array( 'elementor' ),
				'exact_widget_types'           => array( 'form' ),
				'allow_elementor_raw_fallback' => false,
				'hint'                         => 'Elementor Pro Forms are found only by the exact widget type <code>form</code>, so words like <code>transform</code> or <code>form_fields</code> are ignored.',
				'hint_sources'                 => array(
					'elementor' => 'Primary area.',
					'posts'     => 'Avoid for this preset; form-related words are too generic.',
					'postmeta'  => 'Usually not needed.',
					'options'   => 'Usually not needed.',
				),
			),
			'contact_form_7'      => array(
				'label'               => 'Contact Form 7',
				'patterns'            => implode( "\n", array( '[contact-form-7', 'wpcf7' ) ),
				'recommended_sources' => array( 'elementor', 'posts' ),
				'hint'                => 'Contact Form 7 appears as a shortcode like <code>[contact-form-7]</code> in page content or inside an Elementor shortcode / text widget.',
				'hint_sources'        => array(
					'elementor' => 'Shortcodes inside Elementor widgets.',
					'posts'     => 'Shortcodes in classic/block content.',
					'postmeta'  => 'Form definitions/traces only.',
					'options'   => 'Plugin settings only.',
				),
			),
			'wpforms'             => array(
				'label'               => 'WPForms',
				'patterns'            => implode( "\n", array( '[wpforms', 'wpforms' ) ),
				'recommended_sources' => array( 'elementor', 'posts' ),
				'hint'                => 'WPForms appears as a <code>[wpforms]</code> shortcode, a block, or its Elementor widget.',
				'hint_sources'        => array(
					'elementor' => 'Shortcodes and the WPForms widget.',
					'posts'     => 'Shortcodes and blocks in content.',
					'postmeta'  => 'Form definitions/traces only.',
					'options'   => 'Settings only.',
				),
			),
			'gravity_forms'       => array(
				'label'               => 'Gravity Forms',
				'patterns'            => implode( "\n", array( '[gravityform', 'gravityforms', 'gform' ) ),
				'recommended_sources' => array( 'elementor', 'posts' ),
				'hint'                => 'Gravity Forms appears through shortcodes or its block. Forms themselves are stored in custom tables.',
				'hint_sources'        => array(
					'elementor' => 'Shortcodes inside Elementor widgets.',
					'posts'     => 'Shortcodes and blocks in content.',
					'postmeta'  => 'Usually not useful; custom tables are used.',
					'options'   => 'Settings only.',
				),
			),
			'fluent_forms'        => array(
				'label'               => 'Fluent Forms',
				'patterns'            => implode( "\n", array( '[fluentform', 'fluentform', 'fluent_form' ) ),
				'recommended_sources' => array( 'elementor', 'posts' ),
				'hint'                => 'Fluent Forms appears through shortcodes or its block. Forms themselves are stored in custom tables.',
				'hint_sources'        => array(
					'elementor' => 'Shortcodes inside Elementor widgets.',
					'posts'     => 'Shortcodes and blocks in content.',
					'postmeta'  => 'Usually not useful; custom tables are used.',
					'options'   => 'Settings only.',
				),
			),
			'slider_revolution'   => array(
				'label'               => 'Slider Revolution',
				'patterns'            => implode( "\n", array( '[rev_slider', 'revslider', 'rev_slider' ) ),
				'recommended_sources' => array( 'elementor', 'posts' ),
				'hint'                => 'Slider Revolution appears through a shortcode like <code>[rev_slider]</code>, a block, or its Elementor widget.',
				'hint_sources'        => array(
					'elementor' => 'Shortcodes and the Slider Revolution widget.',
					'posts'     => 'Shortcodes and blocks in content.',
					'postmeta'  => 'Usually not useful; sliders are in custom tables.',
					'options'   => 'Settings only.',
				),
			),
			'woocommerce'         => array(
				'label'               => 'WooCommerce',
				'patterns'            => implode( "\n", array( '[products', '[product_page', '[woocommerce_cart', '[woocommerce_checkout', '[woocommerce_my_account', 'woocommerce-' ) ),
				'recommended_sources' => array( 'elementor', 'posts' ),
				'hint'                => 'WooCommerce is deeply integrated: products and orders are its own data. This finds pages with WooCommerce shortcodes, blocks and Elementor WooCommerce widgets.',
				'hint_sources'        => array(
					'elementor' => 'WooCommerce Elementor widgets and shortcodes.',
					'posts'     => 'Shortcodes and blocks in content.',
					'postmeta'  => 'Many results (product/order data).',
					'options'   => 'Settings.',
				),
			),
			'acf'                 => array(
				'label'               => 'Advanced Custom Fields (ACF)',
				'patterns'            => implode( "\n", array( 'acf-', 'acf_', '_acf_' ) ),
				'recommended_sources' => array( 'elementor', 'postmeta' ),
				'hint'                => 'ACF stores field groups as posts and values as post meta. In Elementor it shows up as dynamic tags named <code>acf-…</code>.',
				'hint_sources'        => array(
					'elementor' => 'Dynamic tags connected to ACF.',
					'posts'     => 'Field group definitions.',
					'postmeta'  => 'Custom field values.',
					'options'   => 'Settings.',
				),
			),
			'yoast_seo'           => array(
				'label'               => 'Yoast SEO',
				'patterns'            => implode( "\n", array( 'yoast', 'wpseo', '_yoast_wpseo' ) ),
				'recommended_sources' => array( 'postmeta', 'options' ),
				'hint'                => 'Yoast stores SEO data in post meta and settings in options. This is a data scan, not a page element scan.',
				'hint_sources'        => array(
					'elementor' => 'Not applicable.',
					'posts'     => 'Usually not applicable.',
					'postmeta'  => 'Per-post SEO data.',
					'options'   => 'Settings.',
				),
			),
			'rank_math'           => array(
				'label'               => 'Rank Math SEO',
				'patterns'            => implode( "\n", array( 'rank_math', 'rankmath', 'rank-math' ) ),
				'recommended_sources' => array( 'postmeta', 'options' ),
				'hint'                => 'Rank Math stores SEO data in post meta and settings/modules in options. This is a data scan, not a page element scan.',
				'hint_sources'        => array(
					'elementor' => 'Not applicable.',
					'posts'     => 'Usually not applicable.',
					'postmeta'  => 'Per-post SEO data.',
					'options'   => 'Settings.',
				),
			),
			'wordfence'           => array(
				'label'               => 'Wordfence Security',
				'patterns'            => implode( "\n", array( 'wordfence', 'wf_' ) ),
				'recommended_sources' => array( 'options' ),
				'hint'                => 'Wordfence keeps settings in options and data in its own tables. It never appears as a page element.',
				'hint_sources'        => array(
					'elementor' => 'Not applicable.',
					'posts'     => 'Not applicable.',
					'postmeta'  => 'Usually not useful.',
					'options'   => 'Only relevant area.',
				),
			),
			'ai1wm'               => array(
				'label'               => 'All-in-One WP Migration',
				'patterns'            => implode( "\n", array( 'ai1wm', 'all-in-one-wp-migration' ) ),
				'recommended_sources' => array( 'options' ),
				'hint'                => 'A utility plugin: never used inside pages; only its settings matter.',
				'hint_sources'        => array(
					'elementor' => 'Not applicable.',
					'posts'     => 'Not applicable.',
					'postmeta'  => 'Not applicable.',
					'options'   => 'Only relevant area.',
				),
			),
		);
	}

	private static function get_preset_scan_config( array $preset ): array {
		return array(
			'exact_widget_types'           => isset( $preset['exact_widget_types'] ) ? array_values( array_filter( array_map( 'strval', (array) $preset['exact_widget_types'] ) ) ) : array(),
			'setting_prefixes'             => isset( $preset['setting_prefixes'] ) ? array_values( array_map( 'strtolower', (array) $preset['setting_prefixes'] ) ) : array(),
			'allow_elementor_raw_fallback' => ! array_key_exists( 'allow_elementor_raw_fallback', $preset ) || (bool) $preset['allow_elementor_raw_fallback'],
		);
	}

	/** Keeps the original case for SQL (LIKE follows the column collation) and a lowercase copy for PHP matching. */
	private static function parse_patterns( string $input ): array {
		$patterns = array();
		foreach ( (array) preg_split( '/\r\n|\r|\n/', $input ) as $item ) {
			$item = trim( (string) $item );
			if ( strlen( $item ) >= 2 ) {
				$patterns[ strtolower( $item ) ] = $item;
			}
		}
		return $patterns;
	}

	private static function get_scope_post_types( string $scope ): array {
		if ( 'pages' === $scope ) {
			return array( 'page' );
		}
		if ( 'pages_templates' === $scope ) {
			return array( 'page', 'elementor_library', 'wp_template', 'wp_template_part', 'wp_block' );
		}
		return array();
	}

	private static function run_search( array $patterns, array $sources, array $post_types, array $config ): array {
		$base = array(
			'patterns' => array_values( $patterns ),
			'groups'   => array(),
			'partial'  => false,
			'error'    => '',
		);
		if ( empty( $patterns ) ) {
			$base['error'] = 'No valid patterns were provided.';
			return $base;
		}
		if ( empty( $sources ) ) {
			$base['error'] = 'No scan areas were selected.';
			return $base;
		}
		wp_raise_memory_limit( 'admin' );
		$deadline = microtime( true ) + self::SEARCH_BUDGET;
		$items    = array();
		$complete = true;
		$areas    = array(
			'elementor' => 'search_elementor',
			'posts'     => 'search_posts',
			'postmeta'  => 'search_postmeta',
			'options'   => 'search_options',
		);
		foreach ( $areas as $source => $method ) {
			if ( in_array( $source, $sources, true ) && ! self::$method( $patterns, $post_types, $config, $items, $deadline ) ) {
				$complete = false;
				break;
			}
		}
		$base['groups']  = self::group_items( $items );
		$base['partial'] = ! $complete;
		return $base;
	}

	private static function like_sql( string $column, array $patterns ): array {
		global $wpdb;
		$args = array();
		foreach ( $patterns as $pattern ) {
			$args[] = '%' . $wpdb->esc_like( $pattern ) . '%';
		}
		return array( implode( ' OR ', array_fill( 0, count( $args ), "{$column} LIKE %s" ) ), $args );
	}

	private static function post_type_sql( string $alias, array $post_types ): array {
		$post_types = array_values( array_filter( array_map( 'sanitize_key', $post_types ) ) );
		if ( empty( $post_types ) ) {
			return array( '', array() );
		}
		return array( " AND {$alias}.post_type IN (" . implode( ',', array_fill( 0, count( $post_types ), '%s' ) ) . ') ', $post_types );
	}

	private static function stop_search( array $items, float $deadline ): bool {
		return microtime( true ) >= $deadline || count( $items ) >= self::SEARCH_CAP;
	}

	private static function search_elementor( array $patterns, array $post_types, array $config, array &$items, float $deadline ): bool {
		global $wpdb;
		$like_patterns = $patterns;
		foreach ( $config['exact_widget_types'] as $type ) {
			$like_patterns[] = '"widgetType":"' . $type . '"';
		}
		$like   = self::like_sql( 'pm.meta_value', $like_patterns );
		$types  = self::post_type_sql( 'p', $post_types );
		$cursor = 0;
		while ( true ) {
			if ( self::stop_search( $items, $deadline ) ) {
				return false;
			}
			$args = array_merge( array( $cursor ), $types[1], $like[1] );
			$sql  = "SELECT pm.meta_id, p.ID, p.post_title, p.post_type, p.post_status, pm.meta_value
				FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE pm.meta_key = '_elementor_data' AND pm.meta_id > %d
				  AND p.post_type <> 'revision' AND p.post_status NOT IN ('trash','auto-draft') {$types[0]}
				  AND ({$like[0]})
				ORDER BY pm.meta_id ASC LIMIT 20";
			$rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			if ( empty( $rows ) ) {
				return true;
			}
			foreach ( $rows as $row ) {
				$cursor = (int) $row->meta_id;
				$item   = self::search_elementor_row( $row, $patterns, $config );
				if ( $item ) {
					$items[] = $item;
				}
			}
			unset( $rows );
		}
	}

	private static function search_elementor_row( $row, array $patterns, array $config ): ?array {
		$raw      = (string) $row->meta_value;
		$tree     = self::decode_elementor_data( $raw );
		$needles  = array_keys( $patterns ); // lowercase
		$prefixes = $config['setting_prefixes'];
		foreach ( $needles as $needle ) {
			if ( '_' === substr( $needle, -1 ) ) {
				$prefixes[] = $needle;
			}
		}
		$text_needles = array_values(
			array_filter(
				$needles,
				static function ( string $needle ): bool {
					return '[' === $needle[0];
				}
			)
		);

		$found = array();
		if ( null !== $tree ) {
			self::walk_elements(
				$tree,
				static function ( array $el, array $path ) use ( &$found, $needles, $prefixes, $text_needles, $config ): void {
					$widget   = self::widget_type( $el );
					$settings = ( isset( $el['settings'] ) && is_array( $el['settings'] ) ) ? $el['settings'] : array();
					$label    = ( isset( $settings['_title'] ) && is_string( $settings['_title'] ) ) ? $settings['_title'] : '';
					$id       = isset( $el['id'] ) ? (string) $el['id'] : '';
					$name     = '' !== $widget ? $widget : ( isset( $el['elType'] ) ? (string) $el['elType'] : '' );

					if ( '' !== $widget ) {
						$matched = self::widget_matches( $widget, $needles, $config['exact_widget_types'] );
						if ( '' !== $matched ) {
							$found[] = array( 'widget_type' => $widget, 'custom_label' => $label, 'widget_id' => $id, 'breadcrumb' => $path, 'kind' => 'exact' );
						}
					}
					foreach ( $settings as $key => $value ) {
						$key_lc = strtolower( (string) $key );
						foreach ( $prefixes as $prefix ) {
							if ( 0 === strpos( $key_lc, $prefix ) && self::is_active_setting( $value ) && ( '' === $widget || 0 !== strpos( strtolower( $widget ), rtrim( $prefix, '_' ) ) ) ) {
								$found[] = array( 'widget_type' => $name, 'custom_label' => 'setting ' . $key, 'widget_id' => $id, 'breadcrumb' => $path, 'kind' => 'exact' );
								break 2;
							}
						}
					}
					if ( $text_needles ) {
						$hits = array();
						self::find_text_in( $settings, $text_needles, $hits, 0 );
						foreach ( array_unique( $hits ) as $hit ) {
							$found[] = array( 'widget_type' => $name, 'custom_label' => 'contains ' . $hit, 'widget_id' => $id, 'breadcrumb' => $path, 'kind' => 'strong' );
						}
					}
				}
			);
		} elseif ( $config['exact_widget_types'] ) {
			foreach ( $config['exact_widget_types'] as $type ) {
				if ( preg_match( '/"widgetType"\s*:\s*"' . preg_quote( $type, '/' ) . '"/i', $raw ) ) {
					$found[] = array( 'widget_type' => $type, 'custom_label' => '', 'widget_id' => '', 'breadcrumb' => array( 'Damaged layout data', 'widgetType: ' . $type ), 'kind' => 'exact' );
				}
			}
		}

		if ( $found ) {
			$confidence = 'strong';
			foreach ( $found as $f ) {
				if ( 'exact' === $f['kind'] ) {
					$confidence = 'exact';
				}
			}
			$item = self::make_item( 'Elementor layout data', $confidence, (int) $row->ID, (string) $row->post_title, (string) $row->post_type, (string) $row->post_status, '_elementor_data', array( '_elementor_data' ), array(), $found );
			if ( '' === $item['elementor_link'] ) {
				$item['confidence'] = 'weak';
				$item['note']       = 'Old Elementor layout: this page was switched back to the WordPress editor, so this layout is not shown.';
			}
			return $item;
		}
		if ( ! $config['allow_elementor_raw_fallback'] ) {
			return null;
		}
		$matched = self::find_matches( $raw, $needles );
		if ( empty( $matched ) ) {
			return null;
		}
		return self::make_item( 'Elementor layout data', 'weak', (int) $row->ID, (string) $row->post_title, (string) $row->post_type, (string) $row->post_status, '_elementor_data (text match)', array( '_elementor_data' ), self::make_snippets( $raw, $matched ), array() );
	}

	/** Exact type, prefix for patterns ending in - or _, otherwise substring. */
	private static function widget_matches( string $widget, array $needles, array $exact ): string {
		$widget = strtolower( $widget );
		foreach ( $exact as $type ) {
			if ( strtolower( $type ) === $widget ) {
				return $type;
			}
		}
		if ( $exact ) {
			return '';
		}
		foreach ( $needles as $needle ) {
			if ( '[' === $needle[0] || '"' === $needle[0] ) {
				continue;
			}
			$last = substr( $needle, -1 );
			if ( ( '-' === $last || '_' === $last ) ? 0 === strpos( $widget, $needle ) : false !== strpos( $widget, $needle ) ) {
				return $needle;
			}
		}
		return '';
	}

	private static function find_text_in( array $values, array $needles, array &$hits, int $depth ): void {
		if ( $depth > 8 ) {
			return;
		}
		foreach ( $values as $value ) {
			if ( is_array( $value ) ) {
				self::find_text_in( $value, $needles, $hits, $depth + 1 );
			} elseif ( is_string( $value ) && false !== strpos( $value, '[' ) ) {
				$lower = strtolower( $value );
				foreach ( $needles as $needle ) {
					if ( false !== strpos( $lower, $needle ) ) {
						$hits[] = $needle;
					}
				}
			}
		}
	}

	private static function search_posts( array $patterns, array $post_types, array $config, array &$items, float $deadline ): bool {
		global $wpdb;
		$types  = self::post_type_sql( 'p', $post_types );
		$groups = array();
		$args   = $types[1];
		foreach ( array( 'p.post_title', 'p.post_content', 'p.post_excerpt', 'p.post_type' ) as $column ) {
			$like     = self::like_sql( $column, $patterns );
			$groups[] = '(' . $like[0] . ')';
			$args     = array_merge( $args, $like[1] );
		}
		$where   = implode( ' OR ', $groups );
		$needles = array_keys( $patterns );
		$cursor  = 0;
		while ( true ) {
			if ( self::stop_search( $items, $deadline ) ) {
				return false;
			}
			$sql  = "SELECT p.ID, p.post_title, p.post_type, p.post_status, p.post_content, p.post_excerpt
				FROM {$wpdb->posts} p
				WHERE p.ID > %d AND p.post_type <> 'revision' AND p.post_status NOT IN ('trash','auto-draft') {$types[0]}
				  AND ({$where})
				ORDER BY p.ID ASC LIMIT 50";
			$rows = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( array( $cursor ), $args ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			if ( empty( $rows ) ) {
				return true;
			}
			foreach ( $rows as $row ) {
				$cursor   = (int) $row->ID;
				$fields   = array(
					'post_title'   => (string) $row->post_title,
					'post_type'    => (string) $row->post_type,
					'post_excerpt' => (string) $row->post_excerpt,
					'post_content' => (string) $row->post_content,
				);
				$matched  = array();
				$snippets = array();
				foreach ( $fields as $field => $value ) {
					$found = self::find_matches( $value, $needles );
					if ( empty( $found ) ) {
						continue;
					}
					$matched[] = $field;
					foreach ( self::make_snippets( $value, $found ) as $snippet ) {
						$snippet[0] = '[' . $field . '] ' . $snippet[0];
						$snippets[] = $snippet;
					}
				}
				if ( $matched ) {
					$items[] = self::make_item( 'Posts / pages / templates', in_array( 'post_content', $matched, true ) ? 'strong' : 'weak', (int) $row->ID, (string) $row->post_title, (string) $row->post_type, (string) $row->post_status, implode( ', ', $matched ), $matched, $snippets, array() );
				}
			}
			unset( $rows );
		}
	}

	private static function search_postmeta( array $patterns, array $post_types, array $config, array &$items, float $deadline ): bool {
		global $wpdb;
		$types   = self::post_type_sql( 'p', $post_types );
		$like    = self::like_sql( 'pm.meta_value', $patterns );
		$needles = array_keys( $patterns );
		$cursor  = 0;
		while ( true ) {
			if ( self::stop_search( $items, $deadline ) ) {
				return false;
			}
			$sql  = "SELECT pm.meta_id, p.ID, p.post_title, p.post_type, p.post_status, pm.meta_key, pm.meta_value
				FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE pm.meta_id > %d
				  AND pm.meta_key NOT IN ('_elementor_data','_elementor_element_cache','_elementor_css','_elementor_page_assets','_elementor_controls_usage')
				  AND p.post_type <> 'revision' AND p.post_status NOT IN ('trash','auto-draft') {$types[0]}
				  AND ({$like[0]})
				ORDER BY pm.meta_id ASC LIMIT 200";
			$rows = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( array( $cursor ), $types[1], $like[1] ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			if ( empty( $rows ) ) {
				return true;
			}
			foreach ( $rows as $row ) {
				$cursor  = (int) $row->meta_id;
				$value   = (string) $row->meta_value;
				$items[] = self::make_item( 'Post meta', 'strong', (int) $row->ID, (string) $row->post_title, (string) $row->post_type, (string) $row->post_status, (string) $row->meta_key, array( (string) $row->meta_key ), self::make_snippets( $value, self::find_matches( $value, $needles ) ), array() );
			}
			unset( $rows );
		}
	}

	private static function search_options( array $patterns, array $post_types, array $config, array &$items, float $deadline ): bool {
		global $wpdb;
		$like    = self::like_sql( 'option_value', $patterns );
		$needles = array_keys( $patterns );
		$cursor  = 0;
		while ( true ) {
			if ( self::stop_search( $items, $deadline ) ) {
				return false;
			}
			$sql  = "SELECT option_id, option_name, option_value FROM {$wpdb->options}
				WHERE option_id > %d
				  AND option_name NOT LIKE %s AND option_name NOT LIKE %s
				  AND option_name NOT IN ('cron','rewrite_rules','active_plugins','recently_activated','uninstall_plugins','auto_update_plugins','" . self::OPT_RESULT . "','" . self::OPT_STATE . "')
				  AND ({$like[0]})
				ORDER BY option_id ASC LIMIT 200";
			$skip = array( $wpdb->esc_like( '_transient_' ) . '%', $wpdb->esc_like( '_site_transient_' ) . '%' );
			$rows = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( array( $cursor ), $skip, $like[1] ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			if ( empty( $rows ) ) {
				return true;
			}
			foreach ( $rows as $row ) {
				$cursor  = (int) $row->option_id;
				$value   = (string) $row->option_value;
				$items[] = self::make_item( 'WordPress options/settings', 'strong', 0, (string) $row->option_name, 'option', '', (string) $row->option_name, array( (string) $row->option_name ), self::make_snippets( $value, self::find_matches( $value, $needles ) ), array() );
			}
			unset( $rows );
		}
	}

	private static function find_matches( string $value, array $needles ): array {
		$lower   = strtolower( $value );
		$matches = array();
		foreach ( $needles as $needle ) {
			if ( '' !== $needle && false !== strpos( $lower, $needle ) ) {
				$matches[] = $needle;
			}
		}
		return array_values( array_unique( $matches ) );
	}

	/** UTF-8 safe: cutting Greek text mid-character would make esc_html() print nothing. */
	private static function make_snippets( string $value, array $needles ): array {
		$lower    = strtolower( $value );
		$snippets = array();
		$half     = (int) ( self::SNIPPET_LEN / 2 );
		foreach ( $needles as $needle ) {
			$offset = 0;
			for ( $count = 0; $count < 2; $count++ ) {
				$pos = strpos( $lower, $needle, $offset );
				if ( false === $pos ) {
					break;
				}
				$start = max( 0, $pos - $half );
				$end   = min( strlen( $value ), $pos + strlen( $needle ) + $half );
				$text  = function_exists( 'mb_strcut' ) ? mb_strcut( $value, $start, $end - $start, 'UTF-8' ) : substr( $value, $start, $end - $start );
				if ( ! preg_match( '//u', $text ) ) {
					$text = wp_check_invalid_utf8( $text, true );
				}
				$snippets[] = array( ( $start > 0 ? '…' : '' ) . $text . ( $end < strlen( $value ) ? '…' : '' ), $needle );
				$offset     = $pos + 1;
			}
		}
		return $snippets;
	}

	private static function make_item( string $source, string $confidence, int $post_id, string $title, string $post_type, string $post_status, string $location, array $fields, array $snippets, array $widgets ): array {
		$elementor = $post_id > 0 && '' !== (string) get_post_meta( $post_id, '_elementor_edit_mode', true );
		return array(
			'source'         => $source,
			'confidence'     => $confidence,
			'id'             => $post_id,
			'title'          => '' !== $title ? $title : '(no title)',
			'post_type'      => $post_type,
			'post_status'    => $post_status,
			'location'       => $location,
			'fields'         => array_values( array_unique( $fields ) ),
			'snippets'       => $snippets,
			'widgets'        => $widgets,
			'edit_link'      => $post_id > 0 ? (string) get_edit_post_link( $post_id, 'raw' ) : '',
			'elementor_link' => $elementor ? admin_url( 'post.php?post=' . $post_id . '&action=elementor' ) : '',
			'view_link'      => ( $post_id > 0 && 'publish' === $post_status && ! in_array( $post_type, self::TEMPLATE_TYPES, true ) && is_post_type_viewable( $post_type ) ) ? (string) get_permalink( $post_id ) : '',
		);
	}

	private static function group_items( array $items ): array {
		$order  = array( 'exact' => 0, 'strong' => 1, 'weak' => 2 );
		$groups = array();
		foreach ( $items as $item ) {
			$key = 'option' === $item['post_type'] ? 'opt_' . $item['location'] : 'post_' . $item['id'];
			if ( ! isset( $groups[ $key ] ) ) {
				$groups[ $key ] = array(
					'id'             => $item['id'],
					'title'          => $item['title'],
					'post_type'      => $item['post_type'],
					'post_status'    => $item['post_status'],
					'edit_link'      => $item['edit_link'],
					'elementor_link' => $item['elementor_link'],
					'view_link'      => $item['view_link'],
					'notes'          => array(),
					'hits'           => array(),
				);
			}
			if ( ! empty( $item['note'] ) ) {
				$groups[ $key ]['notes'][ $item['note'] ] = true;
			}
			$groups[ $key ]['hits'][] = array(
				'source'     => $item['source'],
				'confidence' => $item['confidence'],
				'location'   => $item['location'],
				'fields'     => $item['fields'],
				'snippets'   => $item['snippets'],
				'widgets'    => $item['widgets'],
			);
		}
		foreach ( $groups as &$group ) {
			usort(
				$group['hits'],
				static function ( array $a, array $b ) use ( $order ): int {
					return ( $order[ $a['confidence'] ] ?? 9 ) <=> ( $order[ $b['confidence'] ] ?? 9 );
				}
			);
		}
		unset( $group );
		uasort(
			$groups,
			static function ( array $a, array $b ) use ( $order ): int {
				$cmp = ( $order[ $a['hits'][0]['confidence'] ] ?? 9 ) <=> ( $order[ $b['hits'][0]['confidence'] ] ?? 9 );
				return 0 !== $cmp ? $cmp : strcasecmp( $a['title'], $b['title'] );
			}
		);
		return array_values( $groups );
	}

	private static function render_results( array $results ): void {
		?>
		<hr>
		<h2>Usage results</h2>
		<?php if ( '' !== $results['error'] ) : ?>
			<div class="notice notice-error inline"><p><?php echo esc_html( $results['error'] ); ?></p></div>
			<?php
			return;
		endif;
		?>
		<p><strong>Patterns searched:</strong> <code><?php echo esc_html( implode( ', ', $results['patterns'] ) ); ?></code></p>

		<?php if ( $results['partial'] ) : ?>
			<div class="notice notice-warning inline"><p><strong>The search stopped early</strong> (<?php echo esc_html( (string) self::SEARCH_CAP ); ?> results or <?php echo esc_html( (string) self::SEARCH_BUDGET ); ?> seconds). The list below is incomplete — use more specific patterns or fewer areas.</p></div>
		<?php endif; ?>

		<?php if ( empty( $results['groups'] ) ) : ?>
			<div class="notice notice-success inline">
				<p><strong>No usage found for these patterns<?php echo $results['partial'] ? ' so far' : ''; ?>.</strong></p>
				<p>This does not guarantee the plugin is safe to delete. Deactivate it first, clear caches and check the site.</p>
			</div>
			<?php
			return;
		endif;
		?>
		<div class="notice notice-info inline"><p><strong>Found possible usage in <?php echo esc_html( (string) count( $results['groups'] ) ); ?> location(s).</strong></p></div>
		<p>
			<span class="pus-badge pus-badge-exact">Exact</span> Elementor widget or extension found
			&nbsp; <span class="pus-badge pus-badge-strong">Strong</span> Shortcode/content/meta/settings match
			&nbsp; <span class="pus-badge pus-badge-weak">Weak</span> Raw text or title match
		</p>

		<div class="pus-card-grid">
			<?php foreach ( $results['groups'] as $group ) : ?>
				<?php
				$top_confidence = $group['hits'][0]['confidence'];
				$is_template    = in_array( $group['post_type'], self::TEMPLATE_TYPES, true );
				?>
				<div class="pus-card">
					<p class="pus-card-title"><?php echo esc_html( $group['title'] ); ?></p>
					<div class="pus-card-meta">
						<?php if ( 'option' === $group['post_type'] ) : ?>
							WordPress option (setting)
						<?php else : ?>
							Type: <strong><?php echo esc_html( $group['post_type'] ); ?></strong>
							<?php if ( '' !== $group['post_status'] ) : ?> · Status: <?php echo esc_html( $group['post_status'] ); ?><?php endif; ?>
							· ID: <?php echo esc_html( (string) $group['id'] ); ?>
						<?php endif; ?>
					</div>
					<span class="pus-badge <?php echo esc_attr( self::confidence_badge_class( $top_confidence ) ); ?>"><?php echo esc_html( ucfirst( $top_confidence ) ); ?></span>

					<?php foreach ( array_slice( $group['hits'], 0, 3 ) as $hit ) : ?>
						<div style="margin-top:8px;">
							<strong><?php echo esc_html( $hit['source'] ); ?></strong>
							<?php if ( ! empty( $hit['widgets'] ) ) : ?>
								<?php foreach ( array_slice( $hit['widgets'], 0, 4 ) as $widget ) : ?>
									<div class="pus-widget-line">
										<span class="pus-widget-type"><?php echo esc_html( $widget['widget_type'] ); ?></span>
										<?php if ( '' !== $widget['custom_label'] ) : ?> <span class="pus-muted">— <?php echo esc_html( $widget['custom_label'] ); ?></span><?php endif; ?>
										<?php if ( ! empty( $widget['breadcrumb'] ) ) : ?>
											<div class="pus-breadcrumb"><?php echo esc_html( implode( ' › ', $widget['breadcrumb'] ) ); ?></div>
										<?php endif; ?>
									</div>
								<?php endforeach; ?>
								<?php if ( count( $hit['widgets'] ) > 4 ) : ?>
									<div class="pus-muted pus-small">+<?php echo esc_html( (string) ( count( $hit['widgets'] ) - 4 ) ); ?> more (see technical details)</div>
								<?php endif; ?>
							<?php elseif ( ! empty( $hit['fields'] ) ) : ?>
								<div style="margin-top:4px;">
									<?php foreach ( $hit['fields'] as $field ) : ?>
										<span class="pus-field"><?php echo esc_html( $field ); ?></span>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>

					<?php foreach ( array_keys( $group['notes'] ) as $note ) : ?>
						<div class="pus-global-note"><?php echo esc_html( $note ); ?></div>
					<?php endforeach; ?>
					<?php if ( $is_template ) : ?>
						<div class="pus-global-note"><strong>Template:</strong> it may appear on many pages, depending on where it is embedded or its display conditions. The Plugin inventory tab shows exactly where.</div>
					<?php endif; ?>

					<div class="pus-card-actions">
						<?php if ( '' !== $group['edit_link'] ) : ?><a href="<?php echo esc_url( $group['edit_link'] ); ?>">Edit</a><?php endif; ?>
						<?php if ( '' !== $group['elementor_link'] ) : ?><a href="<?php echo esc_url( $group['elementor_link'] ); ?>">Edit with Elementor</a><?php endif; ?>
						<?php if ( '' !== $group['view_link'] ) : ?><a href="<?php echo esc_url( $group['view_link'] ); ?>" target="_blank" rel="noopener noreferrer">View<span class="screen-reader-text"> (opens in a new tab)</span></a><?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>

		<details class="pus-advanced" style="margin-top:18px;">
			<summary>Technical details</summary>
			<?php self::render_results_table( $results ); ?>
		</details>
		<?php
	}

	private static function render_results_table( array $results ): void {
		?>
		<table class="widefat pus-results-table" style="margin-top:12px;">
			<thead>
				<tr>
					<th scope="col">Post / Location</th>
					<th scope="col">Confidence</th>
					<th scope="col">Source &amp; Field</th>
					<th scope="col">Matched widgets / snippets</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $results['groups'] as $group ) : ?>
					<?php foreach ( $group['hits'] as $hit_index => $hit ) : ?>
						<tr>
							<?php if ( 0 === $hit_index ) : ?>
								<td rowspan="<?php echo esc_attr( (string) count( $group['hits'] ) ); ?>">
									<strong><?php echo esc_html( $group['title'] ); ?></strong><br>
									<span class="pus-muted pus-small"><?php echo esc_html( 'option' === $group['post_type'] ? 'option' : $group['post_type'] . ( '' !== $group['post_status'] ? ' · ' . $group['post_status'] : '' ) . ' · ID ' . $group['id'] ); ?></span>
								</td>
							<?php endif; ?>
							<td><span class="pus-badge <?php echo esc_attr( self::confidence_badge_class( $hit['confidence'] ) ); ?>"><?php echo esc_html( ucfirst( $hit['confidence'] ) ); ?></span></td>
							<td>
								<?php echo esc_html( $hit['source'] ); ?><br>
								<?php foreach ( $hit['fields'] as $field ) : ?><span class="pus-field"><?php echo esc_html( $field ); ?></span><?php endforeach; ?>
							</td>
							<td>
								<?php if ( ! empty( $hit['widgets'] ) ) : ?>
									<?php foreach ( $hit['widgets'] as $widget ) : ?>
										<div class="pus-widget-line">
											<span class="pus-widget-type"><?php echo esc_html( $widget['widget_type'] ); ?></span>
											<?php if ( '' !== $widget['custom_label'] ) : ?> <strong><?php echo esc_html( $widget['custom_label'] ); ?></strong><?php endif; ?>
											<?php if ( ! empty( $widget['breadcrumb'] ) ) : ?><div class="pus-breadcrumb"><?php echo esc_html( implode( ' › ', $widget['breadcrumb'] ) ); ?></div><?php endif; ?>
										</div>
									<?php endforeach; ?>
								<?php elseif ( ! empty( $hit['snippets'] ) ) : ?>
									<?php foreach ( $hit['snippets'] as $snippet ) : ?>
										<div class="pus-snippet"><?php echo self::highlight_snippet( $snippet[0], $snippet[1] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?></div>
									<?php endforeach; ?>
								<?php else : ?>
									<span class="pus-muted">—</span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	private static function highlight_snippet( string $text, string $needle ): string {
		$escaped     = esc_html( $text );
		$highlighted = preg_replace( '/(' . preg_quote( esc_html( $needle ), '/' ) . ')/iu', '<mark>$1</mark>', $escaped );
		return is_string( $highlighted ) ? wp_kses( $highlighted, array( 'mark' => array() ) ) : $escaped;
	}

	private static function confidence_badge_class( string $confidence ): string {
		$map = array(
			'exact'  => 'pus-badge-exact',
			'strong' => 'pus-badge-strong',
			'weak'   => 'pus-badge-weak',
		);
		return isset( $map[ $confidence ] ) ? $map[ $confidence ] : 'pus-badge-weak';
	}

	/* ---------------------------------------------------------------------
	 * Styles
	 * ------------------------------------------------------------------- */

	public static function admin_styles(): void {
		$screen = get_current_screen();
		if ( ! $screen || ! in_array( $screen->id, array( 'tools_page_' . self::PAGE, 'edit-page', 'edit-post', 'plugins' ), true ) ) {
			return;
		}
		?>
		<style>
			.pus-muted { color: #646970; }
			.pus-small { font-size: 12px; }
			.pus-warn { color: #8a2424; background: #fcf0f1; border-left: 4px solid #d63638; padding: 7px 10px; }
			.pus-top-panel { background: #fff; border: 1px solid #dcdcde; border-radius: 8px; padding: 16px 20px; max-width: 1100px; margin-top: 14px; box-shadow: 0 1px 1px rgba(0,0,0,.04); }
			.pus-panel-grid { display: grid; grid-template-columns: minmax(260px, 360px) 1fr; gap: 18px; align-items: start; }
			.pus-select-lg { width: 100%; max-width: 360px; }
			.pus-scope-row { border: 0; padding: 0; margin: 0; }
			.pus-scope-row label { display: block; margin: 7px 0; }
			.pus-hint-box { background: #f0f6fc; border-left: 4px solid #2271b1; padding: 11px 14px; border-radius: 4px; line-height: 1.55; }
			.pus-advanced { max-width: 1100px; margin-top: 12px; }
			.pus-advanced summary { cursor: pointer; font-weight: 600; }
			.pus-toolbar { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 10px; margin: 18px 0 10px; }
			.pus-chips { display: flex; flex-wrap: wrap; gap: 6px; }
			.pus-chip { display: inline-flex; align-items: center; gap: 6px; border: 1px solid #c3c4c7; background: #fff; color: #1d2327; border-radius: 999px; padding: 4px 12px; cursor: pointer; font-size: 12px; line-height: 1.6; }
			.pus-chip span:last-child { color: #646970; }
			.pus-chip.is-active { background: #1d2327; border-color: #1d2327; color: #fff; }
			.pus-chip.is-active span:last-child { color: #dcdcde; }
			.pus-chip:focus-visible, .pus-toggle:focus-visible { outline: 2px solid #2271b1; outline-offset: 2px; }
			.pus-dot { width: 9px; height: 9px; border-radius: 50%; padding: 0; display: inline-block; }
			.pus-search { min-width: 240px; }
			.pus-inv td, .pus-inv th { vertical-align: top; }
			.pus-inv .pus-name { font-weight: 600; font-size: 13px; }
			.pus-inv tr.pus-row > td { border-top: 1px solid #f0f0f1; }
			.pus-details > td { background: #f6f7f7; padding: 14px 18px 18px; }
			.pus-v { display: inline-block; padding: 2px 9px; border-radius: 999px; font-size: 11px; font-weight: 600; line-height: 1.7; white-space: nowrap; }
			.pus-v-used { background: #d63638; color: #fff; }
			.pus-v-hidden { background: #f0c33c; color: #1d2327; }
			.pus-v-active { background: #135e96; color: #fff; }
			.pus-v-quiet { background: #e5eef7; color: #0a4b78; box-shadow: inset 0 0 0 1px #9ec2e6; }
			.pus-v-unused { background: #008a20; color: #fff; }
			.pus-v-rescan { background: #fff; color: #2271b1; box-shadow: inset 0 0 0 1px #2271b1; }
			.pus-v-inactive { background: #fff; color: #50575e; box-shadow: inset 0 0 0 1px #8c8f94; }
			.pus-tag { display: inline-block; padding: 0 6px; border-radius: 4px; background: #f0f0f1; color: #3c434a; font-size: 11px; line-height: 1.8; }
			.pus-tag-live { background: #edfaef; color: #00450c; }
			.pus-tag-warn { background: #fcf0f1; color: #8a2424; }
			.pus-tag-strong { background: #e5eef7; color: #0a4b78; }
			.pus-signals { margin-top: 5px; display: flex; flex-wrap: wrap; gap: 4px; align-items: center; }
			.pus-last-scan { margin-left: 10px; }
			.pus-h4 { margin: 14px 0 6px; font-size: 13px; }
			.pus-evidence { margin: 0 0 12px; padding: 0; list-style: none; font-size: 12px; line-height: 1.5; }
			.pus-evidence li { margin: 3px 0; }
			.pus-ev-tag { display: inline-block; min-width: 118px; font-size: 11px; font-weight: 600; }
			.pus-ev-strong .pus-ev-tag { color: #135e96; }
			.pus-ev-medium .pus-ev-tag { color: #646970; }
			.pus-ev-info { color: #646970; }
			.pus-ev-info .pus-ev-tag { color: #8c8f94; font-weight: 400; }
			.pus-req { display: inline-block; margin-top: 4px; font-size: 11px; color: #8a2424; background: #fcf0f1; border-radius: 4px; padding: 1px 6px; }
			.pus-provides { display: grid; gap: 4px; margin: 0 0 12px; font-size: 12px; line-height: 1.5; }
			.pus-loc-table { width: 100%; max-width: 1200px; border-collapse: collapse; background: #fff; border: 1px solid #dcdcde; font-size: 12px; }
			.pus-loc-table th { text-align: left; background: #f0f0f1; padding: 7px 10px; }
			.pus-loc-table td { padding: 8px 10px; border-top: 1px solid #f0f0f1; vertical-align: top; }
			.pus-loc-table td:first-child { width: 32%; }
			.pus-links a { margin-right: 8px; font-size: 12px; }
			.pus-hit + .pus-hit { margin-top: 6px; }
			.pus-breadcrumb { font-size: 11px; color: #646970; margin-top: 2px; word-break: break-word; }
			.pus-card-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 12px; margin-top: 14px; }
			.pus-card { background: #fff; border: 1px solid #dcdcde; border-radius: 8px; padding: 14px; box-shadow: 0 1px 1px rgba(0,0,0,.04); }
			.pus-card-title { font-size: 14px; font-weight: 700; margin: 0 0 5px; }
			.pus-card-meta { color: #646970; font-size: 12px; margin-bottom: 9px; }
			.pus-card-actions a { display: inline-block; margin-right: 9px; margin-top: 8px; }
			.pus-global-note { background: #fff8e5; border-left: 4px solid #dba617; padding: 7px 10px; margin-top: 9px; font-size: 12px; }
			.pus-badge, .pus-page-badge { display: inline-block; padding: 2px 7px; border-radius: 999px; font-size: 11px; font-weight: 600; line-height: 1.7; white-space: nowrap; margin: 1px 3px 2px 0; }
			.pus-badge-exact { background: #d63638; color: #fff; }
			.pus-badge-strong { background: #b35900; color: #fff; }
			.pus-badge-weak { background: #646970; color: #fff; }
			.pus-page-badge { background: #f0f6fc; color: #0a4b78; box-shadow: inset 0 0 0 1px #c5d9ed; }
			.pus-page-badge-via { background: #fff; color: #50575e; box-shadow: inset 0 0 0 1px #c3c4c7; font-weight: 400; }
			.pus-page-badge-warn { background: #fcf0f1; color: #8a2424; box-shadow: inset 0 0 0 1px #f0b8bb; }
			.pus-widget-line { margin: 4px 0; }
			.pus-widget-type { font-family: ui-monospace, SFMono-Regular, Consolas, Monaco, monospace; background: #f0f0f1; padding: 1px 5px; border-radius: 4px; font-size: 11px; }
			.pus-results-table { border-collapse: collapse; width: 100%; font-size: 13px; }
			.pus-results-table th { background: #f0f0f1; text-align: left; padding: 8px 10px; white-space: nowrap; }
			.pus-results-table td { padding: 8px 10px; vertical-align: top; border-top: 1px solid #e2e4e7; }
			.pus-field { display: inline-block; font-size: 11px; font-family: ui-monospace, SFMono-Regular, Consolas, Monaco, monospace; background: #e8f0fe; color: #1a56db; padding: 1px 5px; border-radius: 4px; margin: 1px 2px 1px 0; }
			.pus-snippet { font-size: 11px; background: #fff8e5; border-left: 3px solid #dba617; padding: 4px 7px; margin-top: 4px; white-space: pre-wrap; word-break: break-word; }
			.pus-snippet mark { background: #ffe066; padding: 0 2px; }
			.column-pus_plugins { width: 220px; }
			.plugins .column-pus_usage { width: 190px; }
			@media (max-width: 900px) { .pus-panel-grid { grid-template-columns: 1fr; } .pus-inv thead th:nth-child(3), .pus-inv td:nth-child(3) { display: none; } }
		</style>
		<?php
	}
}

Aboutnet_Plugin_Usage_Scanner::bootstrap();

endif;